# Literature Dossier — Readings 09–10 Manual Release QA

Verified at 2026-11-04T12:10:19.778533+00:00.

## Status

- **Hourly automation:** disabled explicitly at user's request. Next batch is manual 11–12.
- **Canonical baseline:** previous `Literature_Dossier_Source_Readings_01-08_Editorial.zip` (88 pages with its original intended-font export).
- **All eight prior chapter HTML files and global stylesheet / JavaScript / publisher:** byte-for-byte unchanged.
- **New reading 09:** *Philosophy of Language in the Medieval Arabic Tradition* — five main pages, four revision pages, one reading opener. Eight main sections; 18 passages; 19 passage-linked study cards; six in-context memory aids; two main evidence tables; six revision subsections.
- **New reading 10:** *Black Muslim* — six main pages, four revision pages, one opener. Eight main sections; 20 passages; 20 passage-linked study cards; six in-context memory aids; two main evidence tables; six revision subsections.
- **Two-reading PDF:** 23 physical pages; 34 hierarchical bookmarks; two working Contents links.
- **Full ten-reading PDF:** 108 physical and 108 composed pages; 157 genuine bookmarks; 10 Contents links; no detected overflow or runtime errors.
- **Passage-level placement:** 39/39 new callouts printed on pages containing their exact source passage; zero cards unplaced or attached to unrelated prose. Existing prior 128 cards are unchanged.
- **Mobile test:** 390px document width at 390px viewport; no detected horizontal overflow.
- **Alternate font metrics:** a 23-page, 34-bookmark selected 09–10 export passed. A 10,9 reversed export without revision passed at 15 pages, 20 bookmarks.

## Source identity and preservation

Reading 09: https://docs.google.com/document/d/1gKkdrFAY2KU8nHL3Vrlv8a9bd3U3B3dgSYDMB13fBGY/edit

Reading 10: https://docs.google.com/document/d/1Cij3HEy-SB3oqt7BbkWgXnR-pLyL3OVV4YIO_ynWL_E/edit

The original Google Docs were exported to full text files at `sources/09-raw-explainer.txt` and `sources/10-raw-explainer.txt`; these are source archives, distinct from the curated educational notes. Neither original journal publication was supplied or independently verified. Statements and contentious rhetoric in Reading 10 are identified as historical claims from the explainer rather than endorsed by the dossier.

## Detailed intellectual coverage

**09:** Baghdad disputation (date and social setting as supplied); Mattā’s universal balance; Greek sound/thought/thing versus Arabic lafẓ/maʿnā; Zayd’s brothers and polysemy; al-Fārābī’s two discourses and three aspects of nuṭq; legal wall-boundary example; Avicenna’s mutābaqah, taḍammun, iltizām; al-Jurjānī’s successive meanings; cooperation of grammar and logic. The originally supplied wording about the debate’s exact dating is attributed, not independently certified.

**10:** Lomax, Lincoln and the 1959 exposure; *The Hate That Hate Produced* and media labels; attributed house/field polemic; interview counter-framing, wolf/snake and judo contrasts; forced segregation versus asserted voluntary separation; six-stage rehabilitation explanation and former addict role; 1961 institutions, proposed $20 million center and Elijah Muhammad’s Phoenix move; closing warning about celebrity and jealousy.

## Editorial safeguards

- Five main pages is an aspiration, not a hard cap. Reading 10 retains six for its examples and tables.
- All six semantic callout categories remain permanently colored and placed in the passage-linked margin.
- Memory aids are first encountered in context and later repeated in the dedicated revision section.
- All six revision subsections exist for both new readings.
- The compositor, CSS, typography tokens, headings, table styles, padding and export interfaces were **not altered**.

## Font qualification

The offline Chromium PDF uses the installed font fallbacks (including EB Garamond and Inter), since network Google Fonts were inaccessible in this environment and the actual Spectral/Fraunces font files are not packaged with the project. The approved earlier eight-reading PDF uses the intended fonts and has **88 pages**, whereas exporting those same unchanged eight chapters here with offline fallback produces **86 pages**. The latest combined PDF has 108 pages under the offline profile. Therefore the combined page count is not a precise apples-to-apples comparison against the old 88-page intended-font output. A separate metric-stress profile passed; the font-family CSS preference itself remains unchanged.

## Reproduction

```bash
cd book-source
python build.py
python export_bookmarked.py --chapters '9,10' --font-profile offline --out output/Readings_09_10.pdf
python export_bookmarked.py --chapters '1-10' --font-profile offline --out output/Complete_Readings_01_10.pdf
python tests/test_sidebar_integrity.py --pdf output/Complete_Readings_01_10.pdf
```

The dynamic PDF contains a true `/UseOutlines` bookmark sidebar. Per-reading single-selection exports may not include a printed Contents page; the combined 09–10 and 01–10 PDFs have working Contents hyperlinks.
