# Literature Dossier — Editorial Compression Review · Readings 01–08

**Status:** Completed and tested, 4 November 2026.  
**Scope:** A detailed editorial pass on Readings **02–08**, integrated with the previously approved Reading 01 compression.  
**Release:** 88-page full eight-reading edition, with 53-page optional main-notes-only study edition.  
**Important:** This is controlled editorial rewriting of the main notes, **not** a new interpretation of the original academic articles.

## 1. Executive result

- **Main notes:** 60 → **43 physical pages** (**17 fewer**, 28.3% reduction).
- **Complete book:** 105 → **88 physical pages** (**17 fewer**, 16.2% reduction).
- **Main-note page target:** 5 pages in Readings 03, 04, 05, 07, 08; 6 pages in Readings 01, 02, 06.
- **Revision zones:** all **35 printed revision pages unchanged**. There are **48 revision subsections**, six in every reading.
- **Individual reading openers:** all eight unchanged; the 2 front-matter pages (book cover and Contents) unchanged.
- **Sidebar:** **128/128** existing cards present, retaining their stable IDs, six semantic categories, titles and exact passage association. Shortened card text remains anchored to the related explanation.
- **Scholarly evidence:** all **15 tables** and both authored process diagrams preserved with identical markup and cell contents.
- **Fonts and compositor:** no code changes to `styles.css`, `engine.js`, `build.py`, `export_bookmarked.py` or the visual/print template. The fixed two-column layout, current body font/size, line spacing, heading spacing, table formatting, and page-break rules were not changed.

### Exact main-note page counts

| Reading | Before | After | Main words, before → after | Sidebar cards retained |
|---|---:|---:|---:|---:|
| 01 · A Petition to the Fāṭimid Caliph al-Āmir | 7 | **6** | 927 → 927 | 15 |
| 02 · Was the Fatimid Amīr al-Juyūsh in fact a Wazīr | 8 | **6** | 1,556 → 899 | 16 |
| 03 · Learning the Grammar of Animacy | 7 | **5** | 1,312 → 853 | 18 |
| 04 · Al-Afḍal b. Badr al-Jamālī and the First Crusade | 8 | **5** | 1,522 → 827 | 19 |
| 05 · Persian in Arabic Poetry | 8 | **5** | 1,364 → 845 | 14 |
| 06 · The Worst of Times: Crisis Management | 8 | **6** | 1,439 → 905 | 14 |
| 07 · The Qadi, the Wazir and the Daʿi: Buyid Shiraz | 6 | **5** | 1,201 → 769 | 15 |
| 08 · The Fatimids and the Red Sea (969–1171) | 8 | **5** | 1,697 → 862 | 17 |
| **Total** | **60** | **43** | **11,018 → 6,887** | **128** |

The word totals count main prose/text extracted from the existing chapter `prose` containers, including source tables where present. Sidebar-card text is accounted for separately (2,307 → 1,382 words). The changes reduce repetition and duplicate instructional recaps. **Word count alone cannot establish that all interpretive nuance survives**; that requires editorial comparison, described below.

## 2. Rules used during the compression

The following hierarchy has been respected:

1. **Opener = orientation.** Preserve the question, thesis and roadmap; do not rehearse the full roadmap in the first main section.
2. **Main narrative = complete explanation.** State each argument, causal mechanism, attributed source claim, scholarly qualification and illustrative evidence clearly once. Keep reasons and distinctions, not merely conclusions.
3. **Sidebar = rapid recognition/recall.** Retain definitions, key concepts, exam tips, errors, memory aids and high-yield observations as short *separate* cards. A student skipping a card should still be able to follow the main argument.
4. **Revision = retrieval.** Keep chapter summaries, one-page revision sheets, definition collections, key tables, memory-aid collections and exam questions, unchanged in this experiment.
5. **No superficial page squeezing.** Page savings come from rewriting repeated prose, not shrinking fonts, margins or line spacing, changing CSS, compressing tables, or modifying heading/list break rules.
6. **Five is a target, six is legitimate.** For Readings 02 and 06, essential source evidence and the original tables justify six pages. The last page of a main section may be shorter because each dark revision zone begins on a new page.

## 3. Chapter-by-chapter editorial decisions

### Reading 02 — The military wazirate: 8 → 6 main pages

**Central argument retained:** from the Fatimid political ideal of the civil wazīr (*arbāb al-aqlām*) to Badr al-Jamālī's effective command over army and administration (*arbāb al-suyūf*), despite deliberate avoidance of the public title *wazīr*.

- Consolidated overlapping introduction, roadmap and the final restatement of the political transformation.
- Kept the Moses/Aaron and Joseph models; the *wizāra/wasāṭa* distinction; Ibn Killis, al-Jarjarāʾī and al-Yāzūrī; Badr's 466/1074 secret crossing; and the four military theatres.
- Preserved the office-versus-title puzzle and its evidence: *ṭirāz*, building inscriptions, private handwritten *tawqīʿ*, the al-Ṣulayḥī 'Sultan' comparison, formal decrees and militia succession through Shīrkūh and Saladin.
- Left **three evidence tables** unchanged, along with 16 tagged sidebar cards. The result remains six pages rather than deleting the titulature or documentary analysis to force five.

### Reading 03 — Grammar of Animacy: 7 → 5 main pages

**Central argument retained:** language shapes whether the living world is experienced as isolated things or a community of subjects and moral relations.

- Removed duplicative opening roadmap, repeated lists of key terms, and a second full statement of the conclusion, without replacing the narrative with abstract bullet points.
- Retained the **Puhpowee** mushroom scene; the first-person scientist's dilemma; boarding-school suppression and the historical *nine chairs* gathering; Jim Thunder and 'Spanawatomi'; 70%-verb claim; *wiikwegamaa*, *Yawe*, Andy/Carla; and Bill Tall Bull's final teaching.
- Preserved the qualification that *nine fluent speakers* is the figure in a narrated scene, **not a verified contemporary census**.
- Kept both comparison tables, 18 sidebar cards, and all six revision subsections.

### Reading 04 — Al-Afḍal and the First Crusade: 8 → 5 main pages

**Central argument retained:** rival contemporary and retrospective narratives manufactured contrasting reputations for al-Afḍal's rationality, masculinity and military legitimacy.

- Combined repeated exposition of the court-to-army transition with the separate chronology while preserving its distinct details.
- Kept the *muruwa/adab* framework and its gendered intellectual context **attributed to historical sources**, not endorsed as an analytical truth; the paternal Badr inheritance; the 1087 *khuṭba*; and all three later hostile anecdotes (jealousy, imprisonment/forgetfulness, Nizārī schism).
- Maintained the distinction between **reported accusations** and demonstrated events. Kept the state-sponsored *jihād* rhetoric, Artuqid/Jerusalem context, the contrasting **1118 al-Faramā** accounts, Baldwin's illness and the surviving state-letter evidence.
- Preserved all three tables, 19 cards, and the complete revision area.

### Reading 05 — Persian in Arabic Poetry: 8 → 5 main pages

**Central argument retained:** Persian and Persianising expressions in Arabic poetry are used as social codes, comic material, identity assertions and changing claims to legitimacy, rather than constituting a single timeless cultural attitude.

- Consolidated introductory definitions of macaronic writing, translation/transliteration and multilingual performance; avoided restating each poet's significance both before and after their example.
- Preserved the distinct poet-by-poet cases and important lexical examples (*nōg-rōz*, *mutakharsin*, *rūsapīd*, *du va sih*, *bikhuft*, etc.), together with the contrast between Zoroastrian imagery, Umayyad insult, Abbasid panegyric and later Buyid/urban inversion.
- Retained caveats on identifying foreign terms and the social context of parody, plus the existing evidence table and all 14 sidebar cards.
- This chapter received extra explanatory restoration after an initial draft proved too skeletal.

### Reading 06 — The Worst of Times: 8 → 6 main pages

**Central argument retained:** famine and the *al-Shidda al-ʿUzma* crisis must be explained through a interacting system of Nile flows, irrigation, state food policy, fiscal capacity, war and political institutions—not a simplified 'bad flood alone caused famine' formula.

- Reduced repeated Nile-system background and recurring administrative summaries while retaining the mechanisms of canal regulation, *taqāwī* seed credit, taxation, granaries, hoarding, troop disruption and reform.
- Kept the Nile-level evidence table **unchanged**, the second substantive table, critical actors, chronological markers, and the supplied text's internal date/period problems as marked qualifications rather than silently inventing a solution.
- Preserved the explanatory role of Theodora, al-Ḥākim/al-Ẓāhir, Nāṣir-i Khusrau, al-Maqrīzī and Badr's intervention, and all 14 study cards.
- Retained six main pages because the source's causal interdependencies and tables need room for reasoning.

### Reading 07 — The Qadi, the Wazir and the Daʿi: 6 → 5 main pages

**Central argument retained:** Abu Kalijar's political survival depended on access, mediation and counterweights among religious, military and administrative factions, not the victory of a single interest.

- Streamlined repeated summaries of the 'Shiraz model' while retaining the *actual chain* of al-Muʾayyad's mission, Daylami support, Ramadan dispute and strategic retreat to Fasa.
- Kept the distinct roles of the Qadi al-Fazari, the Wazir Bahram, Abu Kalijar, the relation to Baghdad's turmoil, and the autobiographical/source-position qualification.
- Preserved the three-figure comparison table, 15 passage-anchored cards and all revision sections.

### Reading 08 — Fāṭimids and the Red Sea: 8 → 5 main pages

**Central argument retained:** the Red Sea was both an instrument of political-religious expansion and an essential commercial/strategic artery for the Fatimid state, with changing emphasis across the dynasty's history.

- Combined repeated mission chronology and trade-route summaries but kept the distinct two-phase periodization, Hijaz/Yemen/Mecca/Medina relations, Aden/Aydhāb and linked networks.
- Kept the **Kārim** shipping-season evidence (June–November), Jewish mercantile connections, customs/marine imports, shipbuilding materials, named naval activity and contemporary versus retrospective claims.
- Retained chronological caveats about Badr's arrival and the potentially misleading 'two-century Crusader resistance' phrasing; the explanation remains attributed to the supplied secondary explainer.
- Kept the full existing comparison table, 17 sidebar cards, and all six revision subsections.

## 4. What the QA actually establishes

**Source and design integrity:**

- Compared the new chapter HTML against the immediately preceding **Reading 01 pilot source ZIP**, not against obsolete initial files.
- Checked every chapter's heading IDs, section count, original opener and revision HTML, every main-reading table, both process-strip diagrams, original raw explainer file bytes, and every note's identity, category and title.
- Verified that **Reading 01 remains unchanged** from its approved experiment, while only main-body explanatory prose and sidebar-cue text in 02–08 were edited.
- Checked selected critical names, dates, linguistic examples and legal terminology from each revised chapter against its active explanatory text. No terms on the recorded coverage lists were missing.
- Confirmed **all 128 sidebar notes placed on the actual page containing their exact original passage anchor**, with zero unplaced or duplicated notes. This is stronger than merely verifying a note remains somewhere in the correct section.

**Real PDF and responsive tests:**

| Test | Result |
|---|---|
| Composed / physical full-book pages | **88 / 88** |
| Page geometry | 13⅓ × 7½ inches, 16:9 on every sheet |
| Full-book PDF bookmarks | **125 genuine hierarchical entries** |
| Full-book Contents hyperlinks | **8** working entries |
| Readings 01–08 memory aids | All retained and still individually identifiable |
| Sidebar note alignment | **128 / 128** exact passage/page matches |
| Main pages | **43**; unchanged revision pages **35** |
| Alternative font-metric / reversed order | `8,3,2` produced 21 valid pages, 26 bookmarks, 3 links |
| Optional edition with revisions omitted | **53 pages**, 69 bookmarks, 8 Contents links |
| Mobile viewport | Tested at 390px without horizontal overflow |
| Detected logical-page or physical-sheet overflow | **0** |
| JavaScript execution errors | None reported in tested exports |

The drop from **138 to 125** PDF outline entries reflects the removal of genuinely redundant minor main-body headings/recap blocks, **not** missing major scholarly sections or missing revision subsections. All eight readings still have their original section sequence, complete revision zones and clickable Contents entries.

The 53-page **main-notes-only** PDF is an *additional option*, not a replacement for the complete 88-page version. It retains book front matter and each reading's opener; the six-part revision sections remain in the full edition only.

## 5. Editorial limitations and safeguards

1. **Fidelity means fidelity to the supplied explanatory material, not journal-article fact checking.** The original peer-reviewed articles are not present here; no independent historical or philological certification is claimed.
2. The coverage audit guards against the disappearance of named terms and evidence but does **not mathematically prove every nuance survived rewriting**. The untouched supplied explainers and original pre-compression chapters are archived in the editable ZIP for side-by-side review.
3. Some PDF pages toward the end of a main reading are intentionally shorter. The separate dark revision zone must begin on a fresh sheet, and this task deliberately did not alter printing controls to fill every last gap.
4. The original PDF has a 138-item outline; the new release has 125. This was tested with live PDF outline destinations; differences are attributable to editorial removal of duplicated subordinate signposts.
5. The output PDF embeds font subsets. Raw font files are **not** distributed with the source package. Re-exporting with other font metrics may change page counts and must rerun the PDF checks.

## 6. Archive, reproduction and next batches

The **canonical source ZIP** contains all eight revised independent chapter HTML files, original raw user explainers, the unchanged publisher, baseline reading files for editorial diffing, and an editorial-change log. It also includes `EDITORIAL_COMPRESSION_POLICY.md`, which adds the five-page *target* rule on top of the established passage-linked sidebar standard.

The older `tests/test_eight_readings.py` and other initial-version scripts are retained only for their historical role; where they require **word-for-word equivalence** to the former longer content, that assertion is intentionally superseded by the explicitly approved compression policy. Future tests must instead enforce conceptual coverage, exact table/figure preservation, note identity/alignment, and PDF integrity.

A future 09+ reading should follow the same policy: aim for five main-note pages, allow six when scholarly density warrants it, and keep explanatory arguments understandable independent of the sidebar. Continue producing paired readings with unchanged CSS/JS and separate six-part revision zones. If a newer 09+ validated edition already exists, merge its newer chapters with these revised 01–08 files; never discard newer work to reset a source checkpoint.

---

**Editorial conclusion:** The results show that a concise, source-faithful two-column literature dossier can average approximately **5.4 main-note pages per completed reading** (43 pages across eight), without the earlier long-line problem, reduced typography, or the need to move scholarly tables into the sidebar. The 88-page full edition includes all end-of-chapter revision material. This is a strong but still reviewable **editorial baseline**, not permission to automatically delete details in future readings solely to hit a page target.
