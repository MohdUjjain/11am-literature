# QA — Readings 20 & 21 · Controlled Editorial Sidebar Dossier

**Date:** 5 November 2026  
**Status:** Complete (manual batch); recurring automation remains disabled.

## Editorial scope

- **Reading 20 — Was al-Maqrīzī’s Khiṭaṭ a Khaldūnian History?** Six main sections, 922 words of prose/table content in main passages, 5 main-note pages, 21 passage-linked sidebar cards (5 in-context memory aids), two scholarly comparison tables and all six unchanged-format revision sections.
- **Reading 21 — Marriage, Divorce, and Inheritance in Classical Islamic Law and Premodern Practice.** Seven main sections, 1149 words of prose/table content in main passages, 6 main-note pages, 28 passage-linked sidebar cards (6 in-context memory aids), three scholarly comparison tables and all six revision sections.
- Both original Google Drive source texts are retained byte-for-byte in `sources/20-raw-explainer.txt` and `sources/21-raw-explainer.txt`, with SHA-256 values in `NEW_READINGS_20_21_MANIFEST.json`. The chapter notes are **interpretations of supplied explainers**, not independently checked against original scholarly works.
- All historical examples, named figures and technical distinctions were retained when they supplied unique evidence. Repeated opening roadmaps and conclusion recaps were consolidated into the chapter opener and revision system. No font sizes, line spacing, page breaks, CSS, JS or main column widths were changed.

## Coverage safeguards

**Reading 20:** Ibn Khaldūn/al-Maqrīzī relationship (1383 and 1405); logical studies and Mamluk patronage; shared Fāṭimid genealogical position; <em>Ittiʿāẓ al-ḥunafāʾ</em>; four methodological terms (<em>kanh</em>, <em>ḥaqīqa</em>, <em>ḥāl</em>, <em>aṣl</em>); Ṭūlūnid, Fāṭimid and Mamluk urban episodes; unfinished seventh section and honey taxation; Barqūq, Faraj and Barsbāy; <em>ʿaṣabiyya</em> and <em>ʿibra</em>. The distinction between documented evidence and interpretive inference is explained.

**Reading 21:** descriptive/prescriptive sources; consent and <em>walī</em> differences among Ḥanafī, Imāmī, Mālikī, Shāfiʿī and Ḥanbalī traditions; <em>mahr</em>, <em>nafaqa</em> and payable <em>ḥāll</em> debt; court-enforceable vs moral duties; <em>ṭalāq</em>, <em>khulʿ</em>, <em>faskh</em>; Mālikī Spain’s five stipulations; school-specific child-custody table; Sunni <em>ʿaṣaba</em> versus Twelver Shīʿī treatment; one-third <em>waṣiyya</em> ceiling; <em>waqf ahlī</em>, <em>hiba</em>, Moroccan endowment evidence and the Cordoban nominal sale.

## Publication results

| Check | Verified result |
|---|---:|
| New standalone pair | **27 pages**, 31 genuine PDF bookmarks; 2 Contents links |
| Cumulative dossier (01–18, 20–21) | **217 pages**, 307 genuine PDF bookmarks; 20 Contents links |
| Reading 20 individual | 13 pages, 15 bookmarks |
| Reading 21 individual | 14 pages, 16 bookmarks |
| New sidebar cards | **49 / 49** present, unique and exactly passage-aligned |
| Full sidebar audit | **394 / 395** passage-aligned; only inherited Reading 04 `s4-6-n2` drift in offline metrics |
| New six-category color classes | All six categories in both readings |
| Memory aids repeated in revision | 5 / 5 in Reading 20, 6 / 6 in Reading 21; exact text matching |
| Revision subsections | Six per reading |
| Composed vs physical PDF sheets | Exact match for each checked PDF |
| PDF page geometry | Every sheet 960 × 540 PDF points |
| Detected compositor / body overflow | 0 |
| JavaScript page errors | 0 |
| Reversed reading selection | **27 pages**, valid outline |
| Alternate-font-metrics selection | **27 pages**, valid outline |
| Mobile horizontal overflow at 390 px | None (390 px scroll vs 390 px viewport) |
| Previous chapter & core publisher files | 25 / 25 archived components byte-for-byte equal to previous 01–18 source ZIP |
| Reading 19 | Unassigned, intentionally omitted from contents |

**Known limitation:** Export was performed with the verified offline font profile. A different set of installed/remote typeface metrics may change some page wrapping and sidebar alignment. The earlier Reading 04 single-note mismatch was not silently edited in this chapter-only batch.

**Recovery instruction:** Begin the next manual batch at Readings **22–23**, using the source ZIP from this release; retain Reading 19 as null in `course_index.json`. Never revert to older 01–18 chapters and never enable the recurring automation without explicit user request.
