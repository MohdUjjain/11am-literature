"""Manual batch 20–21. Based solely on the two supplied Drive explainers.

The earlier chapters, CSS, JS, and publishing code are immutable.  This is an
editorial study-guide transformation: unique details remain in explanatory prose;
repeated recaps and roadmaps migrate to the opener / revision sections.
"""
from pathlib import Path
import json, html, hashlib
ROOT=Path(__file__).resolve().parent

CATS={'definition','concept','examtip','mistake','memory','highyield'}
def P(t,*notes):return {'html':'<p>'+t+'</p>','notes':[dict(kind=k,title=ttl,body=b) for k,ttl,b in notes]}
def T(head,rows,*notes):
 return {'html':'<table data-content-type="comparison" data-pagination="repeat-header"><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in r)+'</tr>' for r in rows)+'</tbody></table>','notes':[dict(kind=k,title=ttl,body=b) for k,ttl,b in notes]}
def L(items,*notes,ordered=False):
 tag='ol' if ordered else 'ul'
 return {'html':f'<{tag}>'+''.join(f'<li>{item}</li>' for item in items)+f'</{tag}>','notes':[dict(kind=k,title=ttl,body=b) for k,ttl,b in notes]}
def S(title,*items):return {'title':title,'items':list(items)}
def build(n,title,subtitle,thesis,sections,definitions,keytables,memory,questions,summary,cards,accent,source_id,file_slug):
 o=[f'<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{accent};"><div class="leaf"><div class="chapter-title-page">',
    f'<div class="reading-eyebrow">Reading {n:02d} · Literature Dossier</div><h1>{html.escape(title)}</h1>',
    f'<p class="subtitle">{html.escape(subtitle)}</p><hr class="gold-rule"/>',
    '<div class="opener-split"><div class="thesis-block"><p class="kicker">Central thesis</p>',
    '<p>'+thesis+'</p></div><div class="roadmap"><p class="kicker">In this reading</p><ol>',
    *['<li>'+html.escape(s['title'])+'</li>' for s in sections],'</ol></div></div>',
    f'<p class="source-cite">Source: supplied Google Drive explainer {n:02d}, Google Doc {source_id}. The account follows the supplied interpretation; no independent verification against the underlying publication has been made. Historical claims and quotations are attributed to that explainer.</p></div>']
 stats={};cnt=0
 for i,s in enumerate(sections,1):
  o.append(f'<div class="section" id="s{n}-{i}"><div class="section-number">§{n}.{i}</div><h2>{html.escape(s["title"])}</h2><div class="section-body">')
  for j,it in enumerate(s['items']):
   a=f's{n}-{i}-p{j}'
   o.append(f'<article class="passage" data-anchor="{a}"><div class="prose">{it["html"]}</div>')
   if it['notes']:
    o.append('<aside aria-label="Study notes for this passage">')
    for k,note in enumerate(it['notes']):
     typ=note['kind']; assert typ in CATS
     stats[typ]=stats.get(typ,0)+1;cnt+=1
     o.append(f'<div class="callout callout--{typ}" data-content-type="{typ}" data-note-id="{a}-n{k}" data-pagination="allow-split"><div class="tag">{html.escape(note["title"])}</div><p>{note["body"]}</p></div>')
    o.append('</aside>')
   o.append('</article>')
  o.append('</div></div>')
 matched_mem=[(i,note['body']) for i,s in enumerate(sections,1) for it in s['items'] for note in it['notes'] if note['kind']=='memory']
 assert len(matched_mem)==len(memory), (n,matched_mem,memory)
 assert all(matched_mem[j][0]==memory[j][0] for j in range(len(memory))),n
 memory=[(i,title,matched_mem[j][1]) for j,(i,title,_) in enumerate(memory)]
 o.extend(['</div><div class="revision-zone"><div class="revision-leaf">',f'<div class="revision-kicker">Reading {n:02d} · Revision &amp; recall</div>'])
 def R(i,title,body):return f'<div class="section" id="s{n}-rev-{i}"><div class="section-number">REV {i:02d}</div><h2>{title}</h2><div class="section-body">{body}</div></div>'
 o.append(R(1,'Chapter Summary','<p>'+summary+'</p>'))
 o.append(R(2,'One-Page Revision Sheet','<div data-pagination="keep-together"><div class="revision-grid">'+''.join(f'<div class="revision-card"><h3>{h}</h3><p>{b}</p></div>' for h,b in cards)+'</div></div>'))
 o.append(R(3,'Key Definitions',T(['Term','Meaning in the supplied reading'],definitions)['html']))
 o.append(R(4,'Key Tables',keytables))
 o.append(R(5,'Memory Aids','<div class="callout-grid">'+''.join(f'<div class="callout callout--memory" data-content-type="memory" data-pagination="allow-split"><div class="tag">Memory aid · From §{n}.{i} · {h}</div><p>{b}</p></div>' for i,h,b in memory)+'</div>'))
 o.append(R(6,'Possible Examination Questions','<div class="revision-grid exam-question-grid">'+''.join(f'<div class="exam-q"><span class="qtype">{cat}</span><p>{q}</p></div>' for cat,q in questions)+'</div>'))
 o.extend(['</div></div></section>'])
 f=ROOT/'chapters'/f'{n:02d}-{file_slug}.html';f.write_text(''.join(o),encoding='utf8')
 return {'reading':n,'file':f.name,'sections':len(sections),'passages':sum(len(s['items']) for s in sections),'notes':cnt,'note_types':stats,'memory_aids':len(memory),'tables':sum('<table' in it['html'] for s in sections for it in s['items']),'revision_sections':6}

# 20: Individual methodological moves and the evidence for the teacher/student link.
sec20=[
 S('What Makes a City a Khaldūnian History?',
  P('The supplied explainer asks whether <em>al-Mawāʿiẓ wa-l-iʿtibār bi-dhikr al-khiṭaṭ wa-l-āthār</em> (the <em>Khiṭaṭ</em>) is more than an inventory of Cairo’s sites. Its thesis is that <strong>Taqiyy al-Dīn al-Maqrīzī</strong> (1364–1442) transformed urban topography into a study of the processes by which dynasties build, prosper and decay. In that reading, he applies themes from <strong>Ibn Khaldūn</strong> (1332–1406): <em>ʿumrān</em> (human settlement or civilization), political cycles and the historical meaning of ruins.',
    ('concept','Central question · What is being proved?','The claim is not that every page quotes Ibn Khaldūn, but that the city is investigated as an artifact of social and political processes.'),
    ('definition','Term · ʿUmrān','The realm of human settlement and civilization to which Ibn Khaldūn applies systematic historical explanation.')),
  P('The relationship is asymmetrical in the narrative. Al-Maqrīzī reverently calls Ibn Khaldūn <em>shaykhunā</em> (“our master”) and praises his <em>Muqaddima</em>; Ibn Khaldūn does not name al-Maqrīzī in his autobiographical <em>Taʿrīf</em>. The absence is not proof that they never worked together: the historical evidence must be judged separately from their unequal public praise.',
    ('mistake','Do not confuse silence with non-influence','The teacher’s silence in an autobiography and the student’s explicit intellectual debt are different kinds of evidence.'))),
 S('A Thirty-Year Connection: Logic, Office and Patronage',
  P('Ibn Khaldūn arrived in Cairo and al-Maqrīzī entered his circle in <strong>January 1383</strong>, aged about eighteen. Al-Maqrīzī already had an ʿulamāʾ education; their shared studies included <strong>Afḍal al-Dīn al-Khūnajī’s <em>al-Jumal fī l-Manṭiq</em></strong>, along with the North African and Andalusian past. The account also notes a mutual interest in dreams and visions as possible historical testimony.',
    ('highyield','Evidence of a real intellectual connection','The source names 1383, logic lessons in <em>al-Jumal</em>, and al-Maqrīzī’s later explicit praise of the <em>Muqaddima</em>.'),
    ('memory','Memory · 1383 → 1405','<strong>1383: instruction and logic.</strong> <strong>1405: near-simultaneous loss of office.</strong> Remember the partnership’s intellectual and courtly sides.')),
  P('Courtly fortunes provide a second strand. Both had ties to Mamluk patrons including <strong>Amīr Yashbak al-Shaʿbānī</strong>. The source suggests that al-Maqrīzī, serving as a <em>nadīm</em> (boon companion) to Sultan Barqūq, may have supported Ibn Khaldūn’s reappointment; this is a <strong>possibility, not a demonstrated transaction</strong>. In May 1405 Ibn Khaldūn lost the chief Mālikī judgeship and al-Maqrīzī lost the <em>muḥtasib</em> office within five days.',
    ('examtip','Weigh the kinds of evidence','Distinguish documented timing and shared patrons from the inferred use of influence on a teacher’s behalf.'))),
 S('The Fāṭimid Bond: Lineage and Confessional Polemic',
  P('The two historians also diverged from the Sunni ʿulamāʾ polemic that rejected the Fāṭimid caliphs’ descent from <strong>Fāṭima</strong>. Both accepted that lineage. For al-Maqrīzī the issue was personal: he understood himself to descend from the Fāṭimids. His companion <strong>Ibn Fahd</strong> reported that a sixth ancestor, <strong>Muḥammad b. Tamīm</strong>, relocated to Baalbek and adopted the family name al-Maqrīzī to conceal the ancestry from possible killers.',
    ('definition','Term · Ḥunafāʾ','In the explainer’s reading of <em>Ittiʿāẓ al-ḥunafāʾ</em>, it names sincere believers and signals an appeal beyond partisan denunciation.'),
    ('highyield','Shared position ≠ identical motivation','The historians concur on Fāṭimid genealogy, while the explainer presents al-Maqrīzī’s family affiliation as especially personal.')),
  P('In his Fāṭimid chronicle <em>Ittiʿāẓ al-ḥunafāʾ</em> (“Lessons for the True Believers”), al-Maqrīzī urges readers to <strong>“examine the facts fairly.”</strong> The account treats this stance as a refusal to let inherited sectarian accusation determine historical possibility. It complements the methodological turn in the <em>Khiṭaṭ</em>: a historian should ask how a dynasty existed and functioned, rather than dismissing it before investigation.',
    ('concept','Move from dogma to investigation','Genealogical fairness is evidence of historical disposition, not by itself proof of a direct philosophical borrowing.'))),
 S('From the Muqaddima to a Method of Historical Inquiry',
  P('Al-Maqrīzī celebrates the <em>Muqaddima</em> as “the cream of knowledge” and an achievement of “sound minds.” The supplied account identifies four terms that help turn such admiration into a method: <em>kanh</em> (essence), <em>ḥaqīqa</em> (reality), <em>ḥāl</em> (condition), and <em>aṣl</em> (origin). These guide questions about what a city or institution <strong>is</strong>, what actually occurred, what conditions prevailed and where the phenomenon began.',
    ('memory','Memory · E / R / C / O','<strong>Essence — Reality — Condition — Origin</strong>: four questions behind historically explanatory topography.'),
    ('definition','Four analytical terms','<em>Kanh</em>, <em>ḥaqīqa</em>, <em>ḥāl</em>, <em>aṣl</em> are interpretive lenses in the supplied account, not interchangeable synonyms.')),
  T(['Arabic term','Question to ask','Historical use'],[
   ['<em>Kanh</em> · essence','What is this phenomenon?','Identify the nature of the city or institution'],
   ['<em>Ḥaqīqa</em> · reality','What happened in fact?','Test inherited claims against events'],
   ['<em>Ḥāl</em> · condition','What was its situation?','Specify circumstances at a given time'],
   ['<em>Aṣl</em> · origin','From where did it arise?','Trace institutions and settlements to their beginnings']]),
  P('In this view a monument is not merely an object for description. Its construction and abandonment mark <strong>human intentions, administrative resources, social relations and historical causes</strong>. Thus topography can move from certainty rooted in received belief toward the more qualified and explainable <em>possibility of history</em>.',
    ('mistake','Topography is not automatically theory','The decisive move is explaining the cause of building and ruin—not just supplying a philosophical label to a catalogue.'))),
 S('Cairo as an Archive of Dynastic Cycles',
  P('The <em>Khiṭaṭ</em> maps dynastic fortunes onto the changing urban fabric. The <strong>Ṭūlūnids</strong> built the sumptuous al-Qaṭāʾiʿ, later demolished by the ʿAbbāsids. The <strong>Fāṭimid</strong> era appears as one of order and decorum but also of the Great Calamity (<em>al-shidda al-ʿuẓmā</em>) and the burning of Fusṭāṭ in <strong>1168</strong> to deny it to Crusader attackers. The <strong>Mamluk</strong> account contrasts the comparatively worthy Baḥrī rulers with the deteriorating Burjī order.',
    ('highyield','Three urban episodes','Ṭūlūnids: foundation and demolition. Fāṭimids: order, famine, burning. Mamluks: decline within continuing rule.'),
    ('memory','Memory · T / F / M','<strong>Ṭūlūnids — Fāṭimids — Mamluks.</strong> Each political transition leaves a material trace in Cairo.')),
  T(['Dynasty','Urban evidence','Historical interpretation'],[
   ['Ṭūlūnid','Al-Qaṭāʾiʿ built in splendor, later destroyed','The political fortunes of a dynasty appear in the city'],
   ['Fāṭimid','Cairene order; Great Calamity; Fusṭāṭ burned in 1168','Prosperity is vulnerable to crisis and warfare'],
   ['Mamluk','Baḥrī achievements contrasted with Burjī deterioration','Institutional habits and leadership affect urban welfare']]),
  P('The source’s word “cycle” should not be flattened into identical stages mechanically repeated by all rulers. The examples are different: a destroyed new capital, crisis within an established polity, and degradation of a military elite. Their shared point is that <strong>urban change registers the life of political and social organization</strong>.',
    ('examtip','Explain the comparison, not only the names','Link each dynasty to a physical consequence and then state why the consequence counts as a historical explanation.'))),
 S('Ruin, ʿAṣabiyya and the Moral Argument',
  P('Al-Maqrīzī planned a seventh part of the <em>Khiṭaṭ</em> on the <strong>“reasons for ruin,”</strong> but the source describes it as unfinished: the surviving draft breaks off in an everyday matter, the taxing of honey. That unfinished form matters. The intended explanation of ruin is clear from his discussion, but the historian cannot treat an incomplete final section as a perfectly executed systematic treatise.',
    ('definition','Term · ʿAṣabiyya','Social or group solidarity; the source connects its corruption among Mamluk elites to the weakening of rule.'),
    ('mistake','An intended final part is not a finished one','The seventh part’s unfinished state qualifies the claim of a fully systematic Khaldūnian history.')),
  P('His sharpest denunciation concerns the late Mamluk regime, above all <strong>Sultan al-Ashraf Barsbāy</strong>. The source traces decay through recruitment under Barqūq and Faraj, waning military <em>ʿaṣabiyya</em>, luxury and the abandonment of disciplined barracks life. The rhetoric is severe: he calls the soldiers more lustful than monkeys and more harmful than wolves, blaming Egypt’s destruction on <strong>“the laxity of rule and the corruption of governors.”</strong> Such language is evidence of his moral diagnosis, not a neutral statistical measure of decline.',
    ('concept','Ibra · The point of describing ruin','<em>ʿIbra</em> is an instructive lesson: a ruined street or building can make the consequences of failed government visible.'),
    ('memory','Memory · Stone → society → lesson','<strong>Urban trace → weakened government / solidarity → ʿibra.</strong> The city teaches historical causation.')),
  P('The most defensible answer to the chapter’s title is therefore qualified. Al-Maqrīzī’s filial attachment to Egypt—his “place of my birth” and the “bosom” where he acquired his wings—supplies the urban subject; Khaldūnian <em>ʿumrān</em> supplies a way to interpret it. The <em>Khiṭaṭ</em> becomes a <strong>Khaldūnian urban history in its explanatory ambition</strong>, even while particular claims of direct influence, complete theoretical execution and the moral judgments of its author require discrimination.',
    ('examtip','Best concluding formulation','Distinguish reverence for a teacher, borrowed concepts, actual causal urban analysis, and the limits of the unfinished ruin section.')))
]
mem20=[
 (2,'1383 → 1405','<strong>1383: logic lessons.</strong> <strong>1405: near-simultaneous office losses.</strong>'),
 (4,'E / R / C / O','<strong>Essence / Reality / Condition / Origin.</strong> Four questions for urban historical explanation.'),
 (5,'T / F / M','<strong>Ṭūlūnids → Fāṭimids → Mamluks.</strong> Each regime leaves a distinctive urban trace.'),
 (6,'Stone → society → lesson','<strong>Urban evidence → governmental / social condition → ʿibra.</strong>'),
 (6,'Four layers of proof','<strong>Admiration → terminology → urban causation → limits.</strong> Do not use the first as proof of all four.')]
# Add fifth aid at the site of the argument it recalls.
sec20[-1]['items'][-1]['notes'].append(dict(kind='memory',title='Memory · Four layers of proof',body='<strong>Admiration → terminology → urban causation → limits.</strong> Do not equate praise with a fully realized system.'))
# A term-based recall cue belongs alongside the four-term comparison table.
sec20[3]['items'][1]['notes'].append(sec20[3]['items'][0]['notes'].pop(1))
res20=build(20,'Was al-Maqrīzī’s Khiṭaṭ a Khaldūnian History?',
 'The Philosopher’s Apprentice: Urban Causation, Dynastic Cycles and the Lessons of Ruin',
 'The supplied explainer reads al-Maqrīzī’s <em>Khiṭaṭ</em> as a historically explanatory account of Cairo, shaped by Ibn Khaldūn’s concepts of <em>ʿumrān</em> and political change. The case rests on their intellectual relationship, shared Fāṭimid position, borrowed categories, and the city’s material record of rise and decline—while the unfinished “reasons for ruin” section qualifies a claim of perfect systematic realization.',
 sec20,
 [('Ibn Khaldūn','Historian and theorist of <em>ʿumrān</em>; admired teacher of al-Maqrīzī.'),('Al-Maqrīzī','Mamluk-era historian of Cairo (1364–1442), author of the <em>Khiṭaṭ</em>.'),('Khiṭaṭ','Short name of <em>al-Mawāʿiẓ wa-l-iʿtibār bi-dhikr al-khiṭaṭ wa-l-āthār</em>; an urban topographical and historical work.'),('Muqaddima','Ibn Khaldūn’s foundational introduction praised by al-Maqrīzī.'),('ʿUmrān','Human settlement, social organization and civilization.'),('Shaykhunā','“Our master”; al-Maqrīzī’s address for Ibn Khaldūn.'),('Nadīm','Court companion or boon companion; a position al-Maqrīzī reportedly held.'),('Muḥtasib','Market supervisor; office al-Maqrīzī lost in May 1405.'),('Ḥunafāʾ','The “true believers” invoked in al-Maqrīzī’s title and fairness appeal.'),('Kanh','Essence or intrinsic nature of a phenomenon.'),('Ḥaqīqa','Reality of what occurred.'),('Ḥāl','Condition or historical state.'),('Aṣl','Origin, foundation or root.'),('ʿAṣabiyya','Social/group cohesion; treated as weakening among late Mamluks.'),('ʿIbra','A lesson drawn from historical changes and ruins.')],
 T(['Test','Evidence in the supplied explainer','What it establishes'],[
  ['Relationship','1383 instruction, logic study, shared patrons, 1405 office losses','Close intellectual and courtly association'],
  ['Historiographic disposition','Fāṭimid ancestry accepted; <em>Ittiʿāẓ al-ḥunafāʾ</em> urges fairness','Willingness to question sectarian inherited judgments'],
  ['Analytical language','<em>Kanh</em>, <em>ḥaqīqa</em>, <em>ḥāl</em>, <em>aṣl</em>','Conceptual method rather than bare monument lists'],
  ['Urban demonstration','Ṭūlūnids, Fāṭimids and Mamluks','Cairo’s growth and ruin read through dynastic fortunes'],
  ['Qualification','Incomplete planned seventh part; moral polemics against Mamluks','Not every claim of a finished theory can be taken at face value']])['html'],
 mem20,
 [('Thesis','In what sense does the <em>Khiṭaṭ</em> qualify as a Khaldūnian history?'),('Evidence','Assess what the 1383 relationship and 1405 parallel loss of posts do and do not prove.'),('Source analysis','Why did shared acceptance of Fāṭimid descent matter to both historians?'),('Conceptual','Explain <em>kanh</em>, <em>ḥaqīqa</em>, <em>ḥāl</em> and <em>aṣl</em> as historical questions.'),('Comparison','Compare the Ṭūlūnid, Fāṭimid and Mamluk urban episodes.'),('Critical','How does the unfinished “reasons for ruin” section qualify the thesis?'),('Essay','Analyze the interaction between love of Egypt, the science of <em>ʿumrān</em>, and the didactic function of ruins.')],
 'The explainer argues that al-Maqrīzī’s <em>Khiṭaṭ</em> turns Cairo from an inventory of buildings into a record of social causation. The relationship with Ibn Khaldūn begins in 1383 with logic studies and shared Mamluk patronage, culminating in close office losses in 1405. Both defend the possibility of legitimate Fāṭimid descent against sectarian denunciation. Al-Maqrīzī praises the <em>Muqaddima</em> and deploys questions of essence, reality, condition and origin. Cairo’s successive Ṭūlūnid, Fāṭimid and Mamluk landscapes then become evidence of changing rule and social cohesion. His intended but unfinished section on ruin and his polemical treatment of Barsbāy invite a qualified judgment: a Khaldūnian historical project, not an unproblematic mechanical application of theory.',
 [('Question','Can urban topography be an explanatory history?'),('Relationship','Logic lessons and shared patrons; different public acknowledgment.'),('Shared stance','Both accept Fāṭimid genealogy against hostile historiography.'),('Method','<em>Kanh / ḥaqīqa / ḥāl / aṣl</em>: essential nature, fact, circumstance and origin.'),('Cairo','Ṭūlūnid building/destruction; Fāṭimid crises; Mamluk deterioration.'),('Limit','Unfinished ruin section and moral denunciation require historical discrimination.')],
 '#A26C55','1pb1mL3W-sB1sRFl5fke_MQPRIm5txAcfhCVt584Hjwc','maqrizi-khitat-khaldunian-history')

sec21=[
 S('Reading Family Law Through Doctrine and Daily Practice',
  P('The explainer treats <strong>marriage, divorce and inheritance</strong> as a meeting point of formal jurisprudence, enforceable legal claims, local social strategies and moral duties. <em>Furūʿ al-fiqh</em> manuals present what jurists prescribe; <strong>court records, fatwās and notarial texts</strong> show how people negotiated those prescriptions. No school is a perfect proxy for every premodern household, and an example of strategic practice is not automatically a universal rule.',
    ('concept','The method · Rules versus use','Prescriptive <em>fiqh</em> texts tell us the rule; descriptive documents disclose negotiation and enforcement.'),
    ('memory','Memory · P / D / M','<strong>Prescriptive rules → Descriptive records → Moral duties.</strong> All three are needed to interpret family life.')),
  P('Juristic compulsion and ethical expectation were not identical. A judge might enforce maintenance or a dower debt without enforcing every duty to act generously, love one’s kin or behave according to religious virtue. Other discourses—<strong>Sufism, <em>akhlāq</em>, and the <em>sunna</em></strong>—also influenced household conduct. The contrast between legal rule and lived practice is the thread linking all three topics.',
    ('mistake','Avoid one-system thinking','“Islamic law” here is not a single court rule, nor the complete account of a person’s moral obligations.'))),
 S('The Marriage Contract: Consent, Walī and Safeguards',
  P('Classical marriage is described as requiring a spoken contract, appropriate consent, <em>mahr</em> (dower), witnesses and public acknowledgment, while schools disagreed about the guardian (<em>walī</em>) and the force of a bride’s consent. The distinction between <em>bikr</em> (virgin) and <em>thayyib</em> (previously married/non-virgin) affects those positions. The source assigns adult Ḥanafī and Imāmī women the ability to contract independently; the Mālikī, Shāfiʿī and generally Ḥanbalī positions give the guardian a more necessary role. In the supplied comparison, an adult Shāfiʿī virgin’s express consent is recommended but is not always a validity condition, while Mālikī and Ḥanbalī traditions may treat silence as permission; non-virgin women require express permission.',
    ('definition','Walī / mahr','<em>Walī</em> = marriage guardian; <em>mahr</em> = dower owed in the marriage contract.'),
    ('highyield','Consent varies across legal schools','For adult previously married women, the supplied comparison requires explicit permission across all listed schools; differences are sharper for virgins and the guardian’s role.')),
  T(['School','Walī (adult)','Virgin consent','Non-virgin consent'],[
   ['Ḥanafī','Independent','Required','Required'],
   ['Imāmī','Independent','Required','Required'],
   ['Mālikī','Required','Advised; silence','Express consent'],
   ['Shāfiʿī','Required','Advised','Express consent'],
   ['Ḥanbalī','Generally required','Silence may suffice','Express consent']]),
  P('Guardianship was constrained by <em>shafaqa</em> (care) and <em>kufʾ</em> (suitability of a spouse). Where a guardian refused a suitable marriage because of hostility, a woman could seek <strong>judicial intervention</strong>, including substitution of the judge as guardian. This illustrates how apparently restrictive doctrine could also supply a procedural response to misuse of guardianship.',
    ('definition','Shafaqa / kufʾ','<em>Shafaqa</em> is caring guardianship; <em>kufʾ</em> a suitable marriage match.'),
    ('examtip','Use the table comparatively','Name the school, the woman’s legal status and the role of the judge, rather than declaring a single rule for “Islamic marriage.”'))),
 S('Mahr, Nafaqa and the Economics of Married Life',
  P('The source describes marriage in juristic terms as an <strong>exchange</strong>: lawful sexual access is associated with dower and continued availability with <em>nafaqa</em> (maintenance). Some jurists compared maintenance to compensation for foregone earning opportunities, as in the wages of judges or tax collectors. This doctrinal model does not settle every question about affection, actual earning or domestic cooperation.',
    ('definition','Nafaqa / ḥāll','<em>Nafaqa</em> is spousal maintenance; <em>ḥāll</em> is the portion of dower debt due on demand.'),
    ('concept','Rights can carry monetary leverage','In the supplied Mamluk cases, payment claims gave wives practical bargaining power within the marriage.')),
  P('In Mamluk Egypt, direct provision increasingly became cash support. The <strong>payable <em>ḥāll</em> dower debt</strong> could be demanded by a wife; refusal could lead to a husband’s imprisonment. Ibn al-Qayyim complains of husbands languishing in jail while wives pursued them for debts. The source treats this “monetization” as leverage that could discourage a husband’s unilateral <em>ṭalāq</em>. It was not simply a token exchange at the wedding.',
    ('memory','Memory · Dower / maintenance / leverage','<strong>Mahr is owed → ḥāll may be demanded → enforcement affects bargaining.</strong>'),
    ('highyield','Mamluk example','A legal debt could alter household power without rewriting the doctrinal formulation of unilateral divorce.')),
  P('The discussion also attributes to wives a right to sexual satisfaction; it cites Prophetic guidance emphasizing foreplay and conversation rather than brutal intercourse. Most jurists in this account did <strong>not</strong> make ordinary housework a court-enforceable obligation, though it might remain a social custom or a non-litigable religious duty conditioned by status and class.',
    ('mistake','Moral expectation is not court enforcement','Do not infer that every culturally expected household task could be compelled by a judge.'))),
 S('Dissolution: Ṭalāq, Khulʿ and Faskh',
  P('Three routes to divorce coexist. <strong>Ṭalāq</strong> is unilateral termination by the husband, commonly out of court in Sunni descriptions; the explainer notes Shīʿī requirements of witnesses and an appropriate formula. <strong>Khulʿ</strong> is a negotiated separation initiated by the wife, commonly exchanging a return or waiver of dower/maintenance for release. <strong>Faskh</strong> is judicial dissolution for grounds including failure to maintain, abandonment or <em>ḍarar</em> (harm). The source calls khulʿ the most common divorce in the historical practice it describes.',
    ('definition','Three procedures','<strong>Ṭalāq:</strong> husband’s unilateral act. <strong>Khulʿ:</strong> negotiated release. <strong>Faskh:</strong> court-granted dissolution.'),
    ('memory','Memory · T / K / F','<strong>Ṭalāq — unilateral; Khulʿ — negotiated; Faskh — judicial.</strong>')),
  T(['Procedure','Primary route','Important qualification'],[
   ['<em>Ṭalāq</em>','Husband exercises unilateral repudiation','Sunni and Shīʿī witnessing/formal rules differ in the source'],
   ['<em>Khulʿ</em>','Wife bargains for release with financial concession','Can involve return of <em>mahr</em> or waiver of <em>nafaqa</em>'],
   ['<em>Faskh</em>','Judge dissolves for established cause','Lack of maintenance, abandonment, <em>ḍarar</em>']]),
  P('Premodern legal agency also operated at the outset of marriage. The explainer follows Amalia Zomeño’s work on Mālikī Spain: women negotiated conditions against a second wife or concubine, absence exceeding six months, physical or financial mistreatment, compulsory relocation and restrictions on visiting relatives. Breach could trigger an <strong>option of divorce</strong>; the strategy turned a prospective fear into a contractually legible claim.',
    ('highyield','Five stipulations in Mālikī Spain','No co-wife, long absence, mistreatment, forced move or blocked family visits.'),
    ('examtip','Do not mistake stipulation for universal law','These provisions illustrate documented negotiating practice, not a mandatory clause in every marriage.'))),
 S('Ḥaḍāna: Custody Is a School-Specific Question',
  P('The source distinguishes divorce procedure from <em>ḥaḍāna</em> (custody). The point at which maternal custody ends varies by school and by a child’s sex. Its comparison assigns Ḥanafīs seven years for boys and puberty for girls; Mālikīs puberty for boys and marriage for girls; Shāfiʿīs/Ḥanbalīs a child’s discernment and choice; and Imāmīs two years for boys and seven for girls. These figures are <strong>the positions reported in the supplied explainer</strong>, not a statement of current law.',
    ('definition','Ḥaḍāna','Custody or care of the child following marital dissolution; the school and child’s status affect the rule.'),
    ('memory','Memory · Custody ages','<strong>Ḥanafī 7/puberty; Mālikī puberty/marriage; Imāmī 2/7; Shāfiʿī–Ḥanbalī discernment.</strong>')),
  T(['School','Boys','Girls'],[
   ['Ḥanafī','7 years','Puberty'],
   ['Mālikī','Puberty','Marriage'],
   ['Shāfiʿī / Ḥanbalī','Age of discernment (child’s choice)','Age of discernment (child’s choice)'],
   ['Imāmī Shīʿī','2 years','7 years']]),
  P('This custody comparison reinforces the larger methodological point: the historical tradition contains <strong>distinct doctrinal options</strong> and lived arrangements. A formal rule about maternal custody neither tells us who raised every child nor removes the need to consult court documents and private agreements.',
    ('mistake','School rules are not household statistics','A doctrinal endpoint is not evidence that all mothers or children actually followed it.'))),
 S('Farāʾiḍ: Shares, Agnates and the One-Third Bequest',
  P('Inheritance law is organized around <strong><em>farāʾiḍ</em></strong>, the prescribed fractional shares in the Qurʾān. The source treats this as a change from older tribal patterns excluding women. In the Sunni system, designated <strong>sharers</strong> take fixed portions before an agnatic remainder passes to <em>ʿaṣaba</em>—relatives linked through male ties. In the Twelver Shīʿī system described here, agnates do not enjoy the same residual priority: maternal and paternal kin are placed more comparably, sometimes benefiting female relatives who might otherwise lose to a distant male cousin.',
    ('definition','Farāʾiḍ / ʿaṣaba','<em>Farāʾiḍ</em> = prescribed shares; <em>ʿaṣaba</em> = male-line agnates inheriting the residue in the Sunni model.'),
    ('concept','Sunni / Twelver difference','The treatment of residuary agnates—not the existence of fractional shares alone—is a decisive distinction.')),
  P('A <strong><em>waṣiyya</em></strong> (testamentary bequest) could direct up to <strong>one-third</strong> of an estate to a non-heir. The rest remained within the inheritance framework. The one-third ceiling is thus an important measure of choice within a fixed-share system—not a permission to replace that system altogether.',
    ('memory','Memory · Shares / residue / third','<strong>Fixed sharers → (Sunni) agnatic residue → one-third limit on a non-heir bequest.</strong>'),
    ('examtip','Separate the inheritance models','State what counts as a sharer, what happens to the residue and why Twelver treatment of agnates matters.'))),
 S('The Practical Art of Keeping or Redirecting Property',
  P('Families faced a conflict between fractional succession and the wish to keep an estate together or secure a particular dependent. They therefore used <strong><em>waqf ahlī</em></strong> (family endowment), lifetime <strong><em>hiba</em></strong> (gifts), and nominally priced sales. These are not the same legal instrument: a waqf places assets in an endowment, a gift transfers property in life, and a sale creates a transfer framed as exchange.',
    ('definition','Waqf ahlī / hiba','Family endowment / inter vivos gift; two distinct means of directing property outside a straightforward death-time distribution.'),
    ('highyield','Practice could advantage or disadvantage women','The source notes both exclusions and Moroccan endowment deeds granting women more than their fixed shares.')),
  P('In <strong>fourteenth-century Morocco</strong>, some endowment deeds provided women more than their Qurʾānic shares, though other waqfs excluded them. A striking <strong>twelfth-century Cordoban</strong> case concerns a grandmother who “sold” her house at an artificially low price to her granddaughter’s fiancé, on condition that he pass it to the granddaughter as her <em>mahr</em>. The arrangement effectively excluded the grandmother’s son. This shows property strategy operating through the interaction of family preferences, dower and sale forms.',
    ('memory','Memory · W / H / S','<strong>Waqf — Hiba — Sale.</strong> Three routes used to manage property beyond ordinary inheritance division.'),
    ('examtip','Explain the Cordoban chain','Grandmother → low-price sale to fiancé → house passed to granddaughter as <em>mahr</em> → son loses prospective share.')),
  P('The broader conclusion is not that legal doctrine was ineffective. Its <strong>enforceable rights supplied the very tools</strong> that families used to obtain marriages, dissolve them and redirect wealth. Read a manual beside contracts, court decisions and local practice, and marriage, divorce and inheritance emerge as a negotiated social order rather than either rigid mathematics or unlimited personal freedom.',
    ('concept','The paradox of the “living law”','Negotiation often operated through legal forms; it was not simply an escape from law.')))
]
mem21=[
 (1,'P / D / M','<strong>Prescriptive rules → Descriptive records → Moral duties.</strong>'),
 (3,'Dower / maintenance / leverage','<strong>Mahr is owed → ḥāll may be demanded → enforcement affects bargaining.</strong>'),
 (4,'T / K / F','<strong>Ṭalāq — unilateral; Khulʿ — negotiated; Faskh — judicial.</strong>'),
 (5,'Custody ages','<strong>Ḥanafī 7/puberty; Mālikī puberty/marriage; Imāmī 2/7; Shāfiʿī–Ḥanbalī discernment.</strong>'),
 (6,'Shares / residue / third','<strong>Fixed sharers → (Sunni) agnatic residue → one-third limit on a non-heir bequest.</strong>'),
 (7,'W / H / S','<strong>Waqf — Hiba — Sale.</strong> Three routes to manage assets outside the simplest succession pattern.')]
# The endowment example, not its general introduction, owns the women’s-shares cue.
sec21[6]['items'][1]['notes'].append(sec21[6]['items'][0]['notes'].pop(1))
res21=build(21,'Marriage, Divorce, and Inheritance in Classical Islamic Law and Premodern Practice',
 'Between Doctrine and Practice: The Architecture of Classical Islamic Family Law',
 'Classical family law in the supplied explainer is both a technical juristic structure and a lived practice of bargaining. Differences among schools, moral expectations that courts could not compel, contractual rights, financial claims, and property-planning techniques explain how women and men navigated marriage, divorce, custody and inheritance without reducing the tradition to a single inflexible code.',
 sec21,
 [('Furūʿ al-fiqh','Prescriptive books of detailed juristic rulings and commentary.'),('Fatwā','Juristic responsum; one source for understanding how law was applied.'),('Walī','Guardian involved in contracting a woman’s marriage; role varies by school.'),('Bikr / thayyib','Virgin / previously married or non-virgin status relevant to marriage consent.'),('Mahr','Dower owed under the marriage contract.'),('Nafaqa','Support or maintenance due within marriage.'),('Ḥāll','Portion of the dower payable upon demand.'),('Shafaqa / kufʾ','Caring guardianship / suitability of a marriage match.'),('Ṭalāq','Unilateral divorce initiated by the husband.'),('Khulʿ','Negotiated divorce involving financial concession by the wife.'),('Faskh','Judicial dissolution of marriage for cause.'),('Ḍarar','Harm or mistreatment; a ground for judicial remedy.'),('Ḥaḍāna','Custody, subject to school-specific rules.'),('Farāʾiḍ','The system of fixed inheritance shares.'),('ʿAṣaba','Male-line agnatic residuary kin in Sunni distribution.'),('Waṣiyya','Testamentary bequest, subject here to a one-third ceiling for non-heirs.'),('Waqf ahlī','Family endowment used to retain and redirect wealth.'),('Hiba','Gift transferring property during the donor’s lifetime.')],
 T(['Domain','Prescription','Practice and negotiated mechanism'],[
  ['Marriage','Guardian, consent, <em>mahr</em> and public contract vary by school','Judge may replace obstructive guardian; contract stipulations'],
  ['Support','<em>Nafaqa</em> and payable <em>ḥāll</em> dower debts','Mamluk women used debt enforcement to strengthen bargaining'],
  ['Dissolution','<em>Ṭalāq / khulʿ / faskh</em>','Negotiated release and judicial remedies coexist with unilateral divorce'],
  ['Custody','School-specific ages or child’s discernment','Documents needed to know actual placement of children'],
  ['Inheritance','<em>Farāʾiḍ</em>, sharers and agnatic residue; one-third bequest','<em>Waqf ahlī</em>, <em>hiba</em>, carefully arranged sales']])['html'],
 mem21,
 [('Method','Why must prescriptive <em>furūʿ al-fiqh</em> be read with descriptive legal records?'),('Comparison','Contrast the requirements for a <em>walī</em> among the five listed schools.'),('Economics','Explain how <em>ḥāll</em> dower debts could affect marital bargaining.'),('Procedure','Distinguish <em>ṭalāq</em>, <em>khulʿ</em> and <em>faskh</em>.'),('Application','How did Mālikī contract stipulations allow wives to anticipate future problems?'),('Comparison','What differs between Sunni <em>ʿaṣaba</em> and Twelver succession?'),('Case study','Analyze the Cordoban grandmother’s low-price house sale and its legal effects.'),('Essay','Show why a negotiated practice can arise from law’s own tools rather than in spite of law.')],
 'The explainer treats classical family law as a relationship between authoritative doctrine and negotiated practice. Juristic manuals give distinct rules about consent, guardianship, maintenance, divorce, custody and prescribed inheritance shares, while records of contracts, fatwās and litigation reveal how these rules were used. The bride’s consent and the guardian’s authority vary by school, subject to safeguards of care and suitability. Marriage involves dower and maintenance, and the enforceable <em>ḥāll</em> debt could provide material leverage in Mamluk Egypt. Separation could come by <em>ṭalāq</em>, negotiated <em>khulʿ</em> or judicial <em>faskh</em>; women also used advance contractual stipulations. Custody rules and Sunni versus Twelver inheritance arrangements differed. The one-third bequest ceiling, family waqfs, lifetime gifts and even nominal sales show how families planned property transfers. The result is a historically contingent “living law,” not the absence of binding doctrine.',
 [('Method','Prescriptive manuals and descriptive records illuminate different aspects of life.'),('Marriage','Walī / consent / mahr / safeguards must be specified by school.'),('Economics','Nafaqa and ḥāll debts can change bargaining power.'),('Divorce','Ṭalāq, khulʿ and faskh offer different legal routes.'),('Children','Ḥaḍāna endpoints vary by school and sex.'),('Succession','Farāʾiḍ; Sunni ʿaṣaba versus Twelver treatment; waṣiyya ≤ one-third.'),('Practice','Waqf, gift and nominal sale reflect household strategies.')],
 '#568074','19S3zpAWrL4_qERuBmm58QV9-3i5nYnpulCZfjB7bz_s','marriage-divorce-inheritance-islamic-law')

manifest={'batch':'20-21','source':'Two supplied Google Drive original explainer documents, preserved as unedited source files',
'source_ids':{'20':'1pb1mL3W-sB1sRFl5fke_MQPRIm5txAcfhCVt584Hjwc','21':'19S3zpAWrL4_qERuBmm58QV9-3i5nYnpulCZfjB7bz_s'},
'stats':[res20,res21],
'source_sha256':{str(n):hashlib.sha256((ROOT/'sources'/f'{n:02d}-raw-explainer.txt').read_bytes()).hexdigest() for n in [20,21]},
'policy':'Content compression only: 5 main pages as soft target, 6 where needed; fonts, spacing, page-breaks, tables and compositor unchanged; six revision sections per reading. Reading 19 remains null.'}
(ROOT/'NEW_READINGS_20_21_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
