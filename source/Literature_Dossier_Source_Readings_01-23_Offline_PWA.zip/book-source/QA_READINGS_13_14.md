# Literature Dossier — Verified Manual Release 13–14

**Date:** 4 November 2026  
**Edition:** Complete readings 01–14, condensed editorial text, passage-linked six-category sidebar, 16:9 landscape print.  
**Status:** Passed production/export and new-chapter checks; one pre-existing full-book anchor exception documented below.

## Source and editorial decisions

- **Reading 13 — The Book Thief (Part 1)** was authored from Drive Google Doc `1inuwDEkCWK5Y84J9Sj-GeWhbsP1m8WLmSn0kTqsvc9E`. Raw text saved byte-for-byte to `sources/13-raw-explainer.txt` (8,728 bytes). The **4-page main discussion** retains the dates of April/May 1941; hiding Max at 33 Himmel Street; the Liesel–Max haircut and hair disposal; roles of Hans and Rosa; the secret in the mouth; `Molching Express`, newspapers, crosswords and the contrast with music; sky metaphor and wall painting; the unequal imagined boxing match, Goebbels, brown eyes, Hitler's verbal jewels, and the crowd; Liesel's interrupting crossword; and the ethical double edge of language. Its two main evidence tables compare the fighters and the four transformed domestic objects. The overlapping standalone conclusion was condensed into §13.6, with the complete synthesis retained in Revision 1.
- **Reading 14 — Textual Endings as Persuasive Educational Beginnings** was authored from Drive Google Doc `16txWg8e2Gd-e2YtRho9Z-4MjdsdEZsQ6EqW603YDlxQ`. Raw text saved unchanged to `sources/14-raw-explainer.txt` (9,529 bytes). The **5-page main discussion** covers anonymous Brethren and epistemic/pedagogical goals; potential and actual knowledge; the four epilogue functions of Epistle 7; practical crafts, unseen spiritual agency, and Divine Law in Epistle 8; the animal-human trial, King of the Jinn, concluding praise and prayer in Epistle 22; the logos/ethos/pathos framework and al-Fārābī; and *maqnaʿ wa-kifāya* and four persuasive ending functions in Epistle 52. Two tables preserve the theoretical/practical contrast and three rhetorical appeals. The repeated final recap was integrated into §14.7; a full comparative synthesis remains in Revision 1.
- A **five-main-note-page target is editorial, not compulsory**. Main prose stands alone if the sidebar is skipped. No source explainer was overwritten; both source texts are archived for scholarly checking. The documents are explanatory material provided by the user, not verified originals of the scholarly texts or literary work.

## Chapter-level figures

| Category | Reading 13 | Reading 14 |
|---|---:|---:|
| Main-note sheets | **4** | **5** |
| Main sections | 6 | 7 |
| Passages | 14 | 17 |
| Sidebar cards | 20 | 25 |
| Six semantic classes present | 6 | 6 |
| Memory devices introduced beside the relevant passage | 5 | 6 |
| Memory aids repeated in revision | 5 | 6 |
| Main tables | 2 | 2 |
| Dark revision sections | 6 | 6 |
| Standalone PDF physical sheets (cover + opener + main + revision) | 10 | 11 |

## PDF/pagination results

| Export | Physical pages | Real bookmarks | Contents links | Detected overflow |
|---|---:|---:|---:|---:|
| Full 01–14, offline fonts | **146** | **218** | **14** | 0 |
| Batch 13–14, offline fonts | **21** | **31** | **2** | 0 |
| Batch 13–14, alternate font metrics | 23 | 31 | 2 | 0 |
| Reversed selection `14,13` without revision zones | 13 | 17 | 2 | 0 |

- Physical pages and compositor logical pages match; every page measures **960 × 540 PDF pt** (16:9) with no browser JavaScript errors.
- True PDF bookmarks are persisted, valid, and requested open in the viewer's Outline panel; Contents links point at the new chapter openers.
- Full edition includes an embedded Arabic typeface for prior chapters with Arabic script; the selected 13–14 pair does not use Arabic-script passages and therefore does not require that font subset.
- **All 45 new note cards (20 + 25) appear on pages containing their exact source passages**; no duplicate IDs, misplaced new cards, or missing semantic category. Mobile at 390 px has no document-width overflow.
- Complete-book audit: **254 cards printed**, **253 exact matches** under the offline-font profile. One **inherited** Reading 04 card, `s4-6-n2` (Al-Faramā two-lenses memory aid), is printed on the next page, whose main narrative contains `s4-6-p2` onward rather than its assigned `s4-6-p1`. This issue was already present in a pre-existing chapter, and fixing it would alter the user's locked 01–12 source or compositor. It is transparently flagged rather than mislabeled a new-batch QA pass.
- Existing **twelve chapter files, twelve raw sources, and seven shared publisher files are byte-identical** to the supplied verified 01–12 ZIP, checked by 31 SHA-256 hashes. The tests for new chapters and both local source hashes passed.
- Rendered PDF contact sheet and representative full-size sheets were visually inspected. Main prose measure, section spacing, tables, typography, footer and sidebar colors were not changed.
- The alternate-font test confirms resilience but may produce different pagination than the offline-font deliverable; exact PDF pagination should be revalidated whenever the original intended web fonts become available.

## Reproduce and continue

Extract `Literature_Dossier_Source_Readings_01-14_Editorial.zip`, then run:

```bash
cd book-source
python build.py
python export_bookmarked.py --chapters 13,14 --font-profile offline --out output/recheck_13_14.pdf
python export_bookmarked.py --font-profile offline --out output/recheck_01_14.pdf
python tests/test_readings_13_14.py
```

`progress.json`, `NEW_READINGS_13_14_MANIFEST.json`, `PRE_13_14_HASHES.json` and `QA_READINGS_13_14_MACHINE.json` record the new checkpoint. **Next manual batch is Readings 15 and 16.** Reading 19 is still reserved and the hourly automation remains disabled.
