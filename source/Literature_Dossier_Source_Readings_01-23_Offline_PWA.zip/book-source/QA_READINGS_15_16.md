# Literature Dossier — Readings 15 and 16, manual production QA

**Release:** 2026-11-04 · **Status: PASS for new material; one inherited offline-font exception in Reading 04 remains**.

## Source and scope

- **15** — *The Dāʾūdī Bohras (Mustaʿlī Ismāʿīlī Shīʿa) Using Modernity to Institutionalise a Fāṭimid Tradition*. Supplied Google Doc `1HT4NM_rlhy2RrY_TSd3uL0AxTTZW89Jb6SUFmcvlwp8`; untouched text saved in `sources/15-raw-explainer.txt` (10,048 bytes, SHA-256 `b4f2981ac2c939ebd76042ede1aa4c2fe217bd0ddc1b7fc09233d3923125a74a`). Main notes: **5 pages**, 7 sections, 16 anchored passages, 2 comparison tables, 23 sidebar cards, 5 memory aids mirrored at the end, and 6 revision subsections. Key distinctions retained: hidden Imām/Dāʿī, ẓāhir/bāṭin/taʾwīl, Yemen→India migration, 1915 education policy, source-bound 72× computer ownership figure, 1975 37% figure, 1979/1981 dress directives, digital organization and surveillance, 2014 succession debate, khatna reform, Jamea-tus-Saifiyah and female professional education.
- **16** — *Shuʿūbiyyah in Arabic Literature*. Supplied Google Doc `1MrcsG73ToWGKKEO1TPLxJpTbd0yC32hnmH9r6NRdufI`; untouched text saved in `sources/16-raw-explainer.txt` (10,127 bytes, SHA-256 `046b6e866ad7d50c80609375d33bdcda2715a9a2eb5163836fa9c47f7954c057`). Main notes: **6 pages** (justified by the range of historical/literary positions), 8 sections, 18 anchored passages, 3 comparison tables, 26 sidebar cards, 6 memory aids mirrored at the end, and 6 revision subsections. Key distinctions retained: ʿaṣabiyyah and Qays–Kalb rivalry, Yemeni/Copt and Khārijī arguments, mawālī/kuttāb and Sasanian influence, three rival positions including ahl al-taswiyah, mathālib/eloquence/weaponry examples, zandaqah accusation, Nabaṭ/Babylonian literary memory, Sarah–Hagar counterargument, Ibn García's Andalusian polemic, al-Zamakhsharī and the Arabic-medium paradox. Abusive ethnic stereotypes are carefully attributed as polemical testimony, not factual description.

**Text provenance:** These Google Docs are supplied *explainers*, not independently acquired publications. The notes follow their arguments while consolidating repetition. Claims, quotations and quantities are represented as source claims; figures tied to a past sample are not presented as current statistics. This process did **not** independently validate the source's historical statements against original academic texts.

## Editorial and preservation checks

- 01–14 chapter files and the shared `styles.css`, `engine.js`, `build.py`, `export_bookmarked.py`, `cover.html`, `head-template.html`, `course_index.json` are **byte-for-byte identical** to the 01–14 canonical ZIP (21 checked files).
- All six sidebar categories occur in each new reading: definition, concept, exam tip, common mistake, memory aid, high-yield fact.
- 49/49 new sidebar cards have unique stable IDs and render on the same page as their **exact** `data-anchor` passage. No missing/duplicated cards or misplaced new notes.
- 5 memory-aid bodies in 15 and 6 in 16 match their respective recap copies **exactly**. Six revision sections per chapter; main evidence tables retained in the prose area rather than being squeezed into sidebar cards.
- No change to typography, spacing, page-break rules, print page geometry, or publisher scripts. Reading 16 was deliberately allowed six main pages under the flexible target.

## Export and layout checks

| Export | Physical/logical sheets | Real PDF bookmarks | Contents links | Overflow | Status |
|---|---:|---:|---:|---:|---|
| Standalone 15 (no Contents) | 12 / 12 | 16 | 0 (by selection) | 0 | PASS |
| Standalone 16 (no Contents) | 13 / 13 | 17 | 0 (by selection) | 0 | PASS |
| Selected 15–16 | 25 / 25 | 33 | 2 | 0 | PASS |
| Complete 01–16 | 169 / 169 | 249 | 16 | 0 | PASS |
| 15–16 alternate font metrics | 26 / 26 | 33 | 2 | 0 | PASS |
| Reversed 16,15 without revision | 15 / 15 | 19 | 2 | 0 | PASS |

All pages are genuine 960×540-point widescreen sheets. The full PDF embeds Arabic-capable **Amiri**, and the HTML uses the existing font stack. Test exports use the `offline` font profile; the platform fallbacks, not separately supplied Spectral/Fraunces files, determine exact line wrapping. The alternate-metrics test confirmed no compositor overflow; individual page numbers could vary on another font installation. The 390-pixel mobile viewport does not horizontally overflow.

### Full-volume sidebar audit

The combined source contains **303 main-reading sidebar cards**. **302** render on a page with their exact linked passage; the single inherited exception is `s4-6-n2` attached to `s4-6-p1` in **Reading 04** under the offline font profile, already disclosed in the 13–14 checkpoint. The new chapters introduce **zero** additional exceptions. This earlier problem was left untouched rather than surreptitiously changing a prior chapter or the global engine.

## Reproducibility and recovery

Inside the source ZIP, `python build.py` rebuilds `output/book.html`. For PDFs use:

```bash
python export_bookmarked.py --chapters '1-16' --font-profile offline --out output/full.pdf
python export_bookmarked.py --chapters '15,16' --font-profile offline --out output/new_pair.pdf
python tests/test_readings_15_16.py
```

`generate_readings_15_16.py` regenerates **only** chapters 15 and 16; do not run older generators over edited earlier chapters. The portable ZIP includes raw source explainers, chapter HTML, publisher, checkpoint JSON and QA scripts. The next manual batch is **17–18**, while Reading 19 remains expressly reserved.
