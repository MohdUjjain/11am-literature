#!/usr/bin/env python3
"""Author Readings 03 and 04 from the user's supplied explanatory texts.

Retain all substantive original paragraphs, list items, headings and table cells.
Pedagogical callouts, visuals, and six revision subsections are additive.
No source article, independent fact-check, or outside historical claims are assumed.
"""
from pathlib import Path
from html import escape
import re
from bs4 import BeautifulSoup
from generate_initial_readings import md, callout, mark_arabic

ROOT=Path(__file__).resolve().parent
READINGS={
3: {'source':'03-raw-explainer.md','file':'03-learning-grammar-of-animacy.html',
    'title':'Learning the Grammar of Animacy',
    'subtitle':'The Grammar of Animacy · How Language Shapes Our Relationship with the Living World',
    'thesis':'The source contrasts a language that classifies nature as objects with a grammar that recognizes living presences; linguistic choices become questions of relationship, memory and responsibility.',
    'roadmap':['The forest and the meaning of Puhpowee','Scientific precision versus the presence of other beings','Assimilation, endangered language and the nine chairs','Verb-based grammar: wiikwegamaa and animacy','The ethics of “it,” Yawe and personhood','Speaking through the heart: an ecological conclusion'],
    'accent':'#527B32'},
4: {'source':'04-raw-explainer.md','file':'04-al-afdal-crusade-and-vizierate.html',
    'title':'Al-Afḍal b. Badr al-Jamālī, the vizierate and the Fatimid response to the First Crusade',
    'subtitle':'The Sword, the Pen, and the Performance of Power',
    'thesis':'Al-Afḍal’s historical image emerges from a struggle between contemporary praise for martial authority and later narratives portraying him as irrational; the reading examines how gendered political ideals shaped the evidence.',
    'roadmap':['Muruwa, adab and the medieval ideal of self-governing masculinity','Inherited military authority and retrospective categories','Three hostile anecdotes about jealousy, prisoners and succession','Jihād rhetoric and the performance of military competence','The 1118 al-Faramā raid in conflicting accounts','What competing narratives reveal about historical memory'],
    'accent':'#417B32'},
}

# Place note clusters beside the passages they illuminate. Deliberately compact;
# long teaching explanations remain in the preserved source paragraphs.
CALLOUTS={
3:{
 1:[('definition','Puhpowee','The Potawatomi term in the explainer denotes the <strong>force causing mushrooms to rise overnight</strong>, rather than a taxonomic species name.'),('memory','One-word image','<strong>Puhpowee → push upward.</strong> Picture a mushroom rising through forest duff; attach the word to emergence, not identification.'),('concept','The guiding opposition','“Collection of objects” versus “communion of subjects” is the argument’s governing contrast: grammar shapes relationship as well as description.')],
 2:[('concept','Precision does not equal presence','The narrator values the close observation enabled by scientific names, but argues that such naming can distance observers from other beings’ subjectivity.'),('examtip','State both sides of the dilemma','Do not misread the speaker as rejecting biology. Explain how scientific naming sharpens observation <em>and</em> may narrow the kinds of presence language can express.')],
 3:[('highyield','Nine chairs are a narrated historical scene','The speaker counts <strong>nine fluent speakers</strong> at the gathering described in the explainer. This is a figure within that recollection, not a verified present-day census.'),('definition','Bodewadmimwin','The Potawatomi language, described here as a repository of cultural memory, a worldview, humor and relationships.'),('memory','Nine chairs · nine voices','<strong>9 chairs → living linguistic inheritance at risk.</strong> Remember the scene and the consequences of boarding-school suppression.'),('mistake','Do not turn personal testimony into a current statistic','“Only nine fluent speakers” belongs to the source’s narrated moment. Do not quote it as the language’s verified speaker count in 2026.')],
 4:[('definition','Wiikwegamaa','“<strong>To be a bay</strong>”: the reading’s key illustration of expressing place as an active state rather than a static noun.'),('highyield','The source’s numeric contrast','The explainer compares English at <strong>30% verbs</strong> with Potawatomi at <strong>70% verbs</strong>. Attribute these figures to the supplied text.'),('memory','A bay becomes a verb','<strong>Bay (thing) → “to be a bay” (being).</strong> Use this contrast to recall why verbs matter to the grammar of animacy.')],
 5:[('definition','Yawe and animacy','<em>Yawe</em> is presented in the source as an animate form of “to be,” associated with breath and living presence.'),('mistake','Personhood is not anthropomorphism','The student debate distinguishes granting a nonhuman being moral standing from projecting specifically human traits onto it.'),('memory','Pronoun → ethical consequence','<strong>“It” → resource; “someone” → responsibility.</strong> A mnemonic for the passage’s ethical argument, not an empirical law of grammar.'),('concept','What the maple illustration tests','The contrast between “it” and “her” asks whether the language of objects makes exploitation easier to justify.')],
 6:[('memory','The elder’s two gestures','<strong>Lips → heart.</strong> Bill Tall Bull’s gesture asks the learner to place genuine relationship before fluent pronunciation.'),('examtip','Close by returning to the thesis','Connect Puhpowee, the nine chairs, verbal animacy, and the ethics of pronouns to the final idea: a world of coexisting subjects.')]
},
4:{
 1:[('concept','Two rival reputational scripts','The reading juxtaposes <strong>contemporary laudatory martial praise</strong> with a <strong>later hostile shadow narrative</strong> that interprets the same ruler through alleged passion.'),('memory','Praises and polemics','<strong>Praise → prowess; polemic → passion.</strong> This is the interpretive contrast organizing the entire reading.')],
 2:[('definition','Muruwa and adab','<em>Muruwa</em> is the historically idealized manliness of self-command; <em>adab</em> denotes cultivated conduct through which that status is performed.'),('mistake','Report the gender hierarchy, do not endorse it','The reading analyzes medieval writers’ gendered opposition between reason and passion. Their disparaging claims about women are <strong>historical rhetoric</strong>, not neutral descriptions.'),('examtip','Use the framework as a source-reading tool','Explain why later chroniclers selected jealousy and anger anecdotes: within their moral vocabulary those traits discredited political competence.')],
 3:[('concept','Beware retrospective administrative labels','The author warns that “Vizier of the Pen/Sword” and some delegation categories may be later analytical classifications projected backward onto Fāṭimid institutions.'),('highyield','Two signs of al-Afḍal’s early elevation','The explainer gives the title <em>ṣifwat amīr al-mu’minīn</em> at <strong>age 14 (c.1080)</strong> and an appearance in the <em>khuṭba</em> by <strong>1087</strong>.'),('memory','Courtly ascent · two markers','<strong>14 → title; 1087 → khuṭba.</strong> The milestones help recall a court upbringing rather than a battlefield career.')],
 4:[('highyield','A hostile numerical claim, not a verified count','The later story reportedly has <strong>100,000 prisoners</strong> released after al-Afḍal’s death. Treat the number as part of the hostile account, not confirmed administrative data.'),('memory','The shadow narrative in three episodes','<strong>Jealousy → Jail → Succession.</strong> The three anecdotes frame his emotions as unfit for rule.'),('examtip','Distinguish allegation from settled event','Use “later chroniclers allege” for the terrace incident, forgotten prisoners, and revenge-based explanation of the 1094 Nizārī schism.')],
 5:[('definition','Jihād as legitimating language','Here <em>jihād</em> functions in the source as a political-rhetorical marker of martial authority, not proof that al-Afḍal personally fought in each campaign.'),('memory','Three theatres of martial image','<strong>Alexandria → Jerusalem → Asqalān.</strong> Follow the three settings of contemporary praise.'),('mistake','Coordination is not personal combat','The passage distinguishes raising or coordinating armies from commanding in battle; do not convert propaganda into biography.')],
 6:[('concept','Two incompatible al-Faramā narratives','Contemporary praise stresses al-Afḍal’s <strong>coordination</strong>; later accounts foreground <strong>devastation, illness and Baldwin’s death</strong>.'),('highyield','The 1118 interpretive test','Al-Faramā is the same raid made to signify a successful Fatimid response in one account and the limits of that response in another.'),('memory','Al-Faramā · two lenses','<strong>State = strategy; later = suffering and Baldwin.</strong> Ask whose agency the narrator makes decisive.')],
 7:[('examtip','The strongest conclusion is historiographical','Answer not only what al-Afḍal did, but <strong>how different communities wrote about him</strong> and why descriptions of “manliness” carried political stakes.'),('concept','Historical image as performance','An image of rational martial command was constructed, challenged and remembered through contrasting sources rather than straightforwardly observed.')]
}}

# Main text may gain an additional comparison/visual, never replacing source evidence.
ADDITIONS={
3:{
 4:'''<div class="process-strip" role="group" aria-label="Noun and verb contrast"><div class="process-step"><span class="step-no">NOUN</span><strong>A bay</strong><small>A place represented as a thing</small></div><span class="process-arrow">→</span><div class="process-step"><span class="step-no">VERB</span><strong>Wiikwegamaa</strong><small>“To be a bay” · a state of being</small></div></div><p class="table-caption">A spatial visualization of the exact example already discussed in the source, not a replacement for its explanation.</p>''',
 5:'''<table data-pagination="repeat-header"><thead><tr><th>Expression in the reading</th><th>Interpretive effect</th><th>Question the author poses</th></tr></thead><tbody><tr><td>“It” · object/resource</td><td>Frames a being as usable matter</td><td>Who has moral standing?</td></tr><tr><td>“Someone” · subject/neighbor</td><td>Calls for recognition and responsibility</td><td>How should we relate to nonhuman beings?</td></tr></tbody></table><p class="table-caption">A comparison derived solely from the speaker’s pronoun argument.</p>'''
},
4:{
 3:'''<table data-pagination="repeat-header"><thead><tr><th>Time / evidence</th><th>Source-grounded significance</th></tr></thead><tbody><tr><td>1074</td><td>Badr’s military-administrative merger creates the inherited office.</td></tr><tr><td>c. 1080, age 14</td><td>Al-Afḍal receives a prestigious court title.</td></tr><tr><td>1087</td><td>His name appears in the <em>khuṭba</em>.</td></tr><tr><td>1094</td><td>Succession dispute later recast through personal hostility.</td></tr><tr><td>1098</td><td>Jerusalem’s recapture used in martial praise.</td></tr><tr><td>1118</td><td>Al-Faramā raid attracts contradictory historical frames.</td></tr></tbody></table><p class="table-caption">Chronology gathered from the explainer’s own dates; not an independent historical chronology.</p>''',
 6:'''<table data-pagination="repeat-header"><thead><tr><th>Dimension · 1118 raid</th><th>Contemporary state account</th><th>Later hostile account</th></tr></thead><tbody><tr><td>Who is central?</td><td>Al-Afḍal as organizer of a large army</td><td>Victims and Baldwin’s illness/death</td></tr><tr><td>Why did Franks retreat?</td><td>Fatimid mobilization and pressure</td><td>Baldwin’s fatal illness</td></tr><tr><td>What is the political effect?</td><td>Retains the image of martial strength</td><td>Undercuts the vizier’s military efficacy</td></tr></tbody></table><p class="table-caption">Comparison of the two interpretations described by the supplied text.</p>'''
}}

REVISIONS={
3:{
'Chapter Summary':'''<p>The explainer begins with <em>Puhpowee</em>, a Potawatomi word for the force of mushrooms rising, and asks what becomes visible when language treats the more-than-human world as <strong>subjects rather than objects</strong>. Scientific names permit precision, yet the narrator fears their distance can conceal living presence.</p><p>The history of boarding-school suppression makes linguistic loss an ethical and cultural crisis, embodied by the nine chairs at a tribal gathering. Potawatomi’s verb-focused structure and <em>wiikwegamaa</em> (“to be a bay”) exemplify a world understood as active being; <em>Yawe</em> and the rejection of the pronoun “it” extend that grammar into moral inclusion. Bill Tall Bull’s concluding gesture from lips to heart locates respect deeper than vocabulary alone.</p><p>These are arguments and first-person observations <strong>made by the supplied explainer</strong>; its language statistics and speaker count have not been externally verified for the present day.</p>''',
'One-Page Revision Sheet':'''<div class="revision-grid"><div class="revision-card"><h3>Opening question</h3><ul><li><em>Puhpowee</em> = a mushroom’s emergence force</li><li>Object-language versus subject-language</li><li>Science: precision and a potential distance</li></ul></div><div class="revision-card"><h3>Suppression and survival</h3><ul><li><em>Bodewadmimwin</em> is the Potawatomi language</li><li>Boarding-school punishment and assimilation</li><li>Nine speakers: narrated scene, not current census</li><li>Jim Thunder and “Spanawatomi”</li></ul></div><div class="revision-card"><h3>Grammar</h3><ul><li>Source: English 30% verbs; Potawatomi 70%</li><li>Animate / inanimate classification</li><li><em>Wiikwegamaa</em> = “to be a bay”</li><li>Be a Saturday / be a hill</li></ul></div><div class="revision-card"><h3>Ethics and ending</h3><ul><li>“It” can deny a relationship</li><li><em>Yawe</em> and animate being</li><li>Andy and Carla: personhood vs anthropomorphism</li><li>Lips → heart: Bill Tall Bull’s gesture</li></ul></div></div>''',
'Key Definitions':'''<table data-pagination="repeat-header"><thead><tr><th>Term</th><th>Meaning / role in the explainer</th></tr></thead><tbody><tr><td><em>Puhpowee</em></td><td>The force making mushrooms rise from the earth overnight.</td></tr><tr><td><em>Bodewadmimwin</em></td><td>Potawatomi language; repository of cultural relation and memory.</td></tr><tr><td><em>Grammar of animacy</em></td><td>Language framework that marks other beings as active presences/subjects.</td></tr><tr><td><em>Wiikwegamaa</em></td><td>“To be a bay”; verbal treatment of place as an ongoing state.</td></tr><tr><td><em>Yawe</em></td><td>Animate “to be,” invoked to describe living presence.</td></tr><tr><td>Anthropomorphism</td><td>Attributing human traits to nonhumans; distinguished from granting personhood.</td></tr><tr><td>“Spanawatomi”</td><td>Hybrid language practice used by learners to keep Potawatomi speech alive.</td></tr></tbody></table>''',
'Key Tables':'''<p>Recap the <strong>English/Potawatomi linguistic comparison</strong> in §3.4 and the <strong>“it”/“someone” ethical contrast</strong> in §3.5. Both are introduced and explained in the main text.</p><table data-pagination="repeat-header"><thead><tr><th>Contrast</th><th>First framing</th><th>Second framing</th></tr></thead><tbody><tr><td>Grammatical emphasis (source’s description)</td><td>English: nouns; 30% verbs</td><td>Potawatomi: verbs; 70% verbs</td></tr><tr><td>Representing water</td><td>Bay as object</td><td>“To be a bay” as becoming</td></tr><tr><td>Ethical pronoun</td><td>“It”: object/resource</td><td>“Someone”: subject/neighbor</td></tr></tbody></table>''',
'Memory Aids':'''<div class="callout-grid"><div class="callout callout--memory"><div class="tag">🟪 From §3.1</div><p><strong>Puhpowee → push upward.</strong> Picture a mushroom rising through forest duff; attach the word to emergence, not identification.</p></div><div class="callout callout--memory"><div class="tag">🟪 From §3.3</div><p><strong>9 chairs → living linguistic inheritance at risk.</strong> Remember the scene and the consequences of boarding-school suppression.</p></div><div class="callout callout--memory"><div class="tag">🟪 From §3.4</div><p><strong>Bay (thing) → “to be a bay” (being).</strong> Use this contrast to recall why verbs matter to the grammar of animacy.</p></div><div class="callout callout--memory"><div class="tag">🟪 From §3.5</div><p><strong>“It” → resource; “someone” → responsibility.</strong> A mnemonic for the passage’s ethical argument, not an empirical law of grammar.</p></div><div class="callout callout--memory"><div class="tag">🟪 From §3.6</div><p><strong>Lips → heart.</strong> Bill Tall Bull’s gesture asks the learner to place genuine relationship before fluent pronunciation.</p></div></div>''',
'Possible Examination Questions':'''<div class="exam-q"><span class="qtype">Short answer</span><p>What does <em>Puhpowee</em> mean, and why is the word the opening example?</p></div><div class="exam-q"><span class="qtype">Comparison</span><p>How does the narrator evaluate both the achievements and limits of scientific naming?</p></div><div class="exam-q"><span class="qtype">Context</span><p>Explain the nine-chair scene and the relation between boarding-school suppression and linguistic loss.</p></div><div class="exam-q"><span class="qtype">Linguistic example</span><p>What does <em>wiikwegamaa</em> illustrate about grammar, verbs and the status of place?</p></div><div class="exam-q"><span class="qtype">Debate</span><p>Distinguish anthropomorphism from the argument for nonhuman personhood in the Andy–Carla exchange.</p></div><div class="exam-q"><span class="qtype">Long essay</span><p>Trace the reading’s intellectual movement from forest observation to cultural survival, grammatical structure and ecological ethics.</p></div>'''
},
4:{
'Chapter Summary':'''<p>This reading asks how al-Afḍal’s memory was fashioned through contrasting medieval source traditions. A <strong>contemporary laudatory narrative</strong> made the court-trained vizier a defender whose military direction fulfilled the rational, martial ideal. Later Ayyubid and Mamluk writers supplied a <strong>shadow narrative</strong> of jealousy, impulsive imprisonment and vindictive succession politics—vices that their <em>muruwa</em>/<em>adab</em> framework gendered as unmanly.</p><p>Al-Afḍal inherited Badr’s combined executive-military powers despite lacking his frontier career. The source argues that <em>jihād</em> rhetoric and the Alexandria–Jerusalem–Asqalān record performed martial competence. The 1118 al-Faramā raid is a crucial controlled comparison: contemporaries credited his mobilization, whereas later historians emphasized devastation and Baldwin’s illness as the reason for the Frankish retreat.</p><p>The argument concerns not only the vizier’s decisions but how <strong>praise, political polemic and later memory construct judgments of power</strong>. Medieval gender stereotypes are objects of critical analysis, not claims endorsed by these notes.</p>''',
'One-Page Revision Sheet':'''<div class="revision-grid"><div class="revision-card"><h3>Central dispute</h3><ul><li>Contemporary praise: rational martial hero</li><li>Later polemic: irrational tyrant</li><li>Both judge performance against gendered ideals</li></ul></div><div class="revision-card"><h3>Moral vocabulary</h3><ul><li><em>Muruwa</em>: manliness through self-command</li><li><em>Adab</em>: refined conduct</li><li>Historical binary: reason vs passion</li><li>Read sources critically, not as neutral facts</li></ul></div><div class="revision-card"><h3>Inheritance / self-presentation</h3><ul><li>Badr merges offices in 1074</li><li>Al-Afḍal: court career; age-14 title; 1087 <em>khuṭba</em></li><li><em>Jihād</em> rhetoric; Alexandria, Jerusalem, Asqalān</li></ul></div><div class="revision-card"><h3>Competing narratives</h3><ul><li>Jealousy / forgotten prisoners / Nizārī succession</li><li>Al-Faramā, 1118: strategy vs devastation</li><li>Baldwin’s illness changes assigned causation</li></ul></div></div>''',
'Key Definitions':'''<table data-pagination="repeat-header"><thead><tr><th>Term</th><th>Use in the reading</th></tr></thead><tbody><tr><td><em>Muruwa</em></td><td>Historical ideal of manliness sustained by rational self-command.</td></tr><tr><td><em>Adab</em></td><td>Cultivated etiquette and conduct used to evaluate elite behavior.</td></tr><tr><td><em>Wazīr al-qalam / al-sayf</em></td><td>Vizier of the Pen / Sword: categories requiring historical caution.</td></tr><tr><td><em>Amīr al-juyūsh</em></td><td>Commander of the armies, the military component of Badr’s power.</td></tr><tr><td><em>Khuṭba</em></td><td>Public sermon whose inclusion of a ruler’s name signals political recognition.</td></tr><tr><td><em>Naṣṣ</em></td><td>Theological designation cited in contemporary succession accounts.</td></tr><tr><td><em>Jihād</em> rhetoric</td><td>In the explainer, language legitimating al-Afḍal’s martial role.</td></tr><tr><td>Laudatory / shadow narratives</td><td>Opposing positive contemporary and negative later reputational accounts.</td></tr></tbody></table>''',
'Key Tables':'''<p>Recap the <strong>masculine-ideal binary</strong> in §4.2, the <strong>dated indicators</strong> in §4.3, and the <strong>two al-Faramā accounts</strong> in §4.6.</p><table data-pagination="repeat-header"><thead><tr><th>Dimension</th><th>Contemporary laudatory account</th><th>Later hostile account</th></tr></thead><tbody><tr><td>Standard</td><td>Rational military protector</td><td>Passionate, impulsive ruler</td></tr><tr><td>Testimony</td><td>Campaigns and <em>jihād</em> language</td><td>Jealousy, forgotten prisoners, succession vendetta</td></tr><tr><td>1118 al-Faramā</td><td>Vizier’s coordination forces retreat</td><td>Devastation; Baldwin’s illness explains retreat</td></tr></tbody></table>''',
'Memory Aids':'''<div class="callout-grid"><div class="callout callout--memory"><div class="tag">🟪 From §4.1</div><p><strong>Praise → prowess; polemic → passion.</strong> This is the interpretive contrast organizing the entire reading.</p></div><div class="callout callout--memory"><div class="tag">🟪 From §4.3</div><p><strong>14 → title; 1087 → khuṭba.</strong> The milestones help recall a court upbringing rather than a battlefield career.</p></div><div class="callout callout--memory"><div class="tag">🟪 From §4.4</div><p><strong>Jealousy → Jail → Succession.</strong> The three anecdotes frame his emotions as unfit for rule.</p></div><div class="callout callout--memory"><div class="tag">🟪 From §4.5</div><p><strong>Alexandria → Jerusalem → Asqalān.</strong> Follow the three settings of contemporary praise.</p></div><div class="callout callout--memory"><div class="tag">🟪 From §4.6</div><p><strong>State = strategy; later = suffering and Baldwin.</strong> Ask whose agency the narrator makes decisive.</p></div></div>''',
'Possible Examination Questions':'''<div class="exam-q"><span class="qtype">Short answer</span><p>Define <em>muruwa</em> and <em>adab</em> in the account of medieval masculinity.</p></div><div class="exam-q"><span class="qtype">Source criticism</span><p>How did later historians make jealousy, anger and “forgetfulness” into criticisms of political fitness?</p></div><div class="exam-q"><span class="qtype">Chronology</span><p>Why does al-Afḍal’s court upbringing complicate the inheritance of Badr’s military office?</p></div><div class="exam-q"><span class="qtype">Comparison</span><p>How are the 1118 events at al-Faramā narrated differently by contemporary praise and later polemic?</p></div><div class="exam-q"><span class="qtype">Interpretation</span><p>Why is <em>jihād</em> rhetoric interpreted as a performance of martial authority?</p></div><div class="exam-q"><span class="qtype">Long essay</span><p>Evaluate how medieval gender ideals, propaganda and source transmission shape the historical reputation of al-Afḍal.</p></div>'''
}}


def improve_md(source,n):
    if n==3:return source
    a='''The Binary of Medieval Masculinity,Masculine (The Ideal Ruler),Unmanly / Feminine (The Subject)

Primary Driver,Rationality and Self-Possession,"Passion, Impulse, and Emotion"

Political Role,"Order, Justice, and Protection","Anarchy, Frailty, and Instability"

Key Traits,"Wisdom, Martial Valor, Restraint","Jealousy, Excess Anger, Querulousness"

Intellectual Root,"Aristotelian ""Rule of Reason""","""The Soul of Passion"" (Source of Deviation)"'''
    b='''**The Binary of Medieval Masculinity**

| Dimension | Masculine (The Ideal Ruler) | Unmanly / Feminine (The Subject) |
|---|---|---|
| Primary Driver | Rationality and Self-Possession | Passion, Impulse, and Emotion |
| Political Role | Order, Justice, and Protection | Anarchy, Frailty, and Instability |
| Key Traits | Wisdom, Martial Valor, Restraint | Jealousy, Excess Anger, Querulousness |
| Intellectual Root | Aristotelian “Rule of Reason” | “The Soul of Passion” (Source of Deviation) |'''
    assert a in source, 'Pseudotable in Reading 04 did not match; stop before content loss'
    return source.replace(a,b)


def extract_sections(source,n):
    # Source structure: one ### document title, 6 or 7 numbered ##### sections
    source=re.sub(r'(?m)^### .+?\s*\n','',source,count=1)
    chunks=re.split(r'(?m)^#####\s+(.+?)\s*$',source)
    sections=[(chunks[i].strip(),chunks[i+1].strip()) for i in range(1,len(chunks),2)]
    assert len(sections)==(6 if n==3 else 7),(n,len(sections))
    return sections


def section_html(n,i,title,source_md):
    # Section title text comes directly from the supplied source; the section index
    # is added by the dossier, not inferred from a different article.
    name=re.sub(r'^\d+\.\s*','',title)
    body=md(source_md).replace('<table>','<table data-pagination="repeat-header">')
    additions=CALLOUTS[n].get(i,[])
    cards=''.join(callout(*c) for c in additions)
    if len(additions)>1:cards='<div class="callout-grid">'+cards+'</div>'
    soup=BeautifulSoup(body,'html.parser')
    nodes=[x for x in soup.contents if getattr(x,'name',None)]
    # Meaningful early placement, preserving all source paragraphs and list items.
    anchors={3:{1:2,2:1,3:2,4:2,5:1,6:1},4:{1:1,2:1,3:1,4:1,5:1,6:1,7:0}}
    if nodes and cards:
        pos=min(anchors[n].get(i,0),len(nodes)-1)
        anchor=nodes[pos]
        anchor.insert_after(BeautifulSoup(cards,'html.parser'))
    body=str(soup)
    # Add source-based comparison only after the source's existing explanations.
    supplement=ADDITIONS[n].get(i,'')
    body=mark_arabic(body)
    return f'''<div class="section" id="s{n}-{i}"><div class="section-number">§{n}.{i}</div><h2>{escape(name)}</h2><div class="section-body">{body}\n{supplement}</div></div>'''


def revision_html(n):
    elements=[]
    for i,(title,content) in enumerate(REVISIONS[n].items(),1):
        if title=='Possible Examination Questions':content='<div class="revision-grid exam-question-grid">'+content+'</div>'
        elements.append(f'<div class="section" id="s{n}-rev-{i}"><div class="section-number">REV {i:02d}</div><h2>{escape(title)}</h2><div class="section-body">{content}</div></div>')
    return '\n'.join(elements)


def build(n):
    info=READINGS[n]
    source=(ROOT/'sources'/info['source']).read_text(encoding='utf8')
    sections=extract_sections(improve_md(source,n),n)
    roadmap=''.join('<li>'+escape(p)+'</li>' for p in info['roadmap'])
    body='\n'.join(section_html(n,i,t,chunk) for i,(t,chunk) in enumerate(sections,1))
    out=f'''<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{info['accent']};">
 <div class="leaf"><div class="chapter-title-page">
 <div class="reading-eyebrow">Reading {n:02d} · Literature Dossier</div>
 <h1>{escape(info['title'])}</h1><p class="subtitle">{escape(info['subtitle'])}</p><hr class="gold-rule">
 <div class="opener-split"><div class="thesis-block"><p class="kicker">Central thesis</p><p>{escape(info['thesis'])}</p></div><div class="roadmap"><p class="kicker">In this reading</p><ol>{roadmap}</ol></div></div>
 <p class="source-cite">User-supplied explanatory text for Reading {n}; original academic article not independently supplied or verified.</p>
 </div>{body}</div>
 <div class="revision-zone"><div class="revision-leaf"><div class="revision-kicker">Reading {n:02d} · Revision &amp; recall</div>{revision_html(n)}</div></div></section>'''
    p=ROOT/'chapters'/info['file']
    p.write_text(out,encoding='utf8')
    soup=BeautifulSoup(out,'html.parser')
    assert len(soup.select('.leaf > .section'))==(6 if n==3 else 7)
    assert len(soup.select('.revision-zone .section'))==6
    print(f'Reading {n} authored: {p.name} {len(out):,} characters; {len(soup.select(".leaf .callout--memory"))} main-text memory aids')

if __name__=='__main__':
    for n in READINGS:build(n)
