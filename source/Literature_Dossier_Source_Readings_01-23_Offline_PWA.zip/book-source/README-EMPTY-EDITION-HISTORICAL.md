# Complete Literature Dossier Notes — new active edition

**Status: 0 active readings.** Reading 1 (the Fāṭimid petition) was intentionally archived and removed at the user's request on 3 November 2026. It is available separately in `Literature_Dossier_Archived_Reading_1.zip`, but is **not part of this source package or its assembled book**. Do not automatically reinsert it.

## Add the first replacement reading

The next genuine reading supplied by the user becomes **Reading 1**, not Reading 2. Create `chapters/01-descriptive-title.html` with its own `<section class="chapter" data-chapter="1">…</section>` markup. Preserve the complete argumentation and source terminology. Chapter numbering thereafter follows the readings actually supplied, up to 26.

Do not modify the permanent head, shared CSS, JavaScript compositor, bookmark exporter, cover or design system merely to add a reading. Only modify them for a confirmed system-level fix.

## Unchanged study-note contract

- **Six semantic categories** are fixed: blue definitions; green concepts; amber exam tips; red common mistakes; purple memory aids; gold high-yield facts.
- **Memory aids appear where the relevant concept is taught in the main reading first.** The end-of-chapter Memory Aids collection only recaps those devices; it must never invent new mnemonics there. Include mnemonics only where they genuinely help understanding or recall.
- The six revision sections remain mandatory: Chapter Summary, One-Page Revision Sheet, Key Definitions, Key Tables, Memory Aids, Possible Examination Questions.
- Key definitions and key tables must likewise recur from the main body, not be introduced for the first time in the revision area.
- Preserve explanations, arguments, evidence, original terminology, Arabic/RTL content and scholarly quotations as faithfully as the user-supplied source warrants. No shortening simply to save space. Supplemental interpretation must be identified, not silently invented.
- Main content is free-flowing with rounded, softly translucent semantic callouts and optional clustered grids; **no sidenotes/sidebar layout**. Each reading opener retains the synopsis/roadmap split. Each reading has a distinct accent from the existing chapter palette.
- Full-bleed 16:9 layout, every main/revision page has a header/footer; separate dark revision zone; arbitrary ordered chapter exports, clickable TOC, and genuine PDF bookmark outline using the local publisher remain intact.

## Build and publish

`python build.py` assembles `output/book.html` from independent source files. Right now the HTML displays the book cover and a friendly 'readings forthcoming' screen; export controls are disabled because there is nothing to export. That is expected.

After the first source arrives, build again and export using:

```bash
python build.py
python export_bookmarked.py --chapters 1 --font-profile offline --out output/Reading_1.pdf
```

The exporter uses local Chromium, Playwright and PyMuPDF, while the browser runtime remains handwritten vanilla JS. The executable tests in `tests/` verify the empty-edition behavior. Once a genuine chapter is supplied, run full Chromium/PDF pagination, font, text-preservation, Arabic and bookmark checks against that reading. Historical tests based specifically on the archived petition are kept in the original v3 source snapshot, not treated as passing tests of this empty edition.
