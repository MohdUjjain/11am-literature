"""Manual 17–18 chapter-only generator; the 01–16 source remains immutable.

Editorial basis: user-supplied Google Docs, not independently checked article texts.
"""
from pathlib import Path
import html,json,hashlib
ROOT=Path(__file__).resolve().parent

CATS={'definition','concept','examtip','mistake','memory','highyield'}
def P(t,*notes):return {'html':'<p>'+t+'</p>','notes':[dict(kind=k,title=ttl,body=b) for k,ttl,b in notes]}
def T(head,rows,*notes):
    return {'html':'<table data-content-type="comparison" data-pagination="repeat-header"><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in r)+'</tr>' for r in rows)+'</tbody></table>', 'notes':[dict(kind=k,title=ttl,body=b) for k,ttl,b in notes]}
def L(items,*notes,ordered=False):
    tag='ol' if ordered else 'ul'
    return {'html':f'<{tag}>'+''.join(f'<li>{item}</li>' for item in items)+f'</{tag}>','notes':[dict(kind=k,title=ttl,body=b) for k,ttl,b in notes]}
def S(title,*items):return {'title':title,'items':list(items)}

def build(n,title,subtitle,thesis,sections,definitions,keytables,memory,questions,summary,cards,accent,source_id,file_slug):
    o=[f'<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{accent};"><div class="leaf"><div class="chapter-title-page">',
       f'<div class="reading-eyebrow">Reading {n:02d} · Literature Dossier</div><h1>{html.escape(title)}</h1>',
       f'<p class="subtitle">{html.escape(subtitle)}</p><hr class="gold-rule"/>',
       '<div class="opener-split"><div class="thesis-block"><p class="kicker">Central thesis</p>',
       '<p>'+thesis+'</p></div><div class="roadmap"><p class="kicker">In this reading</p><ol>',
       *['<li>'+html.escape(s['title'])+'</li>' for s in sections],'</ol></div></div>',
       f'<p class="source-cite">Source: supplied Google Drive explainer {n:02d}, Google Doc {source_id}. This study guide follows the supplied interpretation; no independent comparison with the scholarly publication has been made. Counts, quotations, contested claims and interpretations are those of the explainer unless indicated otherwise.</p></div>']
    stats={}; cnt=0
    for i,s in enumerate(sections,1):
        o.append(f'<div class="section" id="s{n}-{i}"><div class="section-number">§{n}.{i}</div><h2>{html.escape(s["title"])}</h2><div class="section-body">')
        for j,it in enumerate(s['items']):
            a=f's{n}-{i}-p{j}'
            o.append(f'<article class="passage" data-anchor="{a}"><div class="prose">{it["html"]}</div>')
            if it['notes']:
                o.append('<aside aria-label="Study notes for this passage">')
                for k,note in enumerate(it['notes']):
                    typ=note['kind']; assert typ in CATS
                    stats[typ]=stats.get(typ,0)+1;cnt+=1
                    o.append(f'<div class="callout callout--{typ}" data-content-type="{typ}" data-note-id="{a}-n{k}" data-pagination="allow-split"><div class="tag">{html.escape(note["title"])}</div><p>{note["body"]}</p></div>')
                o.append('</aside>')
            o.append('</article>')
        o.append('</div></div>')
    o.extend(['</div><div class="revision-zone"><div class="revision-leaf">',f'<div class="revision-kicker">Reading {n:02d} · Revision &amp; recall</div>'])
    def R(i,title,body):return f'<div class="section" id="s{n}-rev-{i}"><div class="section-number">REV {i:02d}</div><h2>{title}</h2><div class="section-body">{body}</div></div>'
    o.append(R(1,'Chapter Summary','<p>'+summary+'</p>'))
    o.append(R(2,'One-Page Revision Sheet','<div data-pagination="keep-together"><div class="revision-grid">'+''.join(f'<div class="revision-card"><h3>{h}</h3><p>{b}</p></div>' for h,b in cards)+'</div></div>'))
    o.append(R(3,'Key Definitions',T(['Term','Meaning in the supplied reading'],definitions)['html']))
    o.append(R(4,'Key Tables',keytables))
    o.append(R(5,'Memory Aids','<div class="callout-grid">'+''.join(f'<div class="callout callout--memory" data-content-type="memory" data-pagination="allow-split"><div class="tag">Memory aid · From §{n}.{i} · {h}</div><p>{b}</p></div>' for i,h,b in memory)+'</div>'))
    o.append(R(6,'Possible Examination Questions','<div class="revision-grid exam-question-grid">'+''.join(f'<div class="exam-q"><span class="qtype">{cat}</span><p>{q}</p></div>' for cat,q in questions)+'</div>'))
    o.extend(['</div></div></section>'])
    f=ROOT/'chapters'/f'{n:02d}-{file_slug}.html'; f.write_text(''.join(o),encoding='utf8')
    return {'reading':n,'file':f.name,'sections':len(sections),'passages':sum(len(s['items']) for s in sections),'notes':cnt,'note_types':stats,'memory_aids':len(memory),'tables':sum('table' in x['html'] for s in sections for x in s['items']),'revision_sections':6}


# Reading 17 — source-based comparative jurisprudence; 5 pages is a target, not a rigid ceiling.
sec17 = [
 S('A Shared Ethical Demand, Not an Inevitable Collision',
  P('The supplied explainer challenges the depiction of <strong>Islamic law</strong> and <strong>human rights</strong> as inherently incompatible. Both are normative traditions: they claim that human conduct must be governed by standards conducive to the good of humanity. The central question is whether each is construed as a fixed external command or as a living moral practice. The proposed reconciliation is therefore an <strong>internal intellectual and cultural undertaking</strong>, not the mechanical transplantation of an imported statute.',
    ('concept','Core thesis · A subjective challenge','Compatibility depends on moral interpretation and institutional habits, not on an asserted timeless collision.'),
    ('examtip','How to frame the argument','Begin with the shared normative ambition, then examine the mechanisms of reform, the limits of punishment and the demands of conviction.')),
  P('The text places great weight on the resources of <strong>juristic reasoning</strong>, <strong>human dignity</strong>, and <strong>rationalist scholarship</strong>. Historical examples and strong claims about transmission to Western natural rights are presented as claims of the supplied explainer; these notes do not independently establish their documentary genealogy. What the chapter asks the student to test is the difference between possessing a legal declaration and cultivating a population that regards another person’s rights as inviolable.',
    ('highyield','The outcome is a culture, not only a code','The desired human-rights commitment must survive political convenience and lack of reciprocity.'))),
 S('Antimajoritarian Conviction and the Different Kinds of Rights',
  P('An authentic human-rights commitment requires a <strong>rationally grounded conviction</strong> that each person has inherent worth by virtue of being human. It extends across religion, citizenship and ethnic membership. Its defining test is <em>antimajoritarian</em>: a majority cannot simply cancel an individual’s essential immunities. Nor may reciprocity decide the issue; the source offers the example of refusing to torture even after suffering torture oneself.',
    ('definition','Term · Antimajoritarian','An individual right remains binding even when a numerical majority would prefer to withdraw it.'),
    ('memory','Memory · H / C / G','<strong>Human → humanity; Civil → citizenship; Group → membership.</strong> Recall the ground on which each claim rests.')),
  T(['Type','Source of protection','Who possesses it?'],[
    ['Human rights','Inherent human worth, reason, nature or God','Every human being; not cancellable by majority vote'],
    ['Civil rights','Law and political membership of a state','Citizens within that polity'],
    ['Group rights','Belonging to a defined identity or community','People meeting the group criterion']]),
  P('The explainer also warns against translating every classical <em>ḥaqq</em> or <em>ḥuqūq</em> directly as a modern inalienable right. In classical legal discourse these words could designate <strong>claims, jurisdictions or entitlements</strong>, including “rights of God” and “rights of people.” Thus a comparison must distinguish the modern language of universal immunities from the older distribution of legal competence and liability.',
    ('mistake','Do not equate ḥaqq with modern human rights','The same word can name an enforceable legal claim without asserting an unconditional immunity.'),
    ('definition','Term · Ḥaqq / ḥuqūq','Right or claim; in the supplied account often a jurisdictional or legal competence as well as a moral entitlement.'))),
 S('Sharīʿa and Fiqh: The Tradition as a Fallible Inquiry',
  P('In the account, <strong>Sharīʿa</strong> designates the Divine or Covenantal Law: absolute, enduring and inherently good. <strong>Fiqh</strong> is the contextual, fallible human labor of deriving guidance from that ideal. Historical schools therefore differ in method yet remain recognizable participants in a cumulative legal conversation. Treating every historical juristic opinion as the Divine command itself removes the tradition’s capacity for critique.',
    ('definition','Sharīʿa ≠ fiqh','<em>Sharīʿa</em> is the sacred moral ideal; <em>fiqh</em> is contingent juristic understanding of it.'),
    ('memory','Memory · Ideal versus inference','<strong>Divine ideal → human reasoning → revisable ruling.</strong> The distinction makes reform thinkable without denying the ideal.')),
  P('This distinction is the hinge of the chapter’s proposed humanism. If ethical law is an ongoing search for justice and public benefit, responsible correction is possible when interpretations cease to protect persons. That is different from claiming that any change desired by a government becomes legitimate. The source explicitly treats moral justification, deliberation and the protection of the human being as the standards by which interpretations should be tested.',
    ('concept','Why plural schools matter','Juristic variation is evidence of interpretation and debate, not proof that the underlying Divine ideal changes.'))),
 S('The Ḥudūd Paradox: Sanctions and Restraint',
  P('The strongest tension identified by the explainer is the existence of severe <strong>ḥudūd</strong> punishments, including penalties mentioned for theft and adultery. Yet the same legal tradition is portrayed as imposing exceptionally demanding procedural and evidentiary thresholds. The principle of <strong>shubha</strong> (“doubt”) requires restraint where doubt exists before an irrevocable sanction. Qurʾānic exhortations to mercy and forgiveness further complicate the simple picture of a punitive legal machine.',
    ('definition','Term · Shubha','Doubt or uncertainty that, under the rule described, suspends serious punishment.'),
    ('memory','Memory · Three gates','<strong>Evidence → doubt test → mercy.</strong> Examine conditions of enforcement, not only the announced penalty.')),
  P('The source contends that successful prosecutions were historically uncommon and suggests that such sanctions often worked as moral deterrents. This is a historically framed argument in the explainer, <strong>not an independently verified frequency estimate</strong>. The exam-level distinction is between a nominal sanction, the procedural rules required for its application, and the ideal of protecting human dignity. None may be collapsed into another.',
    ('examtip','Address both sides of the paradox','Name the punishments and explain the evidentiary barriers; do not erase either part.'),
    ('mistake','A legal text is not a prosecution statistic','The presence of a severe sanction cannot by itself establish how frequently it was carried out.'))),
 S('Khalīfa, Amāna and the Protected Human Person',
  P('The theological foundation developed in the explainer is the human being as <strong>khalīfa</strong>, a deputy or trustee on earth, entrusted with the <strong>amāna</strong> (sacred trust). Humanity is therefore responsible for justice (<em>ʿadl</em>), excellence or equity (<em>iḥsān</em>) and mercy (<em>raḥma</em>). Classical jurists are said to have recognized basic sanctities (<em>ʿiṣma</em>) that sustain a virtuous social existence.',
    ('definition','Terms · Khalīfa / amāna','Human vicegerency or trusteeship; the trust grounding duties toward other people and the world.'),
    ('memory','Memory · Trust to sanctity','<strong>Trust → justice → inviolability.</strong> The human person is the moral object of legal protection.')),
  T(['Protected value','What the explainer emphasizes'],[
    ['Life','The sanctity of human existence'],['Property','Material security'],['Dignity (<em>karāma</em>)','Inherent worth'],
    ['Reason (<em>ʿaql</em>)','The human intellect'],['Reputation / personality (<em>qiwāma</em>)','Honor and standing'],['Privacy (<em>satr</em>)','Protection of personal space and affairs']]),
  P('Together these protections make the humanist argument more specific than general praise of compassion. They provide an <strong>internal vocabulary</strong> in which dignity, intellect, privacy and the protection of life can be discussed as obligations of the legal order. The question becomes how jurists and societies translate these normative commitments into consistent institutional protections.',
    ('highyield','Six sanctities are not just a list','Explain how each turns the sacred trust into a concrete duty of protection.'))),
 S('Reason, Natural Rights and the Claimed Cross-Cultural Link',
  P('The reading attributes a foundational rationalist role to the <strong>Muʿtazila</strong> and to inquiry into <em>al-ḥusn wa-l-qubḥ</em> (good and evil). It names <strong>Ibn Rushd</strong>, <strong>Ibn Bājja</strong>, <strong>Ibn ʿAqīl</strong> and <strong>Ibn Ṭufayl</strong> among Muslim thinkers associated with moral inquiry. It also claims that <strong>Aquinas</strong> engaged figures such as Ibn Sīnā and al-Ghazālī, and that Ibn Rushd’s framing of moral obligation anticipated an Aquinian first principle. These transmission claims belong to the supplied account and require separate historical verification if cited as settled intellectual genealogy.',
    ('highyield','Names · Rationalist link','Muʿtazila; Ibn Rushd; Ibn Bājja; Ibn ʿAqīl; Ibn Ṭufayl; Aquinas in the later reception argument.'),
    ('mistake','Distinguish influence from proven borrowing','Resemblance and later engagement do not by themselves demonstrate a single direct chain of transmission.')),
  P('The explainer invokes a protest attributed to <strong>ʿUmar b. al-Khaṭṭāb</strong> against enslaving those born free, then presents <strong>Qāḍī ʿAbd al-Jabbār</strong> and his <em>al-Mughnī</em> as developing a reasoned condemnation of slavery as intrinsically wrong. Their function in the chapter is to exemplify the possibility of strong moral critique from within Islamic intellectual premises, rather than the need for an alien source of ethical reason.',
    ('concept','The moral argument is endogenous','The source argues that Islamic intellectual resources can generate claims about universal freedom and dignity.'))),
 S('Colonial Rupture and the Need for Internal Conviction',
  P('The explainer describes a decline in rationalist environments after the thirteenth century amid the sack of Baghdad and the loss of Andalusian centers, then a sharper <strong>colonial rupture</strong> when European civil codes displaced living forms of Islamic legal reasoning. It calls the resulting condition a <strong>“mummified” tradition</strong>: publicly revered as flawless while no longer routinely used for contemporary legal problem-solving. Nationalism narrowed the universal <em>umma</em> into the state; coercive secularization intensified anxiety over religious identity.',
    ('definition','Image · Mummification','A tradition praised as perfect but frozen into an unused relic rather than exercised as critical inquiry.'),
    ('memory','Memory · Rupture and recovery','<strong>Colonial displacement → defensive idealization → renewed internal reasoning.</strong>')),
  P('The chapter also associates this defensive climate with antirationalist responses, including a mention of Wahhabism. These are interpretations advanced by the supplied authorial account, not a complete causal history of modern Islamic movements. The conclusion is practical: human rights cannot take firm root through coercive transplantation alone. The needed project is <strong>education, persuasive conviction and renewed reasoning</strong> grounded in the tradition’s own resources of <em>karāma</em>, <em>ʿaql</em> and justice.',
    ('examtip','Final synthesis','Join three strands: antimajoritarian worth, Sharīʿa–fiqh distinction, and the cultivation of internal moral conviction.'))),
]
mem17=[
 (2,'H / C / G','<strong>Human → humanity; Civil → citizenship; Group → membership.</strong> Recall the ground on which each claim rests.'),
 (3,'Ideal versus inference','<strong>Divine ideal → human reasoning → revisable ruling.</strong> The distinction makes reform thinkable without denying the ideal.'),
 (4,'Three gates','<strong>Evidence → doubt test → mercy.</strong> Examine conditions of enforcement, not only the announced penalty.'),
 (5,'Trust to sanctity','<strong>Trust → justice → inviolability.</strong> The human person is the moral object of legal protection.'),
 (7,'Rupture and recovery','<strong>Colonial displacement → defensive idealization → renewed internal reasoning.</strong>'),
]
res17=build(17,'Cultivating Human Rights: Islamic Law and the Humanist Imperative',
 'From Antimajoritarian Moral Commitment to Juristic Renewal',
 'The source argues that Islamic law and human rights need not be intrinsically incompatible. A robust rights culture depends on antimajoritarian moral conviction and the creative, critical recovery of Islamic resources of reason, dignity and fallible juristic reasoning, rather than imposition of an external code.',
 sec17,
 [('Antimajoritarian','Rights that do not disappear when the majority withdraws support.'),('Human rights','Claims inherent in human worth, irrespective of citizenship or group.'),('Civil rights','Protections dependent on membership and institutions of a polity.'),('Ḥaqq / ḥuqūq','Claims, jurisdictional competences or rights, whose classical uses need contextual reading.'),('Sharīʿa','The Divine or Covenantal Law in its sacred, enduring ideal form.'),('Fiqh','Contextual and revisable human understanding of Sharīʿa.'),('Ḥudūd','Serious prescribed sanctions whose application the source says is limited by strict safeguards.'),('Shubha','Doubt requiring suspension of a severe irrevocable penalty.'),('Khalīfa','Human trustee/deputy on earth.'),('Amāna','The sacred trust grounding moral responsibilities.'),('ʿIṣma','Inviolability or protected sanctity.'),('Karāma','Human dignity.'),('ʿAql','The faculty of reason.'),('Satr','Personal privacy.'),('Al-ḥusn wa-l-qubḥ','The ethical inquiry into good and evil.'),('Mummification','Reverence for a tradition treated as static rather than developed through active reasoning.')],
 T(['Intellectual move','Claim','Illustration in the source'],[
 ['Normative commitment','Human worth binds even against majority preference','Refusal of torture regardless of reciprocity'],
 ['Legal method','Divine ideal differs from fallible juristic interpretation','Sharīʿa versus fiqh'],
 ['Sanction and safeguard','Severe ḥudūd coexist with shubha and calls for mercy','Doubt blocks irreversible punishment'],
 ['Theological anthropology','Humanity bears a moral trust and protected sanctities','Khalīfa, amāna, dignity, reason, privacy'],
 ['Rationalism','Internal moral critique is possible','Muʿtazila, Ibn Rushd, ʿAbd al-Jabbār'],
 ['Modern rupture','Colonial codes and defensive idealization inhibit legal creativity','“Mummified” law and dislocated fiqh'],
 ['Proposed renewal','Educate for conviction; derive norms from internal resources','Humanist and rationalist reconstruction']])['html'],
 mem17,
 [('Definition','Distinguish human, civil and group rights. Why must rights be antimajoritarian?'),('Legal theory','Explain the distinction between Sharīʿa and fiqh and why it matters for reform.'),('Problem analysis','What is the ḥudūd paradox? How does shubha enter the argument?'),('Concept','How do khalīfa and amāna connect to the six protected sanctities?'),('Historical assessment','Explain the reading’s claim about Muslim rationalists and Western natural rights; identify the limits of its source evidence.'),('Essay','Why does the author call colonial-era Islamic legal thought “mummified”?'),('Synthesis','Can human rights be imposed by legislation alone? Develop the author’s argument.')],
 'The supplied argument begins from the shared ethical ambitions of Islamic law and human rights. Inalienable human worth requires antimajoritarian conviction rather than majority tolerance. Classical law is presented as a fallible cumulative search for the Divine ideal, with the Sharīʿa/fiqh distinction enabling criticism. The source juxtaposes severe ḥudūd with demanding evidentiary thresholds, the shubha rule and mercy. The human person as khalīfa bearing amāna grounds protected values such as life, dignity, reason and privacy. Muslim rationalist traditions are offered as internal resources for moral critique and as a claimed link to Western natural rights. Colonial legal displacement and defensive idealization supposedly “mummified” this tradition. Recovery requires cultural and educational conviction rather than coercive transplantation.',
 [('Thesis','A rights culture must grow from internal moral conviction and active juristic reflection.'),('Rights','Human = universal; Civil = polity-based; Group = identity-based.'),('Legal distinction','Sharīʿa is the sacred ideal; fiqh is fallible interpretation.'),('Procedure','Ḥudūd sanctions are discussed alongside shubha, evidence and mercy.'),('Human status','Khalīfa and amāna entail dignity, reason, life, property, reputation and privacy.'),('Modern problem','Colonial displacement; defensive “mummification”; educational and rationalist recovery.')],
 '#705B8F','1jkUMdjKwWdZ_0Xt6zFCv5ufEZoOoavp1mVGQYbc5DLk','cultivating-human-rights-islamic-law')

# Reading 18 — follow the actual sequence of literary scenes, retaining interpretative texture.
sec18=[
 S('The Narrative Spiral: Adult Performance to Child’s Sanctuary',
  P('Chapters <strong>19–21</strong> of <em>The Catcher in the Rye</em>, as analyzed by the supplied explainer, trace Holden Caulfield from the artificial sophistication of the <strong>Wicker Bar</strong>, through a freezing and frightening <strong>Central Park</strong>, to the comparatively safe intimacy of <strong>Phoebe’s bedroom</strong>. The route is also psychological: he seeks someone who will recognize his loneliness without converting it into social display or clinical diagnosis. The source reads recurring objects—drink, record, ice, notebooks—as cues to a destabilized sense of self.',
    ('concept','Route equals emotional argument','Bar: performance and estrangement → Park: vulnerability and grief → Bedroom: recognition.'),
    ('memory','Memory · B / P / B','<strong>Bar → Park → Bedroom.</strong> Each space changes what Holden can admit and receive.')),
  P('In the source’s interpretation, adult “phoniness” is less a stable sociological category than the name Holden gives to social postures that exclude honesty. Phoebe does not solve his expulsion or his grief, but her presence supplies an alternative register: play, tactile objects, sudden affection and a refusal to indulge his excuses. It is crucial to distinguish <strong>the events narrated in the novel</strong> from <strong>psychological explanations supplied by the explainer</strong>.',
    ('examtip','Keep event and interpretation separate','First identify what Holden witnesses or does; then explain the symbolism proposed by the reading.'))),
 S('Wicker Bar and Carl Luce: Sophistication Without Empathy',
  P('At the <strong>Seton Hotel’s Wicker Bar</strong>, Holden finds Tina and Janine’s “Vooly Voo Fransay” routine and its delighted audience intolerably artificial. The bartender’s respect for celebrity reinforces his conviction that sophistication can be a form of performance. The room announces refinement through music, manner and applause; Holden experiences it as isolation. He is especially alienated by applause that seems to reward display instead of genuine connection.',
    ('highyield','Wicker Bar · The setting is an argument','Stylized music, celebrity deference and enthusiastic applause become evidence of “phoniness” in Holden’s account.')),
  P('<strong>Carl Luce</strong>, Holden’s former student adviser, arrives as an apparent intellectual authority. He labels other people by sexuality and invokes “Eastern philosophy,” then recommends that Holden recognize patterns in his own mind or consult his psychoanalyst father. Holden meanwhile admits that he is “lonesome as hell” and attempts to prolong the conversation. The supplied analysis treats Luce’s vocabulary as <strong>emotional distance disguised as sophistication</strong>, though the scene also shows Holden’s intrusive, provocative questioning and limited ability to listen.',
    ('definition','Reading distinction · Categorization versus recognition','Luce offers patterns and labels; Holden wants somebody to acknowledge his distress.'),
    ('mistake','Do not present Luce as a clinical diagnosis','The suggestion of “identity fragmentation” is the supplied literary interpretation, not a psychiatric evaluation of the character.')),
  T(['Carl Luce','Holden Caulfield'],[
    ['Labels, intellectual detachment, professional scripts','Emotional disclosure, provocation, need for liking'],
    ['“Eastern” philosophy as narrated through Holden','Hostility to received sophistication'],
    ['Recommends diagnosis and recognizing patterns','Asks for connection and another drink']]),
  P('When Luce leaves, the bar’s social language has failed to provide a listener. This failure prepares the next movement: Holden turns from conversation toward drunken self-staging and increasingly fearful memories. The juxtaposition is not simply adult bad / child good; it reveals how Holden’s need for recognition intensifies his resentment when another person will not meet it.',
    ('examtip','Paragraph technique · Show the causal transition','Luce’s departure → isolation → drunken performance, rather than three unconnected incidents.'))),
 S('Intoxication, a Broken Record and the Frozen Lagoon',
  P('After Luce departs, Holden gets heavily drunk and imagines himself as a wounded “sonuvabitch,” carrying an imaginary bullet in the stomach. He calls <strong>Sally Hayes</strong> while sustaining this melodramatic pose. The source interprets the mock injury as an outward performance of distress he cannot otherwise articulate. His joking language does not cancel the seriousness of the loneliness visible beneath it.',
    ('concept','The imaginary wound is an expressive device','Physical melodrama becomes a substitute for naming psychological pain.'),
    ('memory','Memory · Wound and record','<strong>Imaginary bullet → broken record → icy lagoon.</strong> Playful acting gives way to material loss and grief.')),
  P('In Central Park, the <strong>“Little Shirley Beans” record</strong>, intended for Phoebe, breaks into many pieces. Holden is near tears but pockets the fragments rather than abandoning them. The reading treats this as an image of something damaged yet still worth carrying. The <strong>lagoon and ducks</strong> raise his recurring question about where vulnerable creatures go in winter. Ice in his hair makes him fear pneumonia and picture his own funeral, before the scene shifts toward grief for <strong>Allie</strong>.',
    ('highyield','Objects carry the argument','Record fragments = damaged gift still kept; ducks = survival question; ice = bodily exposure.'),
    ('mistake','The record is not repaired','Holden preserves the broken pieces; the significance lies in their continued value, not a magical restoration.')),
  P('Holden remembers Allie’s grave in the rain: visitors can retreat to their cars while the dead boy remains exposed. The source calls this a meditation on <strong>the mobility of the living and the immobility of the dead</strong>. Holden’s anger at the unfairness of shelter helps explain why Phoebe becomes so urgent to him. He cannot protect Allie, but he can still seek the company of his living sister.',
    ('definition','Interpretive contrast · Mobility and immobility','Living mourners leave the rain; Allie remains at the grave—an image of helpless grief.'))),
 S('The Foyer and the Domestic Geography of Fear',
  P('Holden enters his family apartment secretly because he wants to see Phoebe without encountering his parents after his expulsion. He compares himself to a <strong>crook</strong> in his own home. Unlike the hostile public spaces, the apartment is recognized through a familiar but hard-to-name smell—not cauliflower and not perfume. That sensory certainty suggests intimate belonging even when Holden feels socially estranged from the household.',
    ('concept','Home is sensory before it is safe','The recognizable smell promises familiarity, while stealth and fear show the home remains complicated.')),
  P('He imagines his mother as hyper-alert, with “bloodhound” hearing, and his father as a heavy sleeper. These contrasts help him calculate how to move through the rooms undetected. When he reaches <strong>D.B.’s room</strong>, where Phoebe is sleeping, his tone abruptly changes: he feels “swell, for a change.” The bed and quiet room provide temporary refuge from the bar and lagoon, but the visit is not a permanent cure for his difficulties.',
    ('memory','Memory · Smell / stealth / relief','<strong>Known smell → fear of discovery → Phoebe’s room → temporary relief.</strong>'))),
 S('Phoebe’s Notebooks: Authenticity Through Small Details',
  P('Before Phoebe wakes, Holden studies her <strong>school notebooks</strong> with delight. Her playful self-renaming as <strong>Phoebe Weatherfield Caulfield</strong>, her curious questions about factories in Alaska, and her careful way of keeping things represent the source’s “authentic” counterworld to the Wicker Bar. Her <strong>blue pajamas with red elephants</strong> and neatly arranged clothes are ordinary details, yet Holden notices them with the attention he could not give the adults at the bar.',
    ('highyield','Notebook details matter','“Weatherfield,” unusual school questions and elephant pajamas show affection through specifics, not abstract claims.'),
    ('memory','Memory · Three signs of Phoebe','<strong>Notebook → playful name → elephant pajamas.</strong> Her authenticity is concrete.')),
  P('When Phoebe wakes, her first interest is whether Holden received her <strong>letter</strong>; their connection starts with an act of correspondence. The source contrasts this exchange with Luce’s abstraction: Phoebe asks a direct, relational question rather than classifying Holden as a problem. The reading also calls her “strong as hell” when she resists being moved. Her childhood is not passive innocence; it has energy, judgment and its own will.',
    ('examtip','Avoid idealizing Phoebe','Show both warmth and firmness. She offers attention, then challenges Holden’s evasions.'))),
 S('Expulsion, Benedict Arnold and the End of Evasion',
  P('Phoebe is rehearsing <strong>Benedict Arnold</strong> for <em>A Christmas Pageant for Americans</em>. Their playful talk cannot conceal Holden’s early arrival from school. Phoebe quickly realizes that he has been <strong>expelled</strong> and repeats that their father will be furious. The source treats her protest as a demand that Holden confront consequences, not simply as an adult-like moral lecture.',
    ('definition','Scene pivot · “Daddy’ll kill you”','Phoebe’s frightened, repeated reaction registers real social consequences; it is not a literal prediction of violence.')),
  P('Holden proposes that he might escape to a <strong>Colorado ranch</strong>, trying once more to reorganize reality through fantasy. Phoebe punctures the plan by observing that he cannot even ride a horse. The novel therefore gives the child the role of practical corrector: she refuses to accept another elaborated story when Holden needs to acknowledge what happened. The <strong>broken record pieces</strong>, which she keeps, provide the final counter-image: one can recognize damage without denying the person who brings it.',
    ('memory','Memory · Reality interrupts fantasy','<strong>Expulsion → ranch plan → Phoebe’s correction → kept record fragments.</strong>'),
    ('examtip','Conclude with a qualified claim','Phoebe offers acceptance and reality, not a miraculous resolution of grief, school failure or family tension.')),
  T(['Movement','Key object or moment','How the reading interprets it'],[
    ['Wicker Bar','Stylized singers; Carl Luce','Social performance without an empathetic witness'],
    ['Central Park','Broken record; ducks; Allie’s grave','Fragmentation, survival anxiety, unrepaired grief'],
    ['Apartment','Familiar smell; secret approach','Belonging compromised by fear'],
    ['Phoebe’s room','Notebook; elephant pajamas; letter','Specific, reciprocal, unsophisticated recognition'],
    ['Confession','Expulsion; Colorado ranch; record fragments','Reality confronts fantasy; broken things remain valued']]))
 ]
mem18=[
 (1,'B / P / B','<strong>Bar → Park → Bedroom.</strong> Each space changes what Holden can admit and receive.'),
 (3,'Wound and record','<strong>Imaginary bullet → broken record → icy lagoon.</strong> Playful acting gives way to material loss and grief.'),
 (4,'Smell / stealth / relief','<strong>Known smell → fear of discovery → Phoebe’s room → temporary relief.</strong>'),
 (5,'Three signs of Phoebe','<strong>Notebook → playful name → elephant pajamas.</strong> Her authenticity is concrete.'),
 (6,'Reality interrupts fantasy','<strong>Expulsion → ranch plan → Phoebe’s correction → kept record fragments.</strong>'),
]
res18=build(18,'The Catcher in the Rye (Chapters 19–21)',
 'The Sanctuary of the Innocent: From Wicker Bar to Phoebe’s Room',
 'The supplied interpretation follows Holden from adult performance and failed contact through intoxication, loss and grief toward Phoebe’s attentive but unsentimental presence. Ordinary objects and spaces reveal both his loneliness and his wish for a form of connection that does not deny brokenness.',
 sec18,
 [('Phoniness','Holden’s dismissive term for artificial public roles and self-advertising sophistication.'),('Narrative spiral','A sequence of movements through place that dramatizes changes in Holden’s psychological condition.'),('Wicker Bar','Seton Hotel venue where Holden meets Carl Luce.'),('Carl Luce','Former student adviser who responds to Holden with intellectual and clinical language.'),('Bullet fantasy','Holden’s drunken performance of a wounded man, read as the outward staging of pain.'),('Little Shirley Beans','Record intended for Phoebe; its fragments are preserved after breaking.'),('Central Park lagoon','Scene of Holden’s duck question, exposure to cold and memories of Allie.'),('Allie','Holden’s dead brother, whose grave and vulnerability recur in his grief.'),('Phoebe Weatherfield Caulfield','Phoebe’s playful adopted name in her schoolwork.'),('Benedict Arnold','Role Phoebe is rehearsing for a school Christmas pageant.'),('Colorado ranch','Holden’s imagined escape plan, challenged by Phoebe.'),('Authenticity','The reading’s term for direct, attentive and specific relations, contrasted with social performance.')],
 T(['Sequence','Physical detail','Thematic function'],[
 ['Wicker Bar','“Vooly Voo,” Carl Luce, another drink','Stylized sophistication cannot answer loneliness'],
 ['After the bar','Imaginary bullet and Sally’s phone call','Mock injury stages distress'],
 ['Park','Broken record, frozen hair, ducks, grave','Grief, exposure and uncertainty about survival'],
 ['Return home','Recognizable smell, furtive entry','Belonging mixed with fear'],
 ['Phoebe asleep','Notebook, Weatherfield, elephant pajamas','Ordinary detail becomes trusted authenticity'],
 ['Phoebe awake','Letter, expulsion, ranch claim','Affection coupled with reality-testing'],
 ['Closing object','Record fragments kept by Phoebe','Acceptance does not require an undamaged gift']])['html'],
 mem18,
 [('Narrative','Trace Holden’s movement from the Wicker Bar through Central Park to Phoebe’s room.'),('Comparison','Compare Carl Luce’s way of speaking with Phoebe’s response to Holden.'),('Symbolism','What do the broken record pieces signify, and why does Holden keep them?'),('Psychological reading','How do the imaginary bullet, ducks and Allie’s grave relate to one another?'),('Close reading','Why do the smell of home, notebooks and elephant pajamas matter?'),('Character','How does Phoebe combine affectionate attention with a refusal of Holden’s excuses?'),('Essay','Discuss the limits of “authenticity” as a solution to Holden’s troubles in these chapters.')],
 'The source reads Chapters 19–21 as a journey from performance to imperfect recognition. At the Wicker Bar, false sophistication and Carl Luce’s intellectual distance intensify Holden’s loneliness. Drinking and a pretend abdominal wound give way to the tangible loss of Phoebe’s broken record, fear of cold and death, and grief for Allie beside the lagoon. The secret return home mixes familiar belonging with apprehension. Phoebe’s notebooks, playful names, pajamas and letter ground Holden in a world of specific care. She then exposes his expulsion and challenges his Colorado ranch fantasy. By keeping the broken record fragments, she embodies the possibility of accepting what is damaged without pretending it is restored.',
 [('Route','Wicker Bar → Central Park → apartment → Phoebe’s room.'),('Contrast','Luce categorizes and distances; Phoebe recognizes and challenges.'),('External collapse','Drunken “bullet,” broken record and frozen lagoon expose vulnerability.'),('Grief','Allie’s grave reveals Holden’s inability to protect the dead.'),('Authentic objects','Notebook, Weatherfield name, elephant pajamas, letter.'),('Resolution','Broken record fragments kept: belonging without denial or cure.')],
 '#4D728C','1B0v6VWc5sloT5NpzUWzktFpkvFnnRK_e6a_kA4bSrMI','catcher-in-rye-ch19-21')

manifest={'batch':'17-18','source':'User-connected Google Drive original explainer documents',
 'source_ids':{'17':'1jkUMdjKwWdZ_0Xt6zFCv5ufEZoOoavp1mVGQYbc5DLk','18':'1B0v6VWc5sloT5NpzUWzktFpkvFnnRK_e6a_kA4bSrMI'},
 'stats':[res17,res18],
 'source_sha256':{str(n):hashlib.sha256((ROOT/'sources'/f'{n:02d}-raw-explainer.txt').read_bytes()).hexdigest() for n in (17,18)},
 'policy':'Same condensed editorial system: default five main pages, six if required. No CSS, engine, font or existing chapter modifications. Preserve original explainer archives and distinguish analysis from sourced quotation.'}
(ROOT/'NEW_READINGS_17_18_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
