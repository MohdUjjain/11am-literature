#!/usr/bin/env python3
"""Export the assembled literature dossier with a REAL hierarchical PDF bookmark sidebar.

The HTML application remains plain vanilla JavaScript with no PDF dependencies.
This local publishing command uses Chromium's PDF backend and optionally
PyMuPDF to normalize exact bookmark titles, their nesting, and document metadata.

Usage:
  python build.py
  python export_bookmarked.py --out output/Literature_Dossier.pdf --chapters 1
  python export_bookmarked.py --chapters '15-24,1,26' --out output/selection.pdf

Dependencies (publishing-side only): pip install playwright pymupdf
Browser: system Chromium or playwright's installed Chromium.
"""
from __future__ import annotations
import argparse
import base64
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

from playwright.sync_api import sync_playwright
import fitz

ROOT = Path(__file__).resolve().parent
DEFAULT_HTML = ROOT / 'output' / 'book.html'
DEFAULT_PDF = ROOT / 'output' / 'Literature_Dossier_Bookmarked.pdf'


def compact(s: str) -> str:
    return ' '.join((s or '').split())


def collect_bookmarks(records):
    """Read the actual COMPOSED page map, not approximated text/PDF positions.

    We make bookmarks at exact physical page starts. Section and subsection
    bookmarks point to the first composed sheet where their heading occurs.
    """
    toc = []
    chapter_seen = set()
    revision_seen = set()
    contents_seen = False
    for rec in records:
        page = rec['page']
        if rec['is_cover']:
            toc.append([1, 'Complete Literature Dossier Notes', page])
            continue
        if rec['is_contents']:
            if not contents_seen:
                toc.append([2, 'Contents', page])
                contents_seen = True
            continue
        n = rec.get('chapter')
        if n is None:
            continue
        if n not in chapter_seen:
            title = compact(rec.get('chapter_title') or ('Reading ' + str(n)))
            toc.append([2, f'Reading {n} — {title}', page])
            chapter_seen.add(n)
        is_revision = rec['is_revision']
        if is_revision and n not in revision_seen:
            toc.append([3, 'Revision & Summary', page])
            revision_seen.add(n)
        for section in rec['sections']:
            number = compact(section.get('number', ''))
            name = compact(section.get('title', ''))
            if not name:
                continue
            text = (number + '  ' + name).strip()
            toc.append([4 if is_revision else 3, text, page])
        for sub in rec['subheadings']:
            name = compact(sub)
            if name and not is_revision:
                toc.append([4, name, page])
    return toc


def layout_records(page):
    return page.evaluate('''() => [...document.querySelectorAll('#print-root > .printed-page')]
      .map((p, i) => {
        const body = p.querySelector('.printed-body');
        const num = p.getAttribute('data-print-chapter');
        const chapterTitle = p.querySelector('.chapter-title-page h1');
        return {
          page: i + 1,
          chapter: num === null ? null : Number(num),
          is_cover: !!p.querySelector('#print-book-cover'),
          is_contents: !!p.querySelector('.printed-contents-title, .printed-toc-entry'),
          is_revision: p.classList.contains('theme-ink') && num !== null,
          chapter_title: chapterTitle ? chapterTitle.textContent : '',
          sections: [...(body ? body.querySelectorAll('.page-section-heading') : [])]
              .map(e => ({number:e.querySelector('.section-number')?.textContent || '',
                          title:e.querySelector('h2')?.textContent || ''})),
          subheadings: [...(body ? body.querySelectorAll('.page-main-column > h3, :scope > h3') : [])]
              .map(e => e.textContent || '')
        };
      })''')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--html', type=Path, default=DEFAULT_HTML)
    ap.add_argument('--out', type=Path, default=DEFAULT_PDF)
    ap.add_argument('--chapters', help='Ordered selection; default reads the HTML selector (currently 1)')
    ap.add_argument('--no-revision', action='store_true')
    ap.add_argument('--no-contents', action='store_true')
    ap.add_argument('--chromium', type=Path, default=Path('/usr/bin/chromium'))
    ap.add_argument('--timeout-ms', type=int, default=12000, help='Max time for network fonts to finish')
    ap.add_argument('--font-profile', choices=['normal','offline','metric-stress','local'], default='normal',
                    help='normal tries CDN; offline uses platform fallback; metric-stress checks different font metrics')
    ap.add_argument('--report', type=Path, help='JSON verification report (default next to PDF)')
    args = ap.parse_args()
    if not args.html.exists():
        ap.error('HTML missing: run python build.py first')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    report_path = args.report or args.out.with_suffix('.verification.json')
    logs=[]
    with sync_playwright() as p:
        launch = {'headless': True, 'args': ['--no-sandbox','--disable-dev-shm-usage']}
        if args.chromium.exists():
            launch['executable_path'] = str(args.chromium)
        browser = p.chromium.launch(**launch)
        ctx = browser.new_context(viewport={'width': 1500, 'height': 950})
        pg = ctx.new_page()
        pg.on('pageerror', lambda err: logs.append(str(err)))
        if args.font_profile != 'normal':
            pg.route('https://fonts.googleapis.com/**', lambda r: r.abort())
            pg.route('https://fonts.gstatic.com/**', lambda r: r.abort())
        pg.set_content(args.html.read_text(encoding='utf-8'), wait_until='domcontentloaded', timeout=25000)
        if args.font_profile == 'local':
            # Apply the intended font faces before measuring any page. Font files
            # stay in the local build environment, never in delivered source ZIP.
            fonts_dir = ROOT / 'fonts'
            choices = [('Spectral',400,'spectral-latin-400-normal.ttf'),
                       ('Spectral',600,'spectral-latin-600-normal.ttf'),
                       ('Spectral',700,'spectral-latin-700-normal.ttf'),
                       ('Fraunces',600,'fraunces-latin-600-normal.ttf'),
                       ('Inter',400,'inter-latin-400-normal.ttf'),
                       ('Amiri',400,'Amiri-Regular.ttf')]
            missing = [nm for _,_,nm in choices if not (fonts_dir/nm).exists()]
            if missing: raise RuntimeError('Local font profile requires licensed local font sources: '+', '.join(missing))
            css=''.join("@font-face{font-family:'%s';src:url(data:font/ttf;base64,%s) format('truetype');font-weight:%s;font-display:block;}" % (fam,base64.b64encode((fonts_dir/nm).read_bytes()).decode(),w) for fam,w,nm in choices)
            pg.add_style_tag(content=css)
        if args.font_profile == 'metric-stress':
            # Only for independent QA. Keep the original final HTML untouched.
            pg.add_style_tag(content='''
              :root { --font-display: 'EB Garamond', Georgia, serif;
                      --font-body: 'Liberation Serif', Times, serif;
                      --font-utility: 'Inter', Arial, sans-serif;
                      --font-arabic: 'Amiri', 'Noto Naskh Arabic', serif;
                      --font-arabic-display: 'Amiri', serif;
                      --font-arabic-utility: 'Noto Sans Arabic', sans-serif; }
            ''')
        if args.chapters is not None:
            pg.locator('#range-spec').fill(args.chapters)
        if args.no_revision:
            pg.locator('#toggle-revision').evaluate('(e)=>{e.checked=false;e.dispatchEvent(new Event("change",{bubbles:true}));}')
        if args.no_contents:
            pg.locator('#toggle-contents-page').evaluate('(e)=>{e.checked=false;e.dispatchEvent(new Event("change",{bubbles:true}));}')
        validation = pg.evaluate('''() => ({warning: document.querySelector('#range-warning').innerText,
                             hidden: document.querySelector('#range-warning').hidden,
                             selection:document.querySelector('#range-spec').value})''')
        if not validation['hidden']:
            raise RuntimeError('Invalid chapter selection: ' + validation['warning'])
        try:
            pg.evaluate('''async (t) => Promise.race([document.fonts.ready,
                   new Promise(r=>setTimeout(r,t))])''', args.timeout_ms)
        except Exception:
            pass
        font_faces = pg.evaluate('''() => [...document.fonts].map(f=>({family:f.family,status:f.status,
                            style:f.style,weight:f.weight}))''')
        # Build only AFTER fonts are ready or timeout, so the measured layout
        # and the final PDF use precisely the same glyph metrics.
        pg.evaluate('window.DossierPrint.build()')
        diag = pg.evaluate('window.__dossierPrintDiagnostics')
        if diag.get('error') or diag.get('overflows'):
            raise RuntimeError('Compositor rejected export: ' + repr(diag))
        records = layout_records(pg)
        toc = collect_bookmarks(records)
        if not toc or toc[0][0] != 1:
            raise RuntimeError('Invalid bookmark hierarchy; missing book root')
        # Check every DOM-composed page before engaging the PDF print backend.
        dimensions = pg.evaluate('''() => [...document.querySelectorAll('#print-root > .printed-page')].map(p=>{
           const b=p.querySelector('.printed-body');return {width:p.getBoundingClientRect().width,
             height:p.getBoundingClientRect().height,overflow:b && b.scrollHeight>b.clientHeight+2};
         })''')
        if any(d['overflow'] for d in dimensions):
            raise RuntimeError('Content overflow after font readiness')
        # Capture this BEFORE CDP print: the afterprint handler clears the print DOM.
        needs_arabic = pg.locator('#print-root .arabic').count() > 0
        pg.emulate_media(media='print')
        session = ctx.new_cdp_session(pg)
        cdp = session.send('Page.printToPDF', {
            'printBackground': True,
            'preferCSSPageSize': True,
            'displayHeaderFooter': False,
            'generateDocumentOutline': True,
            'generateTaggedPDF': True,
            'transferMode': 'ReturnAsBase64'
        })
        raw = base64.b64decode(cdp['data'])
        output = fitz.open(stream=raw, filetype='pdf')
        actual_pages = len(output)
        if actual_pages != diag['pages'] or actual_pages != len(records):
            raise RuntimeError(f'Page count mismatch: physical {actual_pages}; logical {diag["pages"]}')
        if any(abs(x.rect.width - 960) > 1.1 or abs(x.rect.height - 540) > 1.1 for x in output):
            raise RuntimeError('Wrong PDF physical sheet dimensions')
        output.set_toc(toc)
        # Ask compliant PDF viewers to open with the actual bookmarks
        # sidebar visible; it is not just an in-page Contents list.
        output.xref_set_key(output.pdf_catalog(), 'PageMode', '/UseOutlines')
        output.set_metadata({
            'title': 'Complete Literature Dossier Notes',
            'author': 'Mohammed Husain Ujjainwala, TR: 25368, Hadi Ashar 1448H',
            'subject': 'Daraja Hadi Ashar — academic literature readings and revision notes',
            'keywords': 'Literature Dossier, Hadi Ashar, reading notes, revision'
        })
        output.save(str(args.out), garbage=3, deflate=True)
        output.close()
        # Reopen final file; inspect the delivered bytes rather than assumptions.
        final = fitz.open(str(args.out))
        final_toc = final.get_toc()
        if final.xref_get_key(final.pdf_catalog(), 'PageMode') != ('name','/UseOutlines'):
            raise RuntimeError('PDF does not request the bookmarks sidebar on open')
        if len(final_toc) != len(toc) or any(a[:3] != b[:3] for a,b in zip(final_toc,toc)):
            raise RuntimeError('PDF outline was not persisted correctly')
        for lev, label, pn in final_toc:
            if pn < 1 or pn > len(final):
                raise RuntimeError('Bookmark has invalid destination: ' + label)
        link_count = sum(len(x.get_links()) for x in final)
        if len(diag.get('selection', [])) > 1 and link_count < len(diag['selection']):
            raise RuntimeError('Missing PDF Contents hyperlink annotations')
        pdf_fonts = sorted({f[3] for sheet in final for f in sheet.get_fonts(full=True) if f[3]})
        has_arabic = any('Amiri' in name or 'Arabic' in name for name in pdf_fonts)
        # A future export may intentionally contain no Arabic-script passage.
        # Enforce the Arabic font only when the selected composed content uses it.
        if needs_arabic and not has_arabic:
            raise RuntimeError('Selected reading contains Arabic script but no Arabic typeface was embedded')
        result = {
            'status':'PASS','source_html':str(args.html),'pdf':str(args.out),
            'page_count': len(final), 'logical_pages':diag['pages'],
            'outline_entries':len(final_toc),'outline':final_toc,
            'internal_links':link_count,'selection':diag.get('selection',[]),
            'pdf_page_mode':'UseOutlines',
            'font_profile':args.font_profile,'loaded_web_fonts':font_faces,
            'embedded_pdf_fonts':pdf_fonts,'arabic_font_embedded':has_arabic,'arabic_font_required':needs_arabic,
            'pdf_metadata':final.metadata,
            'measured_overflow_pages':[i+1 for i,entry in enumerate(dimensions) if entry['overflow']],
            'javascript_errors':logs,
            'created_utc':datetime.now(timezone.utc).isoformat()
        }
        final.close()
        report_path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        browser.close()
    print(f'PASS: {result["page_count"]} physical pages, {result["outline_entries"]} real PDF bookmarks, '
          f'{result["internal_links"]} Contents links; {args.out}')
    print('Report:', report_path)


if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('ERROR:',str(exc),file=sys.stderr)
        raise
