# Literature Dossier | Manual batch 17–18 | Editorial and print QA

**Result: PASSED** · 5 November 2026 · Offline system-font publishing profile

## Source and scope

- Reading 17: **Cultivating Human Rights: Islamic Law and the Humanist Imperative**. Original connected Google Doc `1jkUMdjKwWdZ_0Xt6zFCv5ufEZoOoavp1mVGQYbc5DLk`, archived unchanged in `sources/17-raw-explainer.txt` (SHA-256 `929991bdfebf79bc10c2617ffbedc08daf8c273ebed3afeaa29c54130e6fead8`).
- Reading 18: **The Catcher in the Rye (Ch. 19–21)**. Original connected Google Doc `1B0v6VWc5sloT5NpzUWzktFpkvFnnRK_e6a_kA4bSrMI`, archived unchanged in `sources/18-raw-explainer.txt` (SHA-256 `749d7fa72a52383a1b7e7afc76c9e5aac6f23d729241095bfb6ad3fe30f36cc8`).
- The user's source explainers, rather than independently retrieved articles or novel chapters, are the basis of all notes. Historical/causal readings (including the claim about medieval scholars' influence on Aquinas) are treated as **the supplied author's interpretations**. No independent scholarly verification is claimed.

## Content and editorial decisions

| Criterion | Reading 17 | Reading 18 |
|---|---:|---:|
| Main notes | **5 pages** | **5 pages** |
| Main prose words excluding sidebar | 1,033 | 1,076 |
| Main sections | 7 | 6 |
| Passage anchors | 16 | 16 |
| Sidebar notes | 23 | 20 |
| Contextual memory aids | 5 | 5 |
| Scholarly/comparison tables in main content | 2 | 2 |
| Dark revision sections | 6 | 6 |

**Reading 17:** preserves antimajoritarian rights, the distinction among human/civil/group rights, classical ḥaqq/ḥuqūq, Divine Sharīʿa versus revisable fiqh, the ḥudūd/shubha evidentiary paradox, khalīfa and amāna, six protected values, the names and claims in the rationalist genealogy, colonial rupture and the internal-conviction argument. The law's historic application rates and claims about Western philosophical transmission are carefully attributed rather than independently asserted.

**Reading 18:** follows the scene progression Wicker Bar → Carl Luce → drunken “bullet” fantasy → broken Little Shirley Beans record → frozen lagoon and Allie → stealthy return home → Phoebe's notebooks and letter → expulsion and the Colorado-ranch excuse. Retains the specifics of Tina, Janine, the recognizable smell of home, elephant pajamas, Benedict Arnold, and Phoebe preserving the broken record pieces. Differentiates literary events from the source's psychological interpretations; avoids diagnosing fictional characters.

## Verified layout and navigation

- Pair PDF: **25 composed = 25 physical pages**, **31 real hierarchical bookmarks**, **2 working Contents links**. Reading 17 standalone: **13 pages, 16 bookmarks**. Reading 18 standalone: **12 pages, 15 bookmarks**.
- Full PDF: **192 composed = 192 physical pages**, **278 genuine bookmarks**, **18 Contents hyperlinks**.
- Exact passage-sidebar anchors in new pair: **43 / 43** with unique note IDs, all six semantic categories and no leftover or duplicate cards. Five collected revision memory aids in each chapter match the contextual versions exactly.
- Full book: **345 / 346** cards aligned on the page of their exact anchor; the sole exception `s4-6-n2`, inherited from Reading 04, predates this batch under offline-font metrics. No older chapter or compositor file was edited to conceal it.
- Zero detected overflow, no browser JavaScript exceptions, no horizontal scroll at 390 px mobile width. Reverse order **18,17** and alternate **metric-stress** profile: both exported **25 pages, 31 bookmarks**, no compositor failures.
- Visual audit: contact sheet includes all 10 new main-note pages. Table readability and contrasting sidebar cards inspected; a partial final main page is accepted rather than reducing font or page-break consistency.

## Source integrity and reproducibility

- The **16 earlier chapter HTML files and 7 shared publishing/index files** match the verified 01–16 ZIP byte-for-byte (23 checks).
- All new Drive exports are included untouched in the source bundle with SHA-256 identifiers above.
- `generate_readings_17_18.py` regenerates only the new chapters. `build.py` assembles the complete HTML. `export_bookmarked.py` creates final paginated PDFs with true outline entries.
- `tests/test_readings_17_18.py` passes original source hashes, chapter/prose structure, semantic types, note IDs, collected memory aids, page alignment and PDF outline assertions.
- System-font `offline` profile was used. Original stylesheet font choices remain, and pagination may differ in other environments or if proprietary fonts are supplied; never switch fonts after pagination.

## Next checkpoint

**Readings 01–18 complete. Reading 19 remains unassigned**. Resume manually with **20 — Was al-Maqrīzī’s Khiṭaṭ a Khaldūnian History** and **21 — Marriage, Divorce, and Inheritance in Classical Islamic Law and Premodern Practice**. The scheduled automation remains disabled.
