# Literature Dossier — Canonical Passage-Linked Sidebar Contract

**Status:** Production baseline for Readings 01–08, 4 November 2026. This document supersedes every historical note instructing that in-body callouts should compete with main scholarly prose or that a paragraph must wait for a taller sidebar card.

## What stays and what changes

- Keep the academic material exactly as authored: explanations, quotations, Arabic text, chronology, data tables, diagrams, qualifications, comparisons. Main prose remains the authoritative uninterrupted reading lane.
- All six semantic learning aids belong in the sidebar in the **main reading**: blue definition, green concept, amber exam tip, red common mistake, purple memory aid, gold high-yield fact. If a concept card contains argument essential for following the source, *retain the explanation in the main prose as well*, but its study card still belongs in the sidebar.
- The six *revision-zone* sections retain their full dark layout. Their own summary grids, tables, definitions, memory recaps and exam questions are not repackaged into the narrow sidebar.
- Historical chapter accent colors remain separate from the six note categories. Chapter 19 stays reserved and unfilled in the master index.

## Authoring structure and anchors

```html
<div class="section" id="s9-2">
  <div class="section-number">§9.2</div>
  <h2>Full scholarly section heading</h2>
  <div class="section-body">
    <article class="passage" data-anchor="s9-2-p0">
      <div class="prose"><p>Unabridged explanatory passage...</p></div>
      <aside aria-label="Study notes for this passage">
        <div class="callout callout--memory" data-content-type="memory" data-note-id="s9-2-n0">
          <div class="tag">Memory aid · ...</div><p>Short memory cue...</p>
        </div>
      </aside>
    </article>
    <article class="passage" data-anchor="s9-2-p1">
      <div class="prose"><p>Next explanation...</p></div>
    </article>
    <table>...Full scholarly evidence table...</table>
  </div>
</div>
```

Every card has a unique permanent `data-note-id`. A card's `data-anchor` is inherited from its containing `<article class="passage">`. Attach to the **specific paragraph, list, or evidence passage it explains**, rather than merely the correct broad section. Never make an anchor dependent on a PDF page number: those change with fonts and pagination. On mobile, notes follow their associated passage.

## Print architecture

- 16:9 physical pages: **13.333 × 7.5 inches**. The page box, header/footer and content rectangle are fixed before print measurement and match Chromium's physical sheets.
- Main reading sheets use a 306 CSS-pixel study lane plus 24 CSS-pixel gutter, with the rest for continuous narrative. Body prose uses a readable `18.3px` Spectral-based scale, `1.36` leading and tuned .50em paragraph spacing. Do not shrink body text to reduce pages.
- Paginate the **main content stream first**, at its actual print width. Keep headings with at least the start of real following content; let the next subtopic begin mid-page when it fits. Split long paragraphs, lists, and tables rather than moving whole sections gratuitously. **Never** force a page break merely because the section title changed.
- Only then place every sidebar card on a page containing its *exact passage anchor*. Treat same-section fallback as an exception requiring editorial review; fail release QA if any wrong passage remains.
- Tables and full-width evidence diagrams are **not sidebar notes**. Preserve their complete rows, cells and legible columns; when necessary add a dedicated wide-band/full-width adapter instead of squeezing them into a note card. The present eight readings contain 15 tables and two process diagrams that fit the tested narrative area.
- A reading's revision zone starts on a fresh physical sheet. Covers/openers have no running header/footer; every main and revision page does.
- Keep in-house plain JavaScript for on-screen reading and pagination. The local Python + Chromium publishing step adds actual hierarchical PDF bookmarks and performs PDF checks.

## Non-negotiable QA gates

1. Validate source paragraphs, list items, table cells, Arabic lines, and main-body callout text against source copies before accepting editorial updates. No silent shortening, rewriting or invention.
2. Every category card occurs once in the main print sidebar with a unique ID. Deliberate later copies in revision don't count as duplicates.
3. Every card is on a sheet containing its **exact** `data-anchor`; flag exceptions for review.
4. Logical pages = physical PDF pages. Zero body/notes overflow. Correct page size and running furniture.
5. Actual PDF bookmarks point to headings and Contents entries link to chapter openers; selected chapter order is respected.
6. Confirm Arabic coverage/font, full tables, mobile stacking at 390px, and test at the intended fonts and alternative metrics.
7. Preserve the current verified source ZIP in persistent storage at each batch; add readings *two at a time*, never regenerate completed chapter files or reset the shared engine.

## Production result on 01–08

At intended local font metrics: **105 pages** (same as the previous single-lane 01–08 edition), **138 PDF bookmarks**, **8 linked Contents entries**, **128 of 128 callouts in sidebars**, **128 of 128 exact passage alignments**, **0 overflows**. See `SIDEBAR_01_08_QA.md` and `tests/test_sidebar_integrity.py`.
