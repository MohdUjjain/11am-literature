"""Author only Readings 13 and 14 from their original Drive explainers.
Reuses the canonical 01–12 sidebar edition without changing existing files or publishing engine.
"""
from pathlib import Path
import html, json
ROOT=Path(__file__).resolve().parent

def P(text,*notes):
    return {'html':'<p>'+text+'</p>','notes':[dict(kind=a,title=b,body=c) for a,b,c in notes]}
def T(headers, rows, *notes):
    return {'html':'<table data-content-type="comparison" data-pagination="repeat-header"><thead><tr>'+''.join('<th>'+html.escape(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table>', 'notes':[dict(kind=a,title=b,body=c) for a,b,c in notes]}
def L(items,*notes):
    return {'html':'<ol>'+''.join('<li>'+x+'</li>' for x in items)+'</ol>','notes':[dict(kind=a,title=b,body=c) for a,b,c in notes]}
def S(title,*items):return {'title':title,'items':list(items)}

COLORS={'definition','concept','examtip','mistake','memory','highyield'}

def build(n,title,subtitle,thesis,sections,definitions,keytables,memory,questions,summary,cards,accent,source_id,file_slug):
    output=[f'<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{accent};"><div class="leaf"><div class="chapter-title-page">',
            f'<div class="reading-eyebrow">Reading {n:02d} · Literature Dossier</div><h1>{html.escape(title)}</h1>',
            f'<p class="subtitle">{html.escape(subtitle)}</p><hr class="gold-rule"/>',
            '<div class="opener-split"><div class="thesis-block"><p class="kicker">Central thesis</p>',
            '<p>'+thesis+'</p></div><div class="roadmap"><p class="kicker">In this reading</p><ol>',
            *['<li>'+html.escape(section['title'])+'</li>' for section in sections],'</ol></div></div>',
            f'<p class="source-cite">Source: supplied Drive explainer {n:02d} (Google Doc {source_id}). The original scholarly publication has not been independently checked. Interpretations and historical claims are attributed to that supplied explainer; this is not independent verification of the original publication.</p></div>']
    types={};count=0
    for i,sec in enumerate(sections,1):
        output.append(f'<div class="section" id="s{n}-{i}"><div class="section-number">§{n}.{i}</div><h2>{html.escape(sec["title"])}</h2><div class="section-body">')
        for j,item in enumerate(sec['items']):
            anchor=f's{n}-{i}-p{j}'
            output.append(f'<article class="passage" data-anchor="{anchor}"><div class="prose">{item["html"]}</div>')
            if item['notes']:
                output.append('<aside aria-label="Study notes for this passage">')
                for k,note in enumerate(item['notes']):
                    typ=note['kind'];assert typ in COLORS
                    types[typ]=types.get(typ,0)+1;count+=1
                    output.append(f'<div class="callout callout--{typ}" data-content-type="{typ}" data-note-id="{anchor}-n{k}" data-pagination="allow-split"><div class="tag">{html.escape(note["title"])}</div><p>{note["body"]}</p></div>')
                output.append('</aside>')
            output.append('</article>')
        output.append('</div></div>')
    output.extend(['</div><div class="revision-zone"><div class="revision-leaf">',f'<div class="revision-kicker">Reading {n:02d} · Revision &amp; recall</div>'])
    def R(i,title,body):return f'<div class="section" id="s{n}-rev-{i}"><div class="section-number">REV {i:02d}</div><h2>{title}</h2><div class="section-body">{body}</div></div>'
    output.append(R(1,'Chapter Summary','<p>'+summary+'</p>'))
    output.append(R(2,'One-Page Revision Sheet','<div data-pagination="keep-together"><div class="revision-grid">'+''.join(f'<div class="revision-card"><h3>{h}</h3><p>{b}</p></div>' for h,b in cards)+'</div></div>'))
    output.append(R(3,'Key Definitions',T(['Term','Meaning in this reading'],definitions)['html']))
    output.append(R(4,'Key Tables',keytables))
    output.append(R(5,'Memory Aids','<div class="callout-grid">'+''.join(f'<div class="callout callout--memory" data-content-type="memory" data-pagination="allow-split"><div class="tag">Memory aid · From §{n}.{i} · {h}</div><p>{b}</p></div>' for i,h,b in memory)+'</div>'))
    output.append(R(6,'Possible Examination Questions','<div class="revision-grid exam-question-grid">'+''.join(f'<div class="exam-q"><span class="qtype">{cat}</span><p>{q}</p></div>' for cat,q in questions)+'</div>'))
    output.extend(['</div></div></section>'])
    p=ROOT/'chapters'/f'{n:02d}-{file_slug}.html';p.write_text(''.join(output),encoding='utf8')
    return dict(reading=n,file=p.name,sections=len(sections),passages=sum(len(s['items']) for s in sections),notes=count,note_types=types,revision_sections=6,memory_aids=len(memory))


# Reading 13 — literary interpretation from the supplied Part 1 explainer.
sec13=[
 S('Himmel Street: How Words Shelter a Hidden Life',
   P('At <strong>33 Himmel Street</strong>, hiding Max Vandenburg places the Hubermanns and Liesel Meminger under continuous danger. The source’s account calls the arrangement a gamble—“roll a die by hiding a Jew”—because an ordinary action can become evidence of resistance under Nazi rule. Within the basement’s confinement, Liesel and Max try to preserve a sense of personhood that state propaganda would erase. Their bond is built not on grand speeches but on the <strong>“quiet gathering of words”</strong>: reading, description, word games and the images they generate.',
     ('concept','Central argument · Words as counterpower','The same medium that spreads propaganda can sustain intimacy, imaginative freedom and a threatened identity.'),
     ('examtip','Literary method · Explain the mechanism','Name the object or scene, describe its action, then show how that action protects or changes the characters.')),
   P('The analysis therefore follows a deliberately small sequence of household scenes from <strong>April to May 1941</strong>: grooming, newspapers, a weather report and Max’s imagined fight with Hitler. The large political conflict is never absent, yet the novel makes it intelligible through a hidden body, an empty crossword, a painted wall and a crowd persuaded by a leader’s words. <strong>Death</strong>, the narrator identified by the source, frames these episodes against the wider violence of the war.',
     ('highyield','Evidence map · Four objects','Scissors, newspaper/crossword, wall and boxing ring: trace the movement from ordinary acts to narrative resistance.'))),
 S('April 1941: A Haircut Performed Under Threat',
   P('In mid-April the household attempts to “mimic normality,” even though the man downstairs must remain invisible. Max asks to have his hair cut. Liesel, the person he regards as the “calmest option,” uses <strong>rusty scissors</strong> whose blades grind rather than snip through his hair. Grooming is a fragile claim to ordinary life: treating Max as someone who needs a haircut momentarily replaces the category of dangerous secret with that of a person who can be cared for.',
     ('definition','Device · Ordinary ritual made symbolic','A haircut functions as both practical care and a sign that Max still belongs to human time.'),
     ('memory','Memory aid · Hair → Heat → Hiding','<strong>Cut</strong> Max’s hair → <strong>burn</strong> the tufts → protect the <strong>hidden</strong> person.')),
   P('Afterward Liesel carries the discarded hair upstairs and burns it in the stove; the strands shrivel and disappear in orange-red flame. The gesture is tender <em>and</em> perilous: the family must destroy visible proof of the life it seeks to preserve. The source also sketches the household’s protective roles. <strong>Hans</strong> offers quiet steadiness, <strong>Rosa</strong> masks anxiety with noisy domestic bustle, and <strong>Liesel</strong> makes contact possible. None can treat this as harmless routine.',
     ('mistake','Common mistake · Do not romanticize the ritual','The haircut does not remove danger; destroying the hair is evidence of how acute that danger remains.'))),
 S('Early May: The Secret and the Newspaper',
   P('By early May, Liesel experiences the hidden guest as a bodily secret. In the mayor’s library it “sat in her mouth,” even crossing its legs: <strong>personification</strong> makes silence feel like a resident she cannot expel. She responds not by confiding in someone but by carrying found newspapers, especially the <em>Molching Express</em>, to Max. A day with a newspaper is good; one whose <strong>crossword is still empty</strong> is better. The unused grid offers him a modest arena for thought and choice.',
     ('definition','Technique · Personification of a secret','An unsaid truth is presented as a body that occupies Liesel’s mouth and mind.'),
     ('memory','Memory aid · Find → Fill → Freedom','Find a discarded paper → Max fills an empty grid → he briefly regains agency.')),
   P('The scene reverses the purposes of public print. A disposable newspaper, circulating in a world saturated by political messages, becomes a private gift of attention. The source contrasts bonds formed through different media: <strong>Hans and Erik Vandenburg</strong> are connected through music, whereas Max and Liesel become close through the “noise of turning pages” and words collected quietly. The point is not that a crossword defeats the regime; it is that a constrained person can still exercise a mind.',
     ('concept','Key idea · Public print, private intimacy','The newspaper’s civic/public function is repurposed into a form of care and cognitive refuge.'))),
 S('Mid-May: Reporting the Sky and Writing on the Wall',
   P('The basement’s cement, dimness and isolation color Max’s experience of himself. He asks Liesel for something seemingly minimal—a <strong>weather report</strong>. She returns from outside with a child’s metaphor: a long cloud stretches “like a rope” and the sun appears “like a yellow hole.” Rather than relay meteorological data, she makes the inaccessible sky imaginable, transporting an impression of the outside world into the room.',
     ('memory','Memory aid · Sky → Speech → Wall','Liesel <strong>sees</strong> the sky → <strong>describes</strong> it → Max <strong>paints</strong> their image.'),
     ('highyield','Textual image · Yellow hole','The sky becomes visible to Max through Liesel’s metaphor, not through direct sight.')),
   P('Max paints the shared vision on the wall and gives it a short story: “It was a Monday, and they walked on a tightrope to the sun.” The movement <strong>perception → metaphor → painting</strong> matters because each person adds something the other cannot provide alone. Liesel supplies lived contact with the weather; Max gives that fleeting report a permanent, fantastic form. The wall that confines him is also turned into a place where another world can appear.',
     ('concept','Interpretation · The boundary becomes a canvas','The wall’s material role as confinement persists, but shared art gives it a second imaginative function.'))),
 S('Late May: Max Imagines Boxing the Führer',
   P('Max invents an internal boxing match against <strong>Adolf Hitler</strong> as a way to fight the command that he should disappear. The imagined encounter is radically unequal: Hitler arrives with a team, robe, crowd and the appearance of effortless authority; Max is a weary, twenty-four-year-old challenger without an entourage. The fantasy sharply exposes power as spectacle rather than an even contest. Max notices, with bitter irony, that Hitler’s eyes are brown, “like Jews’ eyes,” disrupting the racial categories the dictator promotes.',
     ('definition','Literary structure · Internal arena','An imagined confrontation makes Max’s psychological resistance visible to the reader.'),
     ('mistake','Interpretation · It is an imagined fight','Do not narrate the boxing encounter as an event occurring outside Max’s mind.')),
   T(['Staged contrast','Hitler: propagandistic spectacle','Max: vulnerable challenger'],[
     ['Support','Entourage, Goebbels, cheering crowd','Alone, no entourage or robe'],
     ['Appearance','Red-and-white robe, swastika, “undefeated” image','Bare chest, gray shorts, exhausted feet'],
     ['Movement','Bounces confidently before spectators','Conserves his scarce energy']],
     ('highyield','Table reading · Power imbalance','Physical resources are unequal before any blows; the crowd is the decisive reserve.')),
   P('When the physical fight no longer serves him, Hitler removes his gloves and addresses the spectators. His words become visible “jewels”; the audience turns into “human ghouls” and Max feels the <strong>“fists of an entire nation.”</strong> The source’s crucial claim is that the Führer wins by <em>rhetoric</em>: propaganda converts listeners into participants in violence. Words are not inherently benevolent; the novel juxtaposes their power to dehumanize with their power to sustain.',
     ('memory','Memory aid · Gloves → Jewels → Crowd','<strong>Gloves</strong> fail → verbal <strong>jewels</strong> fall → the <strong>crowd</strong> becomes the weapon.'),
     ('examtip','Compare the two uses of words','Oppose Hitler’s speech mobilizing a crowd to Liesel’s weather metaphors and shared crosswords.')),
   P('Liesel enters the imagined ring carrying an <strong>empty crossword</strong>, and the dark fantasy breaks. This is no simple physical victory over Hitler. The same small gift that kept Max thinking in the basement interrupts an imagined world of collective violence. The closing “Just basement. Just Jew.” restores the actual condition of confinement while showing how much the fragile relationship has done within it.',
     ('concept','Crux · Return without rescue','The crossword returns Max to reality; neither the danger nor the political persecution has vanished.'))),
 S('Objects Transformed: A Household Vocabulary of Resistance',
   P('The argument gathers force because ordinary objects acquire new functions while keeping their material constraints. Scissors still cut hair that must be disposed of, a newspaper remains discarded print, a wall still confines, and a crossword still demands answers. Yet each can be <strong>reinterpreted through care</strong>. Their transformation is the novel’s practical model of narrative agency: the characters cannot rewrite national law, but they can alter what a household action means to the person enduring it.',
     ('memory','Memory aid · Four changed objects','<strong>Scissors → trust; Paper → attention; Wall → vision; Crossword → agency.</strong>')),
   T(['Object','Ordinary or threatening function','Humanizing transformation'],[
     ['Scissors','Haircut plus evidence that must be destroyed','An act of grooming and trust'],
     ['Newspaper','Discarded mass communication','A gift that engages Max’s mind'],
     ['Basement wall','Cement boundary of confinement','Painted record of a shared sky'],
     ['Crossword','Small word puzzle','A return to reality and private agency']],
     ('highyield','Evidence · Things remain double-edged','The same object can carry danger and care at once; that tension makes the symbolism persuasive.'))),
 S('Conclusion: Syllables Against the Shadows',
   P('The supplied analysis sees the relationship between Liesel and Max as an act of <strong>mutual narrative reconstruction</strong>. With Death recounting their world, intimate objects and language become measures of humanity under a regime that deploys public words to deny it. The haircut normalizes, the newspaper connects, the sky-image opens a window, and the crossword punctures Max’s fantasy of ideological defeat. Their acts do not dissolve confinement; they keep the possibility of personhood alive within it.',
     ('examtip','Essay plan · Four moments, one claim','Lead with the secrecy and risk; trace haircut → paper → sky → boxing; conclude with words’ opposing political and intimate powers.')))
]
mem13=[
 (2,'Hair, heat, hiding','<strong>Cut</strong> the hair → <strong>burn</strong> the tufts → protect the <strong>hidden</strong> life.'),
 (3,'Find, fill, freedom','Discarded newspaper → <strong>empty crossword</strong> → limited mental freedom.'),
 (4,'Sky, speech, wall','What Liesel <strong>sees</strong> becomes what she <strong>says</strong> and Max <strong>paints</strong>.'),
 (5,'Gloves, jewels, crowd','Hitler <strong>drops gloves</strong> → speaks verbal <strong>jewels</strong> → mobilizes a <strong>crowd</strong>.'),
 (6,'Four altered objects','<strong>Scissors → trust; Paper → attention; Wall → vision; Crossword → agency.</strong>')
]
rev13_table=T(['Narrative scene','What happens','Why it matters'],[
  ['April haircut','Liesel cuts Max’s hair; tufts are burned','Care and secrecy cannot be separated.'],
  ['May newspaper','Liesel finds the Molching Express, ideally with an empty crossword','A threatened mind gains agency and connection.'],
  ['Weather and wall','Liesel describes the sky; Max paints the metaphor','Language turns an inaccessible reality into shared art.'],
  ['Imagined boxing match','Hitler uses speech and spectators; Liesel returns with the crossword','Propaganda destroys, while interpersonal words recall Max to personhood.']])['html']
# Avoid a second conclusion that merely repeats the newly introduced artifacts
# comparison and the opener; preserve its distinct ethical emphasis inline.
assert sec13[-1]['title']=='Conclusion: Syllables Against the Shadows'
sec13.pop()
sec13[-1]['title']='Objects Transformed: The Household’s Vocabulary of Resistance'
sec13[-1]['items'][0]['html']=sec13[-1]['items'][0]['html'].replace(
    'to the person enduring it.',
    'to the person enduring it. Through Death’s narration, these small acts protect human presence, not safety itself, against the regime’s effort to erase the individual.')
res13=build(13,'The Book Thief (Part 1)','Scissors, newspapers, painted skies and the rhetoric of survival',
 'Across the scenes of Liesel Meminger and the hidden Max Vandenburg, the supplied explainer explores how <strong>ordinary words and household objects defend human presence</strong> against Nazi propaganda. Language can also be mobilized as a weapon: Max’s imagined boxing match exposes this double-edged power.',
 sec13,
 [('Narrative agency','The limited ability to give events new meaning by shaping or sharing stories.'),('Personification','Treating an abstraction as a person, as when Liesel’s secret sits in her mouth.'),('Metaphor','Speaking of one thing as another; the sun becomes a “yellow hole.”'),('Imagined arena','Max’s mental boxing match in which political conflict becomes a dramatic contest.'),('Propaganda','Mass persuasive speech or images deployed to organize belief and behavior.'),('Quiet gathering of words','The phrase used for Liesel and Max’s bond through books, pages and language.'),('Crossword','A newspaper puzzle that becomes a symbol of Max’s mental agency and return to reality.')],
 rev13_table,mem13,
 [('Narrative analysis','Why does the haircut matter more than ordinary grooming?'),('Close reading','Analyze the personification of the secret in Liesel’s mouth.'),('Symbolic interpretation','How does the weather report become a painted “tightrope to the sun”?'),('Comparison','Contrast Hitler’s verbal “jewels” with Liesel’s use of language.'),('Evidence question','Explain why the empty crossword reappears in Max’s fantasy.'),('Long essay','How do four ordinary objects allow Liesel and Max to preserve humanity without eliminating their danger?')],
 'The supplied account follows Liesel Meminger and Max Vandenburg in the Hubermanns’ hidden basement in spring 1941. A haircut simultaneously offers dignity and creates evidence that must be burned. Discarded newspapers, especially unsolved crosswords, preserve Max’s attention and establish a bond through words. Liesel’s description of a rope-like cloud and yellow-hole sun becomes Max’s painting on the wall. In an imagined boxing match, Hitler’s propaganda converts the audience into an instrument of violence; Liesel interrupts the fantasy with another empty crossword. These scenes show that language can either mobilize dehumanization or protect fragile personhood. The danger is never removed, but the characters reclaim small forms of agency and meaning.',
 [('Central thesis','Shared words protect human presence, but public language can also destroy it.'),('Domestic objects','Haircut and newspaper: care inseparable from concealment and risk.'),('Transformations','Observed sky → child’s metaphor → painted basement world.'),('Two rhetorical powers','Hitler weaponizes the crowd; Liesel’s crossword recalls Max to reality.')],
 '#806C8F','1inuwDEkCWK5Y84J9Sj-GeWhbsP1m8WLmSn0kTqsvc9E','book-thief-part-1')

# Reading 14 — source-derived pedagogy, distinguishing the final argument from the earlier epilogues.
sec14=[
 S('Why an Ending Can Be a New Beginning',
   P('The anonymous <em>Ikhwān al-Ṣafāʾ</em> (Brethren of Purity), associated in the supplied account with tenth-century Basra and a Shīʿī/Ismāʿīlī intellectual milieu, produced an encyclopaedic collection of <strong>52 epistles</strong>. The explainer’s guiding question is not simply what the treatises taught, but <em>what their final paragraphs were designed to do to the reader</em>. Their endings refuse the role of mere summaries: they encourage an intellectual and spiritual transition from knowledge possessed in theory to a way of life practiced deliberately.',
     ('concept','Thesis · Closure as instruction','A textual ending is an invitation to further learning and spiritual action—not just the last item of information.'),
     ('examtip','Analytical question · What does an ending cause?','Compare the audience’s intended response to each epilogue, not only the topics mentioned.')),
   P('The supplied trajectory passes from <strong>Epistle 7</strong> on scientific or theoretical arts to <strong>Epistle 8</strong> on practical crafts, then to the culminating prayer in the animal trial of <strong>Epistle 22</strong>, and finally to the programme recalled in <strong>Epistle 52</strong>. The core problem is pedagogical: how can exposition become persuasion, and how can the learner move from intellectual understanding toward salvation? The source attributes a late tenth-century definitive form to the collection; that chronology is presented here as its claim.',
     ('highyield','Four textual stops','<strong>7</strong> studies; <strong>8</strong> makes; <strong>22</strong> dramatizes; <strong>52</strong> commissions the reader to act.'))),
 S('The Soul, the Sciences and the Brethren’s Mission',
   P('For the Brethren, in the account’s Aristotelian–Neoplatonic framing, knowledge begins as a capacity within the soul—<strong>potentiality</strong>—and is realized through education—<strong>actuality</strong>. The sciences feed this transformation, dispelling the “darkness of ignorance” and preparing the soul for ascent to the higher spheres. Learning is thus an ethical and eschatological project: it alters the learner and orients a life, not merely a collection of propositions.',
     ('definition','Term · Potentiality / actuality','A capacity to know becomes realized through learning and practice.'),
     ('memory','Memory aid · Capacity → Study → Practice','<strong>Potential</strong> knowledge receives the <strong>food of sciences</strong> and becomes <strong>lived wisdom</strong>.')),
   P('The supplied explainer also stresses the Brethren’s “receptivity to otherness”: Greek argument, Persian and Indian learning, and the Torah and Gospels are discussed within an Islamic intellectual synthesis. The writers address “brethren and friends” and cast education as a shared pursuit. Their anonymous collective voice is therefore important to the argument: the purpose is to bring others into a community of inquiry oriented toward an eventual meeting with the divine.',
     ('concept','Key concept · A learning community','The ending addresses companions and recruits them into continuing study, not isolated private enlightenment.'))),
 S('Epistle 7: Scientific Arts and the Ascending Soul',
   P('Epistle 7, <em>Fī l-ṣanāʾiʿ al-ʿilmiyya wa-l-gharaḍ minhā</em> (“On the Scientific Arts and Their Aim”), locates the arts of knowledge within the reform of human dispositions. Its end-goal is <em>al-tafaqquh fī l-dīn</em>, deep understanding of religion with consequences for the afterlife. The epilogue does not re-list the sciences. It addresses the reader directly, calling the negligent to awaken, beginners to seek guidance, companions to share their learning, and everyone to pursue the “last abode.”',
     ('definition','Term · Al-tafaqquh fī l-dīn','Profound understanding of matters of religion, treated as an aim of study.'),
     ('highyield','Key shift · Map becomes summons','The epilogue turns a hierarchy of disciplines into a spiritual programme for the learner.')),
   L(['<strong>Awaken:</strong> rouse the negligent from intellectual passivity.','<strong>Guide:</strong> orient beginners within the sciences.','<strong>Interest:</strong> kindle desire for the “last abode.”','<strong>Path:</strong> offer a shared way toward blessedness.'],
     ('memory','Memory aid · The four verbs of Epistle 7','<strong>Awaken → Guide → Stir → Path.</strong> An epilogue recruits the reader into a journey.')),
   P('The rhetoric is deliberately affective as well as conceptual. To “renounce this world” or “draw nearer to God” is not offered as a detached definition; it is a request that the reader change direction. Epistle 7 therefore exemplifies how <strong>reasoned instruction ends in moral appeal</strong>. Its conclusion measures success by the transformation it initiates in the reader rather than by tidy closure.',
     ('mistake','Common mistake · Not just a syllabus','The four goals are audience-directed actions; treating them as a list of subjects misses the argument.'))),
 S('Epistle 8: Practical Crafts as Visible Evidence',
   P('Epistle 8, “On the Practical Crafts,” moves from scientific study to the handling of material substances. By observing the craftsman use reason, the senses and tools to reshape matter, the Brethren see <strong>visible evidence for active spiritual essences</strong>. The craft is not praised merely for usefulness: human making supplies an analogy for how the Universal Soul gives form and order to the natural world. In the supplied account, practical skill makes an otherwise elusive metaphysical claim accessible to the learner.',
     ('concept','Core analogy · Craftsman and Universal Soul','Visible transformation of matter becomes an argument for unseen spiritual agency.'),
     ('memory','Memory aid · Craft → Spirit → Nomos','<strong>Made thing</strong> points to <strong>active essence</strong>; <strong>Divine Law</strong> guides those who cannot reach philosophy’s summit.')),
   T(['Dimension','Scientific arts — Epistle 7','Practical crafts — Epistle 8'],[
     ['Primary instrument','Intellect, logic and demonstration','Physical tools and bodily action'],
     ['Mode of learning','Refining the soul through thought','Seeing, imitating and making'],
     ['Main evidence','Knowledge moves toward actuality','Material change indicates active essences'],
     ['Stated horizon','Soul’s ascent and religious understanding','Happiness through knowledge and <em>Nomos</em>']],
     ('highyield','Table reading · Different routes, shared end','Theory and craft differ in method but converge on education’s spiritual destination.')),
   P('Its closing mention of <em>al-nāmūs al-ilāhī</em>, or <strong>Divine Law / Nomos</strong>, adds a practical alternative. Since not everyone can attain the highest philosophical comprehension, prophetic ethical and legal instruction can keep a soul from the “abyss of the world of bodies.” The ending thus widens access to spiritual improvement: it joins speculative excellence to a rule of conduct available to learners of differing abilities.',
     ('definition','Definition · Al-nāmūs al-ilāhī','Divine Law: ethical and legal guidance associated with prophetic revelation.'),
     ('examtip','Interpret Epistle 8’s ending','Explain both parts: the craftsman analogy <em>and</em> the turn to Divine Law for wider guidance.'))),
 S('Epistle 22: An Animal Trial Ends in Prayer',
   P('Epistle 22’s lengthy animal fable stages a trial before the <strong>King of the Jinn</strong>. Shipwrecked humans claim mastery over the animals of an island; animals and humans contest the grounds of that claim. The source emphasizes the dramatic close: the court falls silent before an apparently intractable conflict between human pretension and animal right. This narrative supplies a different educational setting from the abstract disciplines and practical crafts of Epistles 7 and 8.',
     ('highyield','Scene · Who litigates where?','Humans and animals dispute dominion before the King of the Jinn; the end reorients the reader.')),
   P('The source describes a learned human speaker called “Muhammad” giving the closing praise, followed by a prayer for readers to comprehend the text, have their hearts opened, and <strong>put its insights into practice</strong>. Praise orders prophets, imams, sages and saints within a spiritual hierarchy; prayer converts the unresolved tension of courtroom reasoning into an appeal for inward transformation. The ending does not simply award human superiority by argument. Instead, the reader is made responsible for an ethical response.',
     ('memory','Memory aid · Trial → Silence → Praise → Prayer','The final sequence shifts from dispute about rights to the reader’s spiritual task.'),
     ('mistake','Avoid a simplistic verdict','The supplied account stresses a rhetorical transition at the ending; it does not justify inventing a neat legal decision on animal rights.'))),
 S('Logos, Ethos and Pathos: The Mechanics of Persuasion',
   P('The explainer uses the classical rhetorical categories <em>logos</em>, <em>ethos</em> and <em>pathos</em> to show why an educational conclusion can persuade rather than merely inform. <strong>Logos</strong> organizes demonstrations and classifications; <strong>ethos</strong> establishes the trustworthiness of the Brethren’s moral voice; <strong>pathos</strong> invokes sympathy, hope and fear of the soul’s fate. These modes work together: a well-argued proposition still needs a reader willing to pursue it.',
     ('definition','Definitions · Three appeals','<strong>Logos:</strong> reasoning; <strong>ethos:</strong> credibility; <strong>pathos:</strong> emotional direction.'),
     ('memory','Memory aid · L–E–P','<strong>Logic → Ethical speaker → Personal motivation.</strong> This is a reading tool, not three separate doctrines.')),
   T(['Appeal','How the ending works','Illustrative source material'],[
     ['Logos','The claim receives organized proof','Hierarchies of knowledge; crafted objects as evidence'],
     ['Ethos','The speaker models a trustworthy ethical purpose','Address to “brethren”; concern for guidance'],
     ['Pathos','The reader is invited to want or fear an outcome','Prayer, spiritual hope, awakening from ignorance']],
     ('examtip','Comparative exam answer','Identify a distinct example of each appeal in Epistles 7, 8 and 22.')),
   P('The source attributes to al-Fārābī the distinction that <strong>persuasion belongs to rhetoric as teaching belongs to demonstration</strong>. The Brethren do not discard rigorous argument; they supplement it with appeals that help knowledge become chosen action. The account interprets this as creating room for the reader’s voluntary response rather than simply enforcing agreement.',
     ('concept','Why combine the three?','A rational conclusion must reach the learner as a person capable of choosing to act.'))),
 S('Epistle 52: Persuasive and Sufficient',
   P('At the end of Epistle 52 the supplied account highlights the phrase <em>maqnaʿ wa-kifāya</em>—<strong>persuasive and sufficient</strong>. The text reflects upon the preceding epistles and states that its educational objective has been reached. Yet the conclusion remains forward-looking: what has been learned should supply the grounds, incentives and direction for spiritual practice beyond the page. The book’s boundary becomes a point of departure rather than an intellectual stopping-place.',
     ('definition','Term · Maqnaʿ wa-kifāya','A formulation describing material that is persuasive and sufficient for learning in the source’s concluding excerpt.'),
     ('mistake','Common mistake · 52 does not merely recap','It declares adequacy in order to turn the reader toward action and further reflection.')),
   L(['<strong>Reason:</strong> restate why study was undertaken.','<strong>Recall:</strong> bring forward the decisive arguments.','<strong>Benefit:</strong> tell the learner what transformation matters.','<strong>Path:</strong> direct the learner toward divine wisdom and practice.'],
     ('memory','Memory aid · R–R–B–P','<strong>Reason → Recall → Benefit → Path.</strong> Four functions of a persuasive textual ending.'))),
 S('Conclusion: What the Last Paragraph Begins',
   P('Read together, the four epilogues show a progression from learning’s aim (7), through material demonstration and accessible ethical law (8), to emotionally charged narrative prayer (22) and a final declaration of adequacy that calls for practice (52). The claim is <strong>not that argument and emotion are rivals</strong>, but that teaching becomes effective when rational account, credible address and emotional motivation work together. The ending is thus an instrument of education: it places responsibility for the next stage in the hands of the reader.',
     ('examtip','Thesis for an essay','Show how 7 → 8 → 22 → 52 shifts from knowledge to practice through different kinds of persuasion.')))
]
mem14=[
 (2,'Potential to practiced','<strong>Capacity → Science → Actuality → Practice.</strong>'),
 (3,'Four aims of Epistle 7','<strong>Awaken → Guide → Stir → Path.</strong>'),
 (4,'Craft and spiritual law','<strong>Craft → Spirit → Nomos.</strong>'),
 (5,'Animal trial’s ending','<strong>Trial → Silence → Praise → Prayer.</strong>'),
 (6,'Three rhetorical appeals','<strong>L–E–P:</strong> Logic, Ethical speaker, Personal motivation.'),
 (7,'How a final paragraph persuades','<strong>Reason → Recall → Benefit → Path.</strong>')
]
rev14_table=T(['Epistle','Subject of analysis','Function of its ending'],[
  ['7','Scientific arts','Awakens and guides the learner toward spiritual understanding.'],
  ['8','Practical crafts','Makes unseen agency intelligible, then offers Divine Law.'],
  ['22','Animals against humanity before the King of the Jinn','Moves from courtroom silence to praise and prayer for practice.'],
  ['52','Concluding claim about the whole collection','Calls the material persuasive and sufficient; shifts reflection into action.']])['html']
# Editorial consolidation: the source's separate closing recap repeats all four
# already-explained epilogues. Preserve its unique contrast between rational
# and emotional appeals in the Epistle 52 paragraph; place the complete
# standalone synthesis in the unchanged Chapter Summary revision section.
assert sec14[-1]['title']=='Conclusion: What the Last Paragraph Begins'
sec14.pop()
sec14[-1]['title']='Epistle 52: Persuasive, Sufficient, and a New Beginning'
sec14[-1]['items'][0]['html']=sec14[-1]['items'][0]['html'].replace(
    'rather than an intellectual stopping-place.',
    'rather than an intellectual stopping-place. Across the epilogues, rational argument and emotional motivation cooperate rather than compete.')
res14=build(14,'Textual Endings as Persuasive Educational Beginnings: An Inquiry into the Epistles of the Brethren of Purity',
 'The Brethren of Purity turn the last paragraph into an invitation to transform the soul',
 'In the supplied analysis of the <em>Rasāʾil Ikhwān al-Ṣafāʾ</em>, textual endings are <strong>pedagogical beginnings</strong>. Across Epistles 7, 8, 22 and 52, arguments, craft analogies, narrative prayer and rhetorical persuasion invite readers to turn knowledge into spiritual practice.',
 sec14,
 [('Rasāʾil Ikhwān al-Ṣafāʾ','The Brethren’s encyclopaedic collection of fifty-two epistles.'),('Potentiality / actuality','The distinction between a capacity and its realization through learning.'),('Al-tafaqquh fī l-dīn','Deep understanding of religious matters, linked to the ultimate aim of study.'),('Awḍaḥ al-dalāʾil','“Clearest evidence”: the source’s characterization of the practical arts as signs of spiritual agencies.'),('Anima Mundi / Universal Soul','Metaphysical principle to which the source compares spiritual activity in nature.'),('Nomos / al-nāmūs al-ilāhī','The Divine Law revealed by prophets as ethical guidance.'),('Logos / ethos / pathos','Appeals to reasoning, ethical credibility and emotion.'),('Maqnaʿ wa-kifāya','Material deemed persuasive and sufficient for the learner.'),('Zulūmāt al-jahāla','“Darkness of ignorance,” overcome through the sciences and spiritual practice.')],
 rev14_table,mem14,
 [('Core claim','Why can an epilogue be an “educational beginning” rather than a summary?'),('Comparison','Contrast the learner-directed aims of Epistles 7 and 8.'),('Narrative reading','How does the animal trial’s ending lead from courtroom silence to prayer?'),('Rhetorical method','Explain logos, ethos and pathos using examples from the Brethren’s epilogues.'),('Terminology','Explain al-tafaqquh fī l-dīn, Nomos and maqnaʿ wa-kifāya.'),('Long essay','Trace how Epistles 7, 8, 22 and 52 shift a reader from potential knowledge to action.')],
 'The source argues that conclusions of the <em>Rasāʾil</em> recruit rather than dismiss their readers. Knowledge begins as potential and should become actual through education and action. Epistle 7 ends by awakening, guiding and inspiring students of the sciences; Epistle 8 uses crafts as evidence for active spiritual essences and offers Divine Law as ethical guidance. The dramatic animal trial of Epistle 22 turns an unresolved dispute into praise and a prayer for deeper understanding and practice. Logos, ethos and pathos explain how demonstrations, credible moral voices and emotional appeals cooperate. Epistle 52 names the curriculum <em>maqnaʿ wa-kifāya</em>, persuasive and sufficient, so that the end of the book becomes the beginning of changed conduct.',
 [('Central proposition','The conclusion is where exposition becomes persuasion and practice.'),('Soul and learning','Potentiality requires scientific study to become actuality.'),('Four epilogues','7 = awaken; 8 = craft and law; 22 = prayer; 52 = commission.'),('Rhetorical method','Logos proves; ethos persuades trust; pathos motivates response.')],
 '#926B79','16txWg8e2Gd-e2YtRho9Z-4MjdsdEZsQ6EqW603YDlxQ','textual-endings-ikhwan')

manifest={
  'batch':[13,14],
  'source_ids':{'13':'1inuwDEkCWK5Y84J9Sj-GeWhbsP1m8WLmSn0kTqsvc9E','14':'16txWg8e2Gd-e2YtRho9Z-4MjdsdEZsQ6EqW603YDlxQ'},
  'source_files':['sources/13-raw-explainer.txt','sources/14-raw-explainer.txt'],
  'chapter_stats':[res13,res14],
  'policy':'Five-main-page editorial target, six where needed; exact-passage note ownership; no global layout changes; original Drive explainer archived untouched.'
}
import hashlib
manifest['source_sha256']={str(n):hashlib.sha256((ROOT/'sources'/f'{n:02d}-raw-explainer.txt').read_bytes()).hexdigest() for n in (13,14)}
(ROOT/'NEW_READINGS_13_14_MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
