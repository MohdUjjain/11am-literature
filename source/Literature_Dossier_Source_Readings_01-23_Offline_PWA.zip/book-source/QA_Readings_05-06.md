# Readings 05–06 — validation report

Date: 4 November 2026 (India)

## Deliveries
- Cumulative Readings 01–06 PDF: 79 physical/composed pages, 102 real outline entries, 6 Contents links.
- Readings 05–06 PDF: 29 physical/composed pages, 43 outline entries, 2 Contents links.
- Reversed 6,5 export without revisions, alternate font metrics: 19 pages, 29 outline entries; passed.
- All exports: zero measured overflows; zero recorded JavaScript errors; 960 × 540 pt landscape pages.

## Content and preservation
Every supplied paragraph, list item and table cell in 05–06 checked against rendered chapter HTML. Each reading: 8 main sections, all 6 revision sections, all 6 semantic categories, 5 in-text memory aids repeated in revision, 6 exam questions. Readings 01–04 and shared CSS, engine, cover and template compared byte-for-byte with the uploaded ZIP: unchanged. Earlier content regression tests pass; the four-reading test's fixed edition-size assertion was generalized for appended chapters.

## Visual and typography review
Rendered new-reading pages reviewed as contact sheets; detailed checks included text, table, dark revision and one-page recall layouts. The one-page revision grids initially split; new chapter wrappers now keep each complete grid on one page. No shared compositor change. New callout labels use category text rather than unsupported emoji glyphs. Intended Fraunces, Spectral and Inter are embedded, with Amiri embedded for earlier Arabic passages. Some extended glyphs still use fallback fonts; not every glyph is guaranteed to use the primary family. Local font setup and font files are included for reproducibility.

## Source limitations
These notes preserve the supplied explanatory Google Docs; the journal articles have not been independently verified. Reading 06's “Ottoman” troop label and AH/AD dates are flagged for checking. Its 466/1073 arrival date conflicts with Reading 02's 466/1074; the discrepancy is disclosed rather than silently reconciled. The grain-stock anecdote is retained as explicitly hyperbolic. Reading 05's etymology and “post-colonial” label are attributed to the explainer.

## Continuation
Next pair: 07–08. Reading 19 remains reserved. Recover from the source ZIP containing this report and progress.json, not from the earlier 01–04 or old petition sources.
