# Literature Dossier — Readings 11–12 QA and Editorial Record

## Manual production checkpoint

Two source Google Docs read directly from the supplied Drive folder; their **unmodified plain-text exports** are included in `sources/`.

| Reading | Source Google Doc ID | Notes | Main pages | Main tables | Memory aids | Revision sections |
|---|---|---:|---:|---:|---:|---:|
| 11 — Homicide in Islamic Law | `1M5PlDRwfk-2nzDFz7MdjGsBXAvBuFR8tbaHQucBkSZ4` | 21 | 5 | 4 | 5 | 6 |
| 12 — Jews and the Fatimid Caliphate | `12znJEOq3lp-e_iyu_kJAFtnolW72M5pTJPC0di0pP9g` | 21 | 4 | 1 | 5 | 6 |

All six recurring callout categories appear within each reading's sidebar: definition, concept, exam tip, common mistake, memory aid, high-yield. The 42 new cards are attached to exactly identified passages, not merely the same broad topic. Collected memory-aid lists repeat the five cues from the main reading.

## Editorial decisions

**11:** The supplied explainer distinguishes family-held retaliation from public crime; the main text keeps the tribal restrictions, the four-school diya/remission comparison, gender/religion/freedom and ascendant status, the five Ḥanafī homicide grades, poisoning and neglect, <em>hadar</em>, multi-party attacks, flickering life, and all four compulsion positions. Three main evidentiary/comparison tables and one framework table remain in the main column. The conclusion explains the public dimension without replaying the entire taxonomy. Historical juristic examples are not contemporary legal advice. No original primary treatise was independently verified.

**12:** Preserves the critique of the “traitor” label, ENA NS 31.21 abuse litigation, Klein's default/design distinction, the Yeshiva stipend, the 1025 Jerusalem tax (15,000 / 6,000 / 3,000 + 3,000 dinars), officials and state literacy, Nahum's 1052 synagogue petition, the 1029 Mount of Olives case, three diplomatic-calque markers, and the Islamicate-state conclusion. The supplied text dates ENA NS 31.21 broadly from the mid-12th to mid-13th century, straddling the end of Fāṭimid rule; its placement in the argument is flagged rather than silently assumed to fall wholly under the dynasty. The final recap sentence was shortened after a visual QA run identified a two-word spill onto a nearly empty main page. No information uniquely contained in that sentence was removed.

## Reproducible checks

- Exact SHA-equivalent byte comparison against `Literature_Dossier_Source_Readings_01-10_Editorial.zip`: all existing ten chapters, ten raw explainers and seven publisher files unchanged.
- Structural source checks: 8 sections + 6 revision subsections per new reading; 5 contextual memory aids + 5 collected aids in each.
- Individual pair: **21 logical = 21 physical** pages; **34 genuine PDF bookmarks**, **2 live Contents links**. Both main bodies fit into 5 and 4 pages respectively.
- Complete 01–12: **127 logical = 127 physical** pages, **189 genuine bookmarks**, **12 internal Contents links**, complete running furniture and zero measured overflow.
- Exact passage ownership: **42 / 42 new cards** appear on a PDF sheet containing their actual `<article data-anchor>` text; no missing or repeated note identities.
- Mobile check at 390 CSS pixels: document scrollWidth = 390; sidebars remain in reading order.
- Alternate font-metric stress profile: 22 physical pages for selected 11–12; no reported overflow. The difference of one page from the standard offline 21-page pair is expected from different font widths.
- Reversed `12,11` selection with revision excluded: **13 physical pages**, **20 bookmarks**, **2 Contents links**.
- PDF dimensions: all 16:9 at approximately 960 × 540 pt. PDF outline's open-sidebar preference is set. PDF text is selectable and unencrypted.
- Source HTML and publication HTML reconstructed using the unchanged Python builder.

## Fonts and scope

Reproducible release uses the `offline` font profile (no remote Google Fonts). The original CSS typography is unchanged, the PDF contains embedded subsets of available local fonts, and Amiri is present for Arabic passages in the full PDF. Exact branded-font wrapping may differ where the remote fonts are later available. Results establish fidelity to user-supplied explainers and named topic coverage, **not independent scholarly verification** against the underlying legal article or published historical studies.

## Recovery

Canonical source: `Literature_Dossier_Source_Readings_01-12_Editorial.zip`. Next manual batch: Readings **13–14**. Do not change existing chapter files or reusable publishing code merely to save pages. The formerly scheduled production task remains disabled.
