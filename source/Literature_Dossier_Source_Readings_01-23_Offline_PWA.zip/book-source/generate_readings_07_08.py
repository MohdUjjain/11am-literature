#!/usr/bin/env python3
"""Add source-faithful readings 05–06; never regenerate earlier chapters."""
from pathlib import Path
from html import escape as E
import re,csv,json
from generate_initial_readings import callout as base_callout
def callout(*args):
 s=base_callout(*args)
 for icon in ["🟦 ","🟩 ","🟨 ","🟥 ","🟪 ","⭐ "]:s=s.replace(icon,"")
 return s
R=Path(__file__).resolve().parent
from data_07_08 import D,C
def table(headers,rows):
 return '<table data-content-type="comparison" data-pagination="repeat-header"><thead><tr>'+''.join('<th>'+E(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+E(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table>'
def body(lines):
 out=[];i=0
 while i<len(lines):
  s=lines[i]
  if s.startswith(('Name,Title,Military Base,Primary Interest','Objective Category,')):
   rows=[]
   while i<len(lines) and ',' in lines[i] and not lines[i].startswith(('The Conceptual Hierarchy',)):
    rows.append(next(csv.reader([lines[i]])));i+=1
   out.append(table(rows[0],rows[1:]));continue
  if s.startswith('* ') or re.match(r'^\d+\. ',s):
   ordered=not s.startswith('* ');tag='ol' if ordered else 'ul';items=[]
   while i<len(lines) and (bool(re.match(r'^\d+\. ',lines[i])) if ordered else lines[i].startswith('* ')):
    items.append(re.sub(r'^(?:\* |\d+\. )','',lines[i]));i+=1
   out.append('<'+tag+'>'+''.join('<li>'+E(x)+'</li>' for x in items)+'</'+tag+'>');continue
  if s.endswith(':') or s in ['The Sacred Dissonance','The Evolution of the Persian Marker:']:
   out.append('<h3>'+E(s)+'</h3>')
  else:out.append('<p>'+E(s)+'</p>')
  i+=1
 return '\n'.join(out)
for n,d in D.items():
 raw=(R/'sources'/f'{n:02d}-raw-explainer.md').read_text();lines=[x.strip() for x in raw.splitlines() if x.strip()];subtitle=lines.pop(0);secs=[]
 for line in lines:
  ishead = line.startswith(f"{len(secs) + 1}. ") and len(secs) < 7
  if ishead:secs.append([re.sub(r'^\d+\. ','',line),[]])
  else:secs[-1][1].append(line)
 assert len(secs)==7
 parts=[]
 for j,(title,ls) in enumerate(secs,1):
  cards=''.join(callout(*x) for x in C[n].get(j,[]))
  parts.append(f'<div class="section" id="s{n}-{j}"><div class="section-number">§{n}.{j}</div><h2>{E(title)}</h2><div class="section-body">{body(ls)}<div class="callout-grid">{cards}</div></div></div>')
 memories=[(j,x) for j,cs in C[n].items() for x in cs if x[0]=='memory']
 grid='<div class="revision-grid">'+''.join('<div class="revision-card"><h3>'+E(a)+'</h3><p>'+E(b)+'</p></div>' for a,b in d['cards'])+'</div>'
 rev=[('Chapter Summary','<p>'+E(d['summary'])+'</p>'),('One-Page Revision Sheet','<div data-pagination="keep-together">'+grid+'</div>'),('Key Definitions',table(['Term','Meaning in this reading'],d['defs'])),('Key Tables',table(['Example / factor','Evidence / marker','Interpretive significance'],d['rows'])),('Memory Aids','<div class="callout-grid">'+''.join(callout('memory',f'From §{n}.{j} · '+x[1],x[2]) for j,x in memories)+'</div>'),('Possible Examination Questions','<div class="revision-grid exam-question-grid">'+''.join('<div class="exam-q"><span class="qtype">'+E(a)+'</span><p>'+E(b)+'</p></div>' for a,b in d['questions'])+'</div>')]
 revision=''.join(f'<div class="section" id="s{n}-rev-{j}"><div class="section-number">REV {j:02d}</div><h2>{title}</h2><div class="section-body">{content}</div></div>' for j,(title,content) in enumerate(rev,1))
 out=f'''<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{d['accent']};"><div class="leaf"><div class="chapter-title-page"><div class="reading-eyebrow">Reading {n:02d} · Literature Dossier</div><h1>{E(d['title'])}</h1><p class="subtitle">{E(subtitle)}</p><hr class="gold-rule"><div class="opener-split"><div class="thesis-block"><p class="kicker">Central thesis</p><p>{E(d['thesis'])}</p></div><div class="roadmap"><p class="kicker">In this reading</p><ol>{''.join('<li>'+E(t)+'</li>' for t,_ in secs)}</ol></div></div><p class="source-cite">Source: supplied Drive explainer {n:02d}. Original scholarly article not independently verified. Added study aids are distinguished from the preserved source text.</p></div>{''.join(parts)}</div><div class="revision-zone"><div class="revision-leaf"><div class="revision-kicker">Reading {n:02d} · Revision &amp; recall</div>{revision}</div></div></section>'''
 (R/'chapters'/d['file']).write_text(out)
 print(n,len(secs),'sections',len(memories),'memory aids')
