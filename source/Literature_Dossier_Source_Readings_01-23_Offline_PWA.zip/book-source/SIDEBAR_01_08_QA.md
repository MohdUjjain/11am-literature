# Literature Dossier — Readings 01–08: Production Sidebar Migration QA

**Verified on 2026-11-04.** The previous 01–08 source ZIP was preserved as the read-only starting point. The new edition is an additional verified checkpoint, not an academic rewrite.

## Deliverables and exact results

| QA dimension | Verified result |
|---|---:|
| Completed readings | **8 / 26** (09–10 next, 19 reserved) |
| Combined physical PDF sheets | **105** |
| Corresponding compositor pages | **105** |
| Prior complete 01–08 PDF sheets | **105** |
| Six-color main-body study callouts | **128** |
| Callouts moved to print sidebar | **128 / 128** |
| Notes beside their **exact** linked source passage | **128 / 128** |
| Notes falling back to the same section, wrong passage | **0** |
| Unplaced / duplicated / lost study callouts | **0** |
| Main-text source units checked | **237** (original vs new, all 8 readings) |
| Main scholarly tables retained | **15 / 15** |
| Process diagrams retained | **2 / 2** |
| Final revision sections | **48** (six per reading) |
| Actual hierarchical PDF bookmarks | **138** |
| Printed Contents hyperlink annotations | **8** |
| PDF page overflow and compositor errors | **0** |
| Printed page dimensions | **960 × 540 pt (13.333 × 7.5 in)** |
| Arabic typeface in the PDF | **Amiri embedded** |
| Mobile width tested | **390 px**; aside cards stack below their passage, no horizontal overflow |

## Layout mechanism

This is the optimized independent-column algorithm, not the original row-coupled sidebar. The main narrative and all section headings paginate continuously using their actual narrow print width. Callouts are collected from passages as a separate note pool and packed afterward on a page containing their exact passage anchor. The final long-form content does not wait vertically for taller sidebar cues. All six study-note colors appear in the right lane. Scholarly tables and process strips remain in the left narrative lane; they have **not** been recast into narrow callout cards. Dark revision pages retain full-page contrast styling and six review subsections.

The body font size was not reduced to obtain page savings: it remains **18.3 CSS px** at 1.36 leading in the printed narrative lane. Paragraph spacing was tuned from .66em to .50em and heading spacing refined. With the intended local fonts this held the total book at exactly the old 105 pages. Across **528 sampled full main-body lines** in the new PDF (length ≥60 characters, excluding most headings/tables/margins), the median was **96 characters**, versus the previously reported much longer lines in the full-width edition. This sampling intentionally excludes short fragments and is not an average of every line.

## Source integrity

Every complete source passage, table cell, process strip and six-part revision layout is preserved from the source chapters. Per-chapter narrative unit counts and study card counts:

| Reading | Narrative units | Sidebar cards | Tables |
|---|---:|---:|---:|
| 01 | 25 | 15 | 2 |
| 02 | 36 | 16 | 3 |
| 03 | 32 | 18 | 2 |
| 04 | 27 | 19 | 3 |
| 05 | 28 | 14 | 1 |
| 06 | 29 | 14 | 2 |
| 07 | 28 | 15 | 1 |
| 08 | 32 | 17 | 1 |

Two previous sidebar pilot chapters (03 and 07) included standalone table/process elements *outside* their passage wrappers; they were retained explicitly and verified against the original chapters. This distinction matters: a test that only counts `.passage` elements can falsely report missing tables even when the tables remain directly inside `.section-body`.

## Extended publishing regression

- Complete 1–8 edition: 105/105 physical/logical pages, 138 bookmarks, eight Contents links, zero overflow.
- Selected `8,1,6`, without revision: 27 pages, 34 bookmarks, three Contents links, correct order.
- Selected `7,3` with intended fonts: 25 pages, 35 bookmarks, two Contents links.
- All 128 main note IDs unique and present once in the print sidebar. All 128 exact passage anchor alignments passed at the intended font metrics.
- Responsive screen: at 390 px, notes appear after their owning passages, with no global horizontal overflow.
- Font-loaded print pass used locally available Spectral, Fraunces, Inter, and Amiri; the PDF has embedded font subsets. The source ZIP intentionally does not redistribute standalone font files. The optional offline publishing profile uses system fallbacks and still validates physical pagination.
- Genuine PDF document outline enabled (`/PageMode /UseOutlines`), destinations all point to valid sheets, 8 clickable Contents entries confirmed.

## Limits / safeguards

The materials are study explainers supplied by the user; this QA checks preservation against those explainers and source HTML, not external scholarly factual verification. Particularly large, genuinely full-bleed diagrams or radically wider future tables may still require a new measured layout adapter; adding such a feature should include its own PDF tests. A few final pages of a main reading finish early because the contrasting revision zone intentionally begins on a fresh sheet. Source scripts named `generate_*` are historical; running them over the curated chapters would reverse the sidebar migration. Continue from the present modular ZIP for Reading 09.

**Baseline SHA-256**: `{source['original_source_zip_sha256']}`  
**New HTML SHA-256**: `{hashlib.sha256(html_file.read_bytes()).hexdigest()}`  
**New PDF SHA-256**: `{hashlib.sha256(pdf_file.read_bytes()).hexdigest()}`.
