# Editorial Compression Policy — Literature Dossier

**New authorized instruction, 4 November 2026.** This adds to `SIDEBAR_AUTHORING_AND_PRINT_CONTRACT.md` and supersedes only that document's *blanket prohibition* against editing/shortening main text, when the user has specifically approved a controlled editorial pass. It does **not** change the sidebar, scholarly ethics, original source archives, or geometry.

## Objective

Concise, intellectually complete, exam-ready main notes; five 16:9 landscape pages is the default editorial target, **not a hard ceiling**. Three–four is good for focused readings. Six is justified for dense text, complex evidence or tables. Seven or more triggers a controlled editorial review.

## Independent responsibilities

1. Reading opener = thesis and roadmap, not another full introduction in the main text.
2. Main text = one complete explanation of each central claim, evidence, example, counterargument, attributed historical claim and qualification. Never replace an author's inference with a bare fact list.
3. Sidebar = six semantic colors, compact lookup/retrieval cues, all `data-note-id` and exact `data-anchor` relationships preserved.
4. Revision zone = six full sections, independently paginated dark sheets, with all collected memory aids and exam questions.

## Editorial audit workflow

- Make an inventory of unique assertions, facts, source attributions, technical terms, named persons, dates, diagrams, tables and qualifications before editing.
- Identify actual duplicated information across introduction/body/sidebar/revision, not merely similar words.
- Tighten the main prose: remove duplicate roadmaps/recap lists, consolidate repeated chronology, reorganize examples into clear but complete causal/argument sequences. Condense sidebar prompts into crisp cues without deleting their mnemonic identities.
- Preserve substantive original source explanations in `sources/` and original pre-edit chapter HTML in an editorial backup. Preserve evidence tables and instructional diagrams verbatim unless separately approved.
- Validate every essential point remains in active main notes, which must be understandable if the margin is skipped. Check that the six revision sections still contain the corresponding mnemonic aid.
- Render the entire book with fixed existing CSS, fonts, geometry and paginator. Count only **main-note** sheets when assessing the 5-page target, not openers or revision pages.
- If five damages explanation, publish six. Record explicit editorial reasons, not just final page numbers.

## Do not modify for page savings

Do not change global CSS, body font size, line-height, paragraph/section spacing, heading/table styles, table padding, page-break/compositor behavior, page margins, reading accent palette, sidebar width, or revision templates. Consistency across all 26 readings is more important than artificially reaching exactly five sheets.

## Per reading required QA

- Original source explainer intact and original chapter archived for diffing.
- All main scholarly section IDs and important attributed claims present.
- All original main-reading tables/figures preserved unless user permits a content change.
- Exactly one current instance of each sidebar card, correct six-category style, unchanged stable ID and passage ownership, exact printed alignment.
- All six revision sections, introductory memory aid cue and matching collected revision cues preserved.
- PDF composed sheets = physical sheets; no clipping, overflow or missing headers/footers; outline/bookmark and Contents destinations valid.
- All revised text remains attributed to supplied explanatory sources. Do not claim independent journal-article verification.

## Release checkpoint 01–08

Before: 105 total pages (60 main, 35 revision, 8 openers, 2 front). After: **88 total pages (43 main, 35 revision, 8 openers, 2 front)**. Seven chapters 02–08 were condensed, Reading 01 approved pilot unchanged. `EDITORIAL_CHECKPOINT.json` records machine-readable metadata; `Editorial_02-08_QA.json` records test details.
