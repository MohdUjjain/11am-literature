"""Install packaged font faces for reproducible offline export on Linux."""
from pathlib import Path
import shutil,subprocess
src=Path(__file__).resolve().parent/'fonts';dest=Path.home()/'.local/share/fonts/literature-dossier';dest.mkdir(parents=True,exist_ok=True)
for f in src.glob('*.ttf'):shutil.copy2(f,dest/f.name)
subprocess.run(['fc-cache','-f'],check=True)
print('Installed dossier fonts')
