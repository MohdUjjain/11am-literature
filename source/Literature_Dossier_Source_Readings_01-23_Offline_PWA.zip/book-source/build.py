#!/usr/bin/env python3
"""
Assembles the single running book HTML from separate source files.

Run this after adding/editing a chapter file, or after editing
styles.css / engine.js / cover.html / head-template.html. Never edit
the assembled output directly — edit a source file and rebuild.

Usage:
    python3 build.py                  # builds output/book.html
    python3 build.py --out PATH       # builds to a custom path
"""
import argparse
import glob
import os
import sys

SRC = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(SRC, "output", "book.html")


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def build(out_path):
    template = read(os.path.join(SRC, "head-template.html"))
    styles = read(os.path.join(SRC, "styles.css"))
    engine = read(os.path.join(SRC, "engine.js"))
    cover = read(os.path.join(SRC, "cover.html"))

    chapter_paths = sorted(glob.glob(os.path.join(SRC, "chapters", "*.html")))
    if not chapter_paths:
        print("WARNING: no chapter files found in chapters/ — output will have no chapters.", file=sys.stderr)

    chapters_html = []
    seen_numbers = set()
    for path in chapter_paths:
        text = read(path)
        # Sanity check: filename prefix should match the chapter's own
        # data-chapter attribute, so a misnamed file is caught here
        # rather than silently producing a chapter out of order.
        basename = os.path.basename(path)
        prefix = basename.split("-", 1)[0]
        if not prefix.isdigit():
            print(f"WARNING: {basename} doesn't start with a numeric prefix (e.g. 02-...) — "
                  f"chapter order depends on filename sort order.", file=sys.stderr)
        else:
            num = int(prefix)
            if f'data-chapter="{num}"' not in text:
                print(f"WARNING: {basename}'s filename number ({num}) doesn't match its "
                      f"data-chapter attribute in the file — check for a copy/paste mistake.", file=sys.stderr)
            if num in seen_numbers:
                print(f"WARNING: chapter {num} appears in more than one file.", file=sys.stderr)
            seen_numbers.add(num)
        chapters_html.append(text)

    html = template
    html = html.replace("<style>\n{{STYLES_CSS}}\n</style>", "<style>" + styles + "</style>")
    html = html.replace("{{COVER}}", cover)
    html = html.replace("{{CHAPTERS}}", "\n".join(chapters_html))
    html = html.replace("<script>\n{{ENGINE_JS}}\n</script>", "<script>" + engine + "</script>")

    remaining = [m for m in ("{{STYLES_CSS}}", "{{COVER}}", "{{CHAPTERS}}", "{{ENGINE_JS}}") if m in html]
    if remaining:
        print(f"ERROR: unreplaced markers in output: {remaining} — head-template.html "
              f"may be missing its exact marker wrapper text.", file=sys.stderr)
        sys.exit(1)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"Built {out_path} ({len(html):,} chars) from {len(chapter_paths)} "
          f"chapter file(s): {', '.join(os.path.basename(p) for p in chapter_paths)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default=DEFAULT_OUT, help="output path for the assembled HTML")
    args = parser.parse_args()
    build(args.out)
