"""Manual 15–16 chapter-only generator; the 01–14 source remains immutable.

Editorial basis: user-supplied Google Docs, not independently checked article texts.
"""
from pathlib import Path
import html,json,hashlib
ROOT=Path(__file__).resolve().parent

CATS={'definition','concept','examtip','mistake','memory','highyield'}
def P(t,*notes):return {'html':'<p>'+t+'</p>','notes':[dict(kind=k,title=ttl,body=b) for k,ttl,b in notes]}
def T(head,rows,*notes):
    return {'html':'<table data-content-type="comparison" data-pagination="repeat-header"><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in r)+'</tr>' for r in rows)+'</tbody></table>', 'notes':[dict(kind=k,title=ttl,body=b) for k,ttl,b in notes]}
def L(items,*notes,ordered=False):
    tag='ol' if ordered else 'ul'
    return {'html':f'<{tag}>'+''.join(f'<li>{item}</li>' for item in items)+f'</{tag}>','notes':[dict(kind=k,title=ttl,body=b) for k,ttl,b in notes]}
def S(title,*items):return {'title':title,'items':list(items)}

def build(n,title,subtitle,thesis,sections,definitions,keytables,memory,questions,summary,cards,accent,source_id,file_slug):
    o=[f'<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{accent};"><div class="leaf"><div class="chapter-title-page">',
       f'<div class="reading-eyebrow">Reading {n:02d} · Literature Dossier</div><h1>{html.escape(title)}</h1>',
       f'<p class="subtitle">{html.escape(subtitle)}</p><hr class="gold-rule"/>',
       '<div class="opener-split"><div class="thesis-block"><p class="kicker">Central thesis</p>',
       '<p>'+thesis+'</p></div><div class="roadmap"><p class="kicker">In this reading</p><ol>',
       *['<li>'+html.escape(s['title'])+'</li>' for s in sections],'</ol></div></div>',
       f'<p class="source-cite">Source: supplied Google Drive explainer {n:02d}, Google Doc {source_id}. This study guide follows the supplied interpretation; no independent comparison with the scholarly publication has been made. Counts, quotations, contested claims and interpretations are those of the explainer unless indicated otherwise.</p></div>']
    stats={}; cnt=0
    for i,s in enumerate(sections,1):
        o.append(f'<div class="section" id="s{n}-{i}"><div class="section-number">§{n}.{i}</div><h2>{html.escape(s["title"])}</h2><div class="section-body">')
        for j,it in enumerate(s['items']):
            a=f's{n}-{i}-p{j}'
            o.append(f'<article class="passage" data-anchor="{a}"><div class="prose">{it["html"]}</div>')
            if it['notes']:
                o.append('<aside aria-label="Study notes for this passage">')
                for k,note in enumerate(it['notes']):
                    typ=note['kind']; assert typ in CATS
                    stats[typ]=stats.get(typ,0)+1;cnt+=1
                    o.append(f'<div class="callout callout--{typ}" data-content-type="{typ}" data-note-id="{a}-n{k}" data-pagination="allow-split"><div class="tag">{html.escape(note["title"])}</div><p>{note["body"]}</p></div>')
                o.append('</aside>')
            o.append('</article>')
        o.append('</div></div>')
    o.extend(['</div><div class="revision-zone"><div class="revision-leaf">',f'<div class="revision-kicker">Reading {n:02d} · Revision &amp; recall</div>'])
    def R(i,title,body):return f'<div class="section" id="s{n}-rev-{i}"><div class="section-number">REV {i:02d}</div><h2>{title}</h2><div class="section-body">{body}</div></div>'
    o.append(R(1,'Chapter Summary','<p>'+summary+'</p>'))
    o.append(R(2,'One-Page Revision Sheet','<div data-pagination="keep-together"><div class="revision-grid">'+''.join(f'<div class="revision-card"><h3>{h}</h3><p>{b}</p></div>' for h,b in cards)+'</div></div>'))
    o.append(R(3,'Key Definitions',T(['Term','Meaning in the supplied reading'],definitions)['html']))
    o.append(R(4,'Key Tables',keytables))
    o.append(R(5,'Memory Aids','<div class="callout-grid">'+''.join(f'<div class="callout callout--memory" data-content-type="memory" data-pagination="allow-split"><div class="tag">Memory aid · From §{n}.{i} · {h}</div><p>{b}</p></div>' for i,h,b in memory)+'</div>'))
    o.append(R(6,'Possible Examination Questions','<div class="revision-grid exam-question-grid">'+''.join(f'<div class="exam-q"><span class="qtype">{cat}</span><p>{q}</p></div>' for cat,q in questions)+'</div>'))
    o.extend(['</div></div></section>'])
    f=ROOT/'chapters'/f'{n:02d}-{file_slug}.html'; f.write_text(''.join(o),encoding='utf8')
    return {'reading':n,'file':f.name,'sections':len(sections),'passages':sum(len(s['items']) for s in sections),'notes':cnt,'note_types':stats,'memory_aids':len(memory),'tables':sum('table' in x['html'] for s in sections for x in s['items']),'revision_sections':6}

# Reading 15: religion, authority and modern infrastructure in the supplied account.
sec15=[
 S('The Paradox: Technology Rebuilds a Fāṭimid Community',
   P('The supplied account describes the <strong>Dāʾūdī Bohras</strong> as a Mustaʿlī Ismāʿīlī Shīʿī community of over a million whose commercial lives span Mumbai, Dubai and diaspora cities. Its central paradox is that the community preserves a medieval Fāṭimid inheritance <em>through</em> modern means rather than in flight from them. Technology, professional education, standardized dress and administrative oversight make an increasingly global religious identity possible. The expression “hardware of the West, software of Fāṭimid Islam” captures the strategy attributed to modern leadership.',
     ('concept','Central paradox · Modern means, inherited ends','Modern institutions are depicted as means of rebuilding, not dissolving, a distinctive Fāṭimid-rooted religious order.'),
     ('examtip','Structure an essay as a double argument','Explain how modern tools strengthen central authority <em>and</em> equip members to question it.')),
   P('In this reading the two forces must be examined together. Clerical centralization depends on the <strong>Dāʿī al-muṭlaq</strong>; professional and digital networks sustain distant followers; visual rules make community boundaries recognisable; the same platforms also circulate disputed claims and reformist criticism. Jonah Blank is quoted in the supplied explainer as describing this process as ideological adaptability and institutional renewal, not a simple choice between religion and modernity.',
     ('highyield','Four arenas of modernization','Authority · education · communication · orthopraxy—follow their effects on both cohesion and dissent.'))),
 S('Hidden Imām and the Authority of the Dāʿī',
   P('The explainer traces the Dāʾūdī succession to the <strong>Mustaʿlī</strong> branch of Ismāʿīlism, contrasted with the Nizārī line associated with living Aga Khan Imāms. In its account, the <strong>22nd Imām Abū l-Qāsim Ṭayyib</strong> enters concealment, the <em>dawr al-satr</em>; during this absence, the Dāʿī al-muṭlaq (“Absolute Summoner”) acts as the community’s visible spiritual and temporal authority. The Dāʿī is regarded as <em>kal maʿṣūm</em>, near-infallible, and mediates access to the Imām’s guidance.',
     ('definition','Authority · Dāʿī al-muṭlaq','Absolute Summoner: the visible guide entrusted with leadership during the concealed Imām’s absence.'),
     ('memory','Memory aid · Concealment → Bridge','<strong>Hidden Imām → Dāʿī al-muṭlaq → communal guidance.</strong>')),
   P('That authority has a hermeneutic dimension. The <em>ẓāhir</em> is the apparent scriptural form; the <em>bāṭin</em> its inner meaning; <em>taʾwīl</em> joins the two through authorized interpretation. The source contrasts this layered, philosophically receptive outlook with a schematic “traditional literalism” that emphasizes the visible text and a closed gate of <em>ijtihād</em>. This is the explainer’s contrast, not a comprehensive description of all other Muslim traditions.',
     ('definition','Reading terms · Ẓāhir, bāṭin, taʾwīl','Outer expression, inner sense, and interpretation linking them.'),
     ('mistake','Do not universalize the comparison','The source’s two-column typology is a rhetorical contrast; it does not establish that every other Muslim tradition rejects philosophy.')),
   T(['Bohra Ismāʿīlī emphasis','Explainer’s contrasting literalist model'],[
     ['<em>Taʾwīl</em> interprets inner meanings of revelation','Reading privileges the apparent words'],
     ['Neoplatonic and other philosophical borrowings are described as productive','External intellectual systems are treated as suspect'],
     ['A present Dāʿī offers living interpretive authority','Authority is presented as inherited texts and established methods']])) ,
 S('Egypt, Yemen, Gujarat: The Geography of the Daʿwat',
   P('In the supplied chronology, Ismāʿīlī missionaries reached India in the eleventh century while the mission’s main institutional sphere remained linked to Yemen; the queen <strong>al-Malika al-Sayyida</strong> is associated with the elevated office of Dāʿī. The missionary institution, the <em>daʿwat</em>, shifted toward India under political pressure in Yemen. In <strong>1539/946 AH</strong> Yusuf Najmuddin became the first Indian Dāʿī, still holding office in Yemen; the account then describes the permanent transfer of the leadership seat to India.',
     ('highyield','Chronology · Where authority moved','Cairo/Fāṭimid inheritance → Yemen → Indian leadership → Surat → Mumbai and global diaspora.')),
   P('The explainer describes suppression under Aurangzeb and recourse to <em>taqiyya</em> (religious concealment). British stability is presented as a later opening: in <strong>1200 AH / 1785 CE</strong> the headquarters moved to <strong>Surat</strong>, followed by nineteenth-century commercial movement toward Mumbai. The larger argument is a change in the material conditions of survival: mercantile prosperity made new institutional strategies possible, while the leadership redefined how a dispersed population could stay together.',
     ('definition','Term · Taqiyya','Concealment of religious affiliation or practice under threat.'),
     ('memory','Memory aid · Y–S–M','<strong>Yemen → Surat → Mumbai</strong>: shifting centers, continuing daʿwat.')),
   T(['Period','Change described in the explainer'],[
     ['11th century','Missionaries arrive in India'],['1539 / 946 AH','Yusuf Najmuddin assumes office in Yemen'],
     ['16th century','Mission’s seat transfers to India'],['1785 / 1200 AH','Surat headquarters'],
     ['19th–20th centuries','Mumbai commerce and diaspora expansion']])) ,
 S('1915 and the Modernization Strategy',
   P('By the time <strong>Syedna Taher Saifuddin</strong> took office as the 51st Dāʿī in 1915, the source portrays clerical power as weakened by wealthy, Western-educated merchant elites, including <strong>Sir Adamji Pirbhai</strong>. The danger was less military defeat than assimilation: promising Bohras could acquire education and status outside communal institutions and cease treating the Dāʿī as central. The leadership’s answer was to appropriate the means associated with this threat.',
     ('concept','Problem · Assimilation through elite independence','Economic and educational mobility had allowed influential families to bypass clerical mediation.'),
     ('memory','Memory aid · Two kinds of immunization','<strong>Education</strong> retains talent; <strong>administration</strong> reconnects dispersed followers to the Dāʿī.')),
   P('The strategy had two interdependent parts. First, Western-style and professional education was encouraged so members would not have to choose between communal belonging and worldly success. Second, new administrative technologies were used to weaken the monopoly of families with privileged access to the clerical court. As presented, modernization was therefore <strong>both an opportunity for ordinary believers and an instrument of renewed central control</strong>. Neither aspect should be omitted from an examination answer.',
     ('examtip','Explain both effects of the same tool','Professional education widens participation; centralized records and communication may also deepen supervision.'))),
 S('Digital Presence: Access and Oversight',
   P('The study cited in the explainer reports that Bohras at its observation point were <strong>72 times more likely to own a computer</strong> than the broader Indian norm. Treat the figure as a claim tied to that study’s period, not a verified present-day statistic. The sequence of communication technologies—telex, messaging, streaming and social media—illustrates how a believer in <strong>Mombasa</strong> might seek advice or a blessing (<em>ʿalāmat</em>) from a Dāʿī based in Mumbai.',
     ('highyield','Source-bound figure · 72×','The explainer’s historical comparison concerns computer ownership at the time of the cited study; it is not a 2026 census.'),
     ('mistake','Access is not the same as equality of power','Faster communication broadens contact with the Dāʿī but does not itself erase hierarchical authority.')),
   P('The explainer contrasts this access with nineteenth-century “elite capture,” when kin-linked Surti merchant families stood between followers and clerical leadership. Digital connection can make a remote authority immediately present across a dispersed diaspora. Yet the same systems allow recordkeeping, monitoring and compliance measures, including the source’s description of <strong>green, yellow and red cards</strong> marking different orthopraxic statuses. Modernization makes devotion more portable, but also makes regulation more systematic.',
     ('concept','Two digital directions · Contact and control','The network links believer to Dāʿī and gives the center information about local compliance.'))),
 S('Uniform Dress as a Modernly Standardized Tradition',
   P('The source applies Eric Hobsbawm’s idea of <strong>“invented tradition”</strong> to the standardized Bohra dress code. Directives (<em>firmāns</em>) attributed to <strong>Syedna Burhanuddin in 1979 and 1981</strong> made a white-and-gold men’s <em>topi</em> and women’s brightly colored <em>rida</em> conspicuous signs of community membership. The account notes that the now-familiar topi was rare in earlier photographs and that local attire had previously varied. Standardization gives a modern organizational rule the appearance of enduring inherited identity.',
     ('definition','Term · Invented tradition','A recently standardized practice presented as expressing continuous communal inheritance.'),
     ('memory','Memory aid · Firmān → Uniform → Visibility','<strong>Directive → standardized appearance → recognizable global community.</strong>')),
   P('A <strong>1975</strong> dataset cited in the explainer reported only <strong>37%</strong> of prominent men complying with what later became mandatory dress and beard guidelines; the source describes compliance after 1981 as near-universal. These numbers indicate change over time within the source’s account. They do not mean every form of Bohra dress was newly created in the late twentieth century: the specific claim concerns the recent <em>uniformity</em> of communal markers.',
     ('highyield','1975 → 1981 · Mark the change','37% in the cited sample before mandatory rules; subsequent compliance reported as much higher.'),
     ('mistake','Do not confuse practice with standardization','The argument is not that Bohra dress had no history; it concerns institutional enforcement of a particular shared form.'))),
 S('Dissent, Education and the Double-Edged Future',
   P('The same digital media that spread the Dāʿī’s voice also circulate competing religious claims. During the <strong>2014 succession dispute</strong> between <strong>Mufaddal Saifuddin and Khuzaima Qutbuddin</strong>, the explainer describes both sides posting recordings to defend their interpretation of <em>naṣṣ</em> (designation of a successor). It also recounts online activism around <em>khatna</em> (female genital cutting/circumcision), with some Bohra reformists using web platforms to challenge the practice and call for a ban. These are presented as ongoing debates described by the supplied text; the source does not establish their present status.',
     ('definition','Term · Naṣṣ','Designation of a successor, disputed in the case described.'),
     ('memory','Memory aid · One network, two audiences','<strong>Center broadcasts → followers connect → critics organize.</strong>')),
   P('The source closes with the <strong>Jamea-tus-Saifiyah</strong> educational model, joining traditional philosophy and modern sciences; it describes professional education for daughters and sons, and examples of women in <em>rida</em> working as surgeons or lawyers. Its conclusion is an institutional paradox rather than an idyll: <strong>an authoritative religious system uses global education and communications to reproduce itself, while these tools furnish believers with new capacities for independent action.</strong>',
     ('examtip','Essay synthesis · Avoid one-sided celebration','Test the costs and benefits of modernization through authority, access, identity, education and internal disputes.'))),
]
mem15=[
 (2,'Concealment → Bridge','<strong>Hidden Imām → Dāʿī al-muṭlaq → communal guidance.</strong>'),
 (3,'Y–S–M','<strong>Yemen → Surat → Mumbai</strong>: shifting centers, continuing daʿwat.'),
 (4,'Two kinds of immunization','<strong>Education</strong> retains talent; <strong>administration</strong> reconnects dispersed followers to the Dāʿī.'),
 (6,'Firmān → Uniform → Visibility','<strong>Directive → standardized appearance → recognizable global community.</strong>'),
 (7,'One network, two audiences','<strong>Center broadcasts → followers connect → critics organize.</strong>'),
]
res15=build(15,'The Dāʾūdī Bohras (Mustaʿlī Ismāʿīlī Shīʿa) Using Modernity to Institutionalise a Fāṭimid Tradition',
 'Mullahs on the Mainframe: Modern Institutions, a Hidden Imām and a Living Daʿwat',
 'The supplied account interprets Bohra modernity as an institutional strategy: professional education, communication and visible communal rules help extend the authority of the Dāʿī while also enabling new forms of access and dissent.',
 sec15,
 [('Dāʿūdī Bohras','Mustaʿlī Ismāʿīlī Shīʿī community described in the source.'),('Dāʿī al-muṭlaq','Absolute Summoner, visible religious authority during the Imām’s concealment.'),('Dawr al-satr','Era of concealment of the Imām.'),('Kal maʿṣūm','Near-infallible status ascribed to the Dāʿī in the account.'),('Ẓāhir / bāṭin','Apparent scriptural form / inward meaning.'),('Taʾwīl','Interpretation of the inner meaning of revelation.'),('Daʿwat','Mission or institutional religious summons.'),('Taqiyya','Concealment of affiliation or practice under threat.'),('Firmān','Directive issued by the religious authority.'),('ʿAlāmat','Sign or blessing conveyed by the Dāʿī in the account.'),('Naṣṣ','Designation of religious succession.'),('Invented tradition','Modern formalization of a practice represented as continuous with the past.')],
 T(['Turning point','Institutional effect'],[
 ['Hidden Imām / Dāʿī','Authority carried by the visible Absolute Summoner'],['Yemen → Gujarat → Mumbai','Continuity across geographic changes'],['1915 educational modernization','Retains communal members while professionalizing them'],['Telex → online media','Extends contact and central oversight'],['1979/1981 dress directives','Makes affiliation visually standardized'],['2014 succession dispute','Digital media also enable contestation']])['html'],
 mem15,
 [('Thesis','Why does the explainer reject a simple tradition-versus-modernity opposition?'),('History','Trace the daʿwat’s movements from Yemen to Surat and Mumbai.'),('Authority','How do dawr al-satr, Dāʿī al-muṭlaq, ẓāhir and bāṭin relate?'),('Comparison','Contrast education as community retention with technology as governance.'),('Evidence','What is the significance of the 1975 and 1979/1981 dress evidence?'),('Critical evaluation','How did the 2014 succession dispute expose the double-edged nature of digital platforms?'),('Essay','Assess the source’s claim that modernity reinstitutionalized a Fāṭimid tradition.')],
 'The Dāʾūdī Bohras are presented as a community whose Fāṭimid-rooted authority survives by adapting modern institutions. With the Imām concealed, the Dāʿī al-muṭlaq provides a visible interpretive and organizational center. The mission’s movements through Yemen, Surat and Mumbai prepare the background for a twentieth-century response to elite assimilation: education and communication reconnect dispersed believers while strengthening the clergy. Dress directives in 1979 and 1981 standardize public identity. Digital platforms also host succession disputes and reformist activism. The resulting synthesis is not a conflict-free victory of tradition but a system in which the tools of centralization simultaneously increase personal reach and opportunities for dissent.',
 [('Authority','Hidden Imām; Dāʿī as visible guide and interpreter.'),('Routes','Yemen → India; 1539 Indian Dāʿī in Yemen; 1785 Surat; Mumbai diaspora.'),('1915 pivot','Western education and modern administration counter assimilation.'),('Data signals','72× computer ownership at study time; 37% dress-compliance sample in 1975.'),('Two directions','Media democratize access and strengthen supervision; rivals and reformists use them too.'),('Source discipline','Treat numeric claims and contemporary disputes as sourced accounts, not independently verified present facts.')],
 '#796B32','1HT4NM_rlhy2RrY_TSd3uL0AxTTZW89Jb6SUFmcvlwp8','daudi-bohras-modernity')

# Reading 16: polarities of Arab/non-Arab literary polemic, with hostile language carefully attributed.
sec16=[
 S('What Was Shuʿūbiyyah? A Cultural Argument, Not One Party',
   P('The supplied explainer presents <strong>Shuʿūbiyyah</strong> as a diverse literary and ideological backlash against the privileged status of Arabian Arabs, especially visible in the third/ninth-century ʿAbbāsid world. Persian and Aramaean or <em>Nabaṭ</em> voices challenged Arab claims to ancestral nobility, political precedence and cultural excellence. The central dilemma was whether the universal religious community of Islam must also reproduce the ethnic hierarchy of <strong>Arabism</strong>. The movement was not one coordinated rebellion: egalitarian arguments and aggressive claims of non-Arab superiority both entered its broad polemical field.',
     ('definition','Term · Shuʿūbiyyah','A range of claims and polemics opposing Arab ethnic privilege, sometimes advocating equality, sometimes non-Arab supremacy.'),
     ('examtip','Do not equate the two positions','The <em>ahl al-taswiyah</em> asked for equality; other Shuʿūbī polemicists asserted non-Arab superiority.')),
   P('A useful intellectual trajectory runs from <strong>tribal antagonism</strong> to the rising influence of non-Arab administrators and then to the public contest over language, religion and memory. The source’s quotations include deliberately insulting ethnic stereotypes: they are evidence of what literary combatants said, <em>not</em> descriptions endorsed by these notes. The paradox to track is that the critics’ strongest polemics were often composed in the very Arabic language they challenged as a marker of exclusive ethnic prestige.',
     ('highyield','Central tension · Islam versus Arabism','Universal religious membership did not automatically eliminate inherited ethnic rankings.'),
     ('memory','Memory aid · Three planes','<strong>Tribe → Administration → Theology</strong>: the conflict widens across institutions.'))),
 S('Umayyad Antecedents: Tribal Rivalry and Early Alliances',
   P('The explainer starts with <em>ʿaṣabiyyah</em> (tribal partisanship), including the fierce <strong>Qays–Kalb</strong> rivalry and the Battle of <strong>Marj Rāhiṭ (64/684)</strong>. These controversies furnished a repertoire of insult and genealogical attack. Later writers redirected intra-Arab “literary barbs” outward, using familiar mockery to contest Arab superiority. A quoted invective from <em>Kitāb al-Aghānī</em>, attacking Arab ancestry and conduct, should therefore be read as an example of hostile poetic rhetoric rather than factual ethnography.',
     ('definition','Term · ʿAṣabiyyah','Partisan attachment to lineage and tribe; a model for later ethnic polemic.'),
     ('memory','Memory aid · From feud to polemic','<strong>Qays–Kalb dispute → inherited satire → anti-Arab polemic.</strong>')),
   P('The source also describes opportunistic alliances: Yemeni Arabs opposed to northern power invoked ties with Egypt’s <strong>Copts</strong>, including stories about Māriyah, Himyarite ancestry and the legendary ʿAbd Shams b. Sabaʾ. Such stories functioned as tools of political solidarity; their genealogical claims are not independently established here. A different antecedent came from <strong>Khārijī</strong> religious reasoning: rejecting exclusive Qurayshī entitlement to the caliphate because a believer’s worth should not depend on race. That position must not be conflated with the later celebration of Persian or Babylonian national superiority.',
     ('concept','Two origins, different purposes','Yemeni/Coptic alliances were political; Khārijī claims challenged hereditary legitimacy on religious grounds.'),
     ('mistake','Genealogical claims are arguments, not proof','Stories of shared ancestry served the polemic; the supplied explainer does not verify them as historical facts.'))),
 S('ʿAbbāsid Secretaries and the Change in Social Power',
   P('Under <strong>Hārūn al-Rashīd</strong> and <strong>al-Maʾmūn</strong>, the explainer describes expanding influence of <em>mawālī</em> (non-Arab Muslim clients), particularly the administrative <em>kuttāb</em> and the <strong>Barmecides</strong>. As ethnic barriers loosened in urban ʿAbbāsid life, secretaries could shape the state through writing and institution building. The source portrays <strong>Sasanian ideals of administration</strong> as an alternative to older claims of Bedouin status; disparaging Arabs became a fashionable elite literary posture.',
     ('definition','Terms · Mawālī and kātib','<em>Mawālī</em>: non-Arab Muslim clients; <em>kātib</em>: state secretary or administrative writer.'),
     ('highyield','Paradox of advancement','The polemic grew in prominence as non-Arabs gained real administrative influence, not only while excluded.')),
   T(['Dimension','Umayyad setting in the source','Third/ninth-century ʿAbbāsid setting'],[
    ['Prestige','Arab aristocracy and explicit Arab–mawālī divisions','Urban secretarial and non-Arab influence'],
    ['Institutional ideal','Tribal, Bedouin and Arabian precedence','Sasanian models and writing-based administration'],
    ['Literary climate','Non-Arab self-praise considered hazardous','Ridicule of Arab claims becomes fashionable']]),
   P('The supplied text also attributes sharp tribal criticism to <strong>al-Maʾmūn</strong>, who is said to have mocked the Qays, Yemenis and Rabīʿa while favoring Persian culture. Whether one treats this as reported sentiment or political language, it links literary attitudes to the power of courtly patronage. Shuʿūbiyyah here is simultaneously a dispute over collective memory and a struggle over who is qualified to define the cultural standards of the empire.',
     ('concept','Institutional stakes','Court patronage and secretarial office gave disputes over prestige practical political consequences.'))),
 S('Three Rival Positions in the Debate',
   P('The explainer distinguishes <strong>three argumentative positions</strong>. Defenders of Arab pre-eminence praised Bedouin eloquence (<em>balāghah</em>) and the Prophet’s Arabian descent; the source associates figures such as Ibn al-Muqaffaʿ and al-Balādhurī with this formulation. The <em>ahl al-taswiyah</em>, the “levellers,” appealed to Qurʾān 49:13 to argue that <strong>piety, not ethnicity</strong>, determines human worth. More militant Shuʿūbīs inverted the older hierarchy, praising Persian, Greek or Indian civilization and caricaturing Arabs as primitive nomads. These are positions attributed to disputants by the supplied account.',
     ('definition','Term · Ahl al-taswiyah','The egalitarian school: Arab and ʿAjam are equal; piety is the criterion of value.'),
     ('memory','Memory aid · Above / Equal / Below','<strong>Arab primacy ↔ equality ↔ non-Arab primacy.</strong> Three views, not one continuum with identical moral premises.')),
   T(['Position','Claim about worth','Typical authority appealed to'],[
    ['Arab precedence','Arab eloquence and ancestry confer cultural privilege','Prophetic descent, <em>balāghah</em>'],
    ['Levellers (<em>ahl al-taswiyah</em>)','No ethnicity outranks another','Qurʾān 49:13; piety'],
    ['Non-Arab supremacy','Persian and other civilizations outrank Arabia','Sasanian/Babylonian past; literary invective']]),
   P('A strong reading does not make this a binary struggle between “Arab” and “Persian.” Yemeni Arabs might support anti-northern arguments; the Khārijī challenge was religiously egalitarian; the Nabaṭ recalled an Aramaean-Babylonian past; and Iberian Slav or Berber writers later developed a western version. Even the apparently clear term <em>Shuʿūbī</em> therefore identifies a changing rhetorical field rather than a stable organization with one programme.',
     ('examtip','Exam method · Classify before explaining','Identify <em>who</em> argues, <em>which</em> kind of equality/superiority, and <em>for what purpose</em>.'))),
 S('Literary Techniques: Mathālib, Eloquence and Arms',
   P('Writers attacking Arab prestige targeted precisely those practices their opponents praised. The source records ridicule of staffs and gestures in public rhetoric, unruly tribal ceremonies, heavy “dogwood” spears and riding styles, while celebrating Pahlavi learning, lighter lances, stirrups, siege engines and military tactics such as night raids or ditches. These comparisons are <strong>polemical evaluations</strong>, not objective rankings of peoples. Their literary force lies in converting Arab emblems of virtue into signs of cultural inadequacy.',
     ('concept','Technique · Invert the symbol','What one party calls nobility or natural eloquence, the opponent recasts as crude or backward.'),
     ('memory','Memory aid · Word / Weapon / Lineage','Polemic attacks <strong>speech</strong>, <strong>military skill</strong> and <strong>ancestry</strong>.')),
   T(['Arena','Arab trait attacked in the polemic','Claimed alternative'],[
    ['Speech','Staffs, gestures and rhyming formulas','Pahlavi/secretarial elegance'],
    ['Weapons','Heavy spears; riding without stirrups','Lighter spears and stirrups'],
    ['Strategy','Alleged lack of ambushes or siege engineering','Catapults, flank attacks and ditches'],
    ['Genealogy','Tribal boast','Catalogues of tribal vices']]),
   P('<strong>Mathālib</strong> literature, a catalogue or “science” of vices, gave this reversal documentary form. The explainer names <em>Mathālib al-ʿArab</em> by <strong>al-Haytham b. ʿAdī</strong> and a provocative work attributed to <strong>Sahl b. Hārūn</strong> that attacked Qurayshī women. The power of the genre lay in its parody of genealogical expertise: the same ancestral method used to support prestige could be turned into an archive of shame.',
     ('definition','Term · Mathālib','Polemical writing exposing alleged vices, ignoble ancestors and collective disgrace.'),
     ('mistake','Handle invective as evidence of a genre','A text cataloguing disgrace is not a reliable independent record of the accusations it makes.'))),
 S('The Religious Boundary: Al-Jāḥiẓ and Zandaqah',
   P('For critics such as <strong>al-Jāḥiẓ</strong>, attacks on Arabic eloquence and ancestry risked becoming attacks on the Prophet and revelation. The source therefore places Shuʿūbiyyah beside accusations of <em>zandaqah</em> (heresy or dangerous deviation) and <em>mujūn</em> (cynicism/licentious irreverence). This was an argument about the security of religious symbols, not proof that all non-Arab polemicists shared one theology. Al-Jāḥiẓ’s reported denunciation is itself part of the contest.',
     ('definition','Terms · Zandaqah and mujūn','Accusations of heretical or irreverent thought applied in the controversy.'),
     ('highyield','Why an ethnic dispute became theological','Opponents joined the Arabic language’s status to the Prophet and Islamic revelation.')),
   P('The supplied account describes the secretary <strong>Muḥammad b. al-Ḥusayn (Daydān)</strong>, linked to a wish to restore Sasanian power and speculative ideas involving intellect (<em>al-ʿaql</em>), time (<em>al-zamān</em>), space (<em>al-makān</em>) and matter (<em>al-hayūlā</em>). Rivals treated such doctrines as evidence of an attempted return to the religion of the Magi. The analytically important distinction is between <strong>what an individual reportedly believed</strong> and <strong>what polemical opponents claimed the whole movement threatened</strong>.',
     ('mistake','Keep attribution distinct','A critic’s accusation of heresy cannot be generalized automatically to everyone labelled Shuʿūbī.'))),
 S('Nabaṭ and Ishmael: Rival Memories of Antiquity',
   P('The <strong>Nabaṭ</strong> (Aramaeans), represented in the explainer through <strong>Ibn Waḥshiyyah’s <em>Nabataean Agriculture</em></strong>, invoked Mesopotamian-Babylonian learning against the alleged lack of Arab antiquity. The debate also turned to genealogical readings of <strong>Sarah and Hagar</strong>. Polemicists used Hagar’s enslaved status to disparage Arab descent through Ishmael; <strong>Ibn Qutaybah</strong> answered by defending the dignity of slave-born lineages and citing distinguished mothers of rulers. Religious narrative became a resource for contemporary status politics.',
     ('memory','Memory aid · Babylon / Hagar / Reply','<strong>Nabaṭ claim ancient civilization → polemic cites Hagar → Ibn Qutaybah counters.</strong>'),
     ('concept','Historical method · Status through genealogy','Antiquity and maternal lineage were mobilized as arguments about current cultural worth.'))),
 S('Al-Andalus and the Enduring Arabic Paradox',
   P('The explainer follows the polemic into fifth/eleventh-century <strong>al-Andalus</strong>, where Slav and Berber critics challenged Arab elite claims in Córdoba. The <em>Risālah</em> of <strong>Abū ʿĀmir b. García (Ibn García)</strong> reverses the biblical genealogy by claiming descent from Sarah, praising non-Arab kings in brocade while mocking Arab nomads in deliberately abusive language. The setting differs from Baghdad, but the literary strategy is recognisable: invert prestige, recruit genealogy and sharpen cultural contrast.',
     ('highyield','Western continuation','Ibn García’s <em>Risālah</em> extends the same polemical mechanisms to eleventh-century Iberia.')),
   P('The final irony is linguistic. The source concludes that Shuʿūbī dissent, even when attacking Arabs with ferocity, was often voiced in <strong>Arabic</strong>; the Persian philologist <strong>al-Zamakhsharī</strong> is presented as defending its study against the “party of slander.” The quarrel could therefore loosen the equation between <em>Islam</em> and ethnic <em>Arabness</em> while reaffirming Arabic as a central language of learned dispute. This is a nuanced ending, not a simple declaration that one side won.',
     ('examtip','Answer the paradox, not just the insults','Explain how an anti-Arab argument could rely on Arabic literary authority.'),
     ('memory','Memory aid · Oppose through the medium','<strong>Attack ethnic privilege in Arabic → Arabic remains the vehicle of elite argument.</strong>'))),
]
mem16=[
 (1,'Three planes','<strong>Tribe → Administration → Theology</strong>: the conflict widens across institutions.'),
 (2,'From feud to polemic','<strong>Qays–Kalb dispute → inherited satire → anti-Arab polemic.</strong>'),
 (4,'Above / Equal / Below','<strong>Arab primacy ↔ equality ↔ non-Arab primacy.</strong> Three views, not one continuum with identical moral premises.'),
 (5,'Word / Weapon / Lineage','Polemic attacks <strong>speech</strong>, <strong>military skill</strong> and <strong>ancestry</strong>.'),
 (7,'Babylon / Hagar / Reply','<strong>Nabaṭ claim ancient civilization → polemic cites Hagar → Ibn Qutaybah counters.</strong>'),
 (8,'Oppose through the medium','<strong>Attack ethnic privilege in Arabic → Arabic remains the vehicle of elite argument.</strong>'),
]
res16=build(16,'Shuʿūbiyyah in Arabic Literature',
 'The Battle for Cultural Prestige: Arabism, Equality and Non-Arab Polemic',
 'Shuʿūbiyyah was a shifting field of arguments over Arab ethnic precedence within Islamic culture: egalitarians rejected inherited hierarchy, others asserted non-Arab superiority, and writers fought through the shared resources of Arabic literary culture.',
 sec16,
 [('Shuʿūbiyyah','Diverse anti-Arab-precedence literary positions, ranging from levelling to non-Arab supremacism.'),('ʿAṣabiyyah','Zealous tribal or lineage partisanship.'),('Mawālī','Non-Arab Muslim clients, increasingly powerful in the ʿAbbāsid age.'),('Kātib / kuttāb','Secretary / secretaries who formed an influential state-writing class.'),('Ahl al-taswiyah','Levellers advocating ethnic equality under a piety-based standard.'),('ʿAjam','Non-Arab people, contrasted with Arab descent.'),('Balāghah','Eloquence, claimed as an inherent Arab excellence in one school of debate.'),('Mathālib','Genre/catalogue of alleged tribal faults and shameful descent.'),('Zandaqah','Heresy or religiously suspect free thought, often as an accusation.'),('Mujūn','Irreverence or cynical/libertine writing as classified by opponents.'),('Nabaṭ','Aramaean population claiming inherited Mesopotamian antiquity in the source.'),('Risālah','Epistle/treatise, notably Ibn García’s polemic.')],
 T(['Arena','Contrasting claims','Named evidence'],[
 ['Political origins','Tribal prestige and Khārijī equality','Qays–Kalb; challenge to Qurayshī entitlement'],
 ['Social setting','Non-Arab clients and court secretaries gain influence','Mawālī, kuttāb, Barmecides'],
 ['Three schools','Arab pre-eminence / levelling / non-Arab primacy','Balāghah; Qurʾān 49:13; Sasanian past'],
 ['Literary method','Inversion of ideals and ancestral accusations','Mathālib; warfare and rhetoric taunts'],
 ['Religious reaction','Critics fear damage to prophecy and Arabic','Al-Jāḥiẓ; zandaqah accusation'],
 ['Regional continuation','Aramaean and Iberian ancestry claims','Ibn Waḥshiyyah; Ibn García'],
 ['Enduring paradox','Arabic carries powerful anti-Arab arguments','Al-Zamakhsharī and his opponents']])['html'],
 mem16,
 [('Definition','Define Shuʿūbiyyah and explain why it cannot be treated as one coherent party.'),('Historical causes','Explain the transition from Umayyad tribal rivalry to ʿAbbāsid secretarial culture.'),('Comparison','Distinguish Arab-precedence, leveller and non-Arab supremacy positions.'),('Literature','How did mathālib writers invert genealogical claims and cultural virtues?'),('Religion','Explain al-Jāḥiẓ’s concern about language, the Prophet and zandaqah.'),('Regional development','Compare Ibn Waḥshiyyah’s Nabaṭ claims with Ibn García’s Iberian polemic.'),('Essay','Why is the Arabic expression of anti-Arab polemic a central irony of the movement?')],
 'The supplied reading traces Shuʿūbiyyah from intra-Arab tribal antagonisms and Khārijī religious equality through the influence of non-Arab ʿAbbāsid administrators. The movement encompassed rival positions: some defended Arab primacy, levellers used Qurʾānic piety to demand ethnic equality, and other writers declared non-Arab civilizations superior. Literary exchanges inverted claims about rhetoric, arms and ancestry, especially through mathālib invective. Critics such as al-Jāḥiẓ associated hostility to Arabic with religious danger; Nabaṭ and Iberian authors deployed ancient genealogy in reply. The enduring paradox is that some of the sharpest attacks on Arab ethnic privilege relied on Arabic literary culture itself.',
 [('Problem','Does universal Islam require Arab ethnic precedence?'),('Evolution','Umayyad tribal disputes → ʿAbbāsid secretarial polemic → theology and regional variants.'),('Three claims','Arab primacy / Qurʾānic equality / non-Arab primacy.'),('Weapons','Mathālib; invective against speech, military culture and ancestry.'),('Cases','Khārijīs, al-Jāḥiẓ, Ibn Waḥshiyyah, Ibn Qutaybah, Ibn García.'),('Analytical caution','Quoted ethnic abuse shows opponents’ rhetoric; it is not evidence that the stereotypes were true.')],
 '#685B81','1MrcsG73ToWGKKEO1TPLxJpTbd0yC32hnmH9r6NRdufI','shuubiyyah-arabic-literature')

manifest={'batch':'15-16','source':'Supplied connected Google Drive documents','source_ids':{'15':'1HT4NM_rlhy2RrY_TSd3uL0AxTTZW89Jb6SUFmcvlwp8','16':'1MrcsG73ToWGKKEO1TPLxJpTbd0yC32hnmH9r6NRdufI'},'stats':[res15,res16],'source_sha256':{str(n):hashlib.sha256((ROOT/'sources'/f'{n:02d}-raw-explainer.txt').read_bytes()).hexdigest() for n in (15,16)},'policy':'Editorial 5 main-page target, six when required. Do not revise CSS/JS/previous chapters; distinguish attributed source claims from independently verified statements.'}
(ROOT/'NEW_READINGS_15_16_MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps(manifest,indent=2,ensure_ascii=False))
