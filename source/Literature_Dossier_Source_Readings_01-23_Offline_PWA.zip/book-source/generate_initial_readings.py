#!/usr/bin/env python3
"""Rebuild *only the first two* authored chapters from the user's 2026-11-03 explainer texts.
Source markdown under sources/ remains the content-fidelity anchor. Supplemental
pedagogical callouts and revision materials below are explicitly additional.
No external historical assertions introduced.
"""
from pathlib import Path
import re, html, unicodedata
import mistune
from bs4 import BeautifulSoup, NavigableString

ROOT=Path(__file__).resolve().parent
md=mistune.create_markdown(plugins=['table'])

READINGS={
1:{'source':'01-raw-explainer.md','file':'01-petition-fatimid-caliph-al-amir.html',
   'title':'A Petition to the Fāṭimid Caliph al-Āmir',
   'subtitle':'Justice from the Imām · A 900-Year-Old Legal Mystery from the Cairo Genizah',
   'thesis':'A woman’s claim to 241 dinars reveals how petitions, legal proofs, a caliphal rescript, and the jurisdiction of mazālim could connect private distress to sovereign authority.',
   'roadmap':['A 900-year-old document, its paper and provenance','Two women, one inheritance debt of 241 dinars','Petitioning the Imām and mobilizing judicial enforcement','Basmala, blessing, narratio, petitio and Middle Arabic','Documentary proof, personal preservation and the idea of “a new life”'],
   'accent':'#747B32'},
2:{'source':'02-raw-explainer.md','file':'02-fatimid-amir-al-juyush-wazir.html',
   'title':'Was the Fatimid Amīr al-Juyūsh in fact a Wazīr (Another Version)',
   'subtitle':'The Sword and the Pen · Deconstructing the Fatimid Wazirate’s Radical Transformation',
   'thesis':'Badr al-Jamālī displaced the civilian “lords of the pen” with a militarized office that avoided the formal word wazīr yet exercised its authority; titles, decrees and militias together explain the shift.',
   'roadmap':['Classical wizāra, wasāṭa and the archetypal administrators','The crisis of 466/1074 and Badr’s military consolidation','The suppressed title and the “Sultan Paradox”','Buildings, ṭirāz, sijills and caliphal tawqīʿ','Successor militias and the road from Badr to Saladin'],
   'accent':'#637B32'},
}

# Insert material alongside the closest main-body claim. 'text' is supplemental
# pedagogical wording, not an unacknowledged quotation from the sources.
CALLOUTS={
1:{
 1:[('highyield','The stakes in one number','The claim is <strong>241 dinars in cash</strong>. Keep that figure attached to the legal process; it helps explain why the petition is framed as a demand for restoration.')],
 2:[('definition','Two related archival terms','<strong>Michaelides Collection</strong> names the collection in Cambridge holding A.169. <strong>Cairo Genizah</strong> identifies the broader documentary context discussed by the explainer; do not automatically treat the two labels as interchangeable.'),('examtip','Describe the object before interpreting it','Identify the document (<em>qiṣṣa</em>), material (paper), dimensions (46.1 × 17.3 cm), script (fast cursive), and addressee (al-Āmir), then explain what each datum lets a historian infer.')],
 3:[('concept','Two parties, unequal status','<strong>Claimant:</strong> the anonymous woman calling herself <em>al-mamlūka</em>. <strong>Debtor:</strong> the deceased <em>šarīfa</em> Ṭāhira (Sitt al-Ḥasab). Their social asymmetry gives the petition its historical significance.'),('memory','Memory anchor · the two women','<strong>“The servant claims; the noblewoman owes.”</strong> Use this contrast to remember who seeks recovery and whose estate is liable.'),('mistake','Do not reverse the roles','Sitt al-Ḥasab is the <strong>deceased debtor</strong>, not the petitioner. The woman submitting the petition remains unnamed in the supplied account.')],
 4:[('definition','Mazālim · tawqīʿ · waḍʿ al-yad','<em>Mazālim</em> is the ruler-linked jurisdiction for grievances; a <em>tawqīʿ</em> is the requested caliphal rescript; <em>waḍʿ al-yad</em> is the seizure of assets ordered for enforcement.'),('memory','Process memory · three actions','<strong>Appeal → Rescript → Seizure.</strong> The longer five-person chain fits inside these three functional steps; each answer should distinguish the request from its execution.'),('examtip','Authority is not the same as enforcement','Explain the division of labor: the Imām-Caliph authorizes the intervention, but the named judge carries out the act against the estate.')],
 5:[('memory','Petition’s verbal sequence','<strong>Begin → Bless → Bow → Report → Request.</strong> This matches <em>basmala</em>, prayers, <em>tuqabbil al-arḍ</em>, <em>tunhī ʿilā</em> and <em>tadraʿ</em> respectively.'),('concept','Middle Arabic in a technical formula','The form <em>ḥayāwa</em> is noteworthy because orthography itself becomes evidence, not merely an error to silently normalize.'),('highyield','Chronological clues in etiquette','The source treats “kissing the ground” and prayers for the caliph’s “pure sons” as historically significant expressions of Fāṭimid chancery practice.')],
 6:[('definition','Proofs and personnel','<em>Ḥujaj</em> = documentary legal proofs; <em>iqrārāt</em> = acknowledgments of debt; <em>ʿudūl</em> = certified witnesses; <em>ʿalāma</em> = a judge’s certification or motto.'),('mistake','Petition is not the completed court record','The supplied explanation identifies A.169 as a petitioner-held copy at the <em>beginning</em> of the process. Do not infer that asset seizure actually occurred merely because it was requested.')],
 7:[('highyield','“A new life” is the thesis in miniature','The requested <em>ḥayātan mujaddadatan</em> links private economic survival to the state’s promise of justice. It connects the material sum, administrative chain and personal plea.')]
},
2:{
 1:[('concept','Central problem · office versus title','The source’s paradox is that <em>amīr al-juyūsh</em> becomes the functional holder of wazīr-like authority while the title <em>wazīr</em> is absent from formal designation.'),('memory','One-line conceptual anchor','<strong>“The sword holds the office; the pen loses its monopoly.”</strong> Remember the structural shift rather than equating title and power.')],
 2:[('definition','Wizāra and wasāṭa','The source distinguishes <em>wizāra</em>, a high office with substantial independence, from <em>wasāṭa</em>, a more flexible intermediary role; the early caliphs often favored the latter or direct rule.'),('memory','Biblical/prophetic models in two verbs','<strong>Aaron assists; Joseph administers.</strong> The first model emphasizes support to authority, while the second legitimizes stewardship of fiscal resources.'),('examtip','Do not collapse the civilian period','Keep the thirty-eight-year interval after Ibn Killis and the different careers of Ibn Killis, al-Jarjarāʾī and al-Yāzūrī in chronological order.')],
 3:[('highyield','The 466/1074 turning point','Badr’s secret arrival with <strong>100 ships</strong>, his personal Juyūshiyya force, and the ensuing purge are the source’s explanation of military consolidation.'),('concept','Four fronts of pacification','The source lists the Eastern Delta, Alexandria, Upper Egypt and the Saljūq invasion force; the last is associated with an assembled army of <strong>30,000</strong>.'),('mistake','Title suppression did not mean weak power','Badr is portrayed as holding authority over everything “save the throne of the caliph.” Do not mistake the absent title for a reduced commission.')],
 4:[('definition','Wizārat tafwīḍ','The supplied account calls the new arrangement a “wazirate of delegation”: far-reaching administrative authority exercised on behalf of the caliph.'),('concept','The Sultan Paradox','The source explains the avoided title <em>Sultan</em> through existing Ṣulayḥī usage and concern about resemblance to the independent Saljūq sultans; this is distinct from the rejection of the bureaucratic label <em>wazīr</em>.'),('memory','Three-layer office test','Ask <strong>Name → Powers → Insignia.</strong> A title can vanish while decision-making power and material markers, such as <em>dār al-wizāra</em>, remain.')],
 5:[('memory','Three kinds of evidence','<strong>Stone → Cloth → Signature.</strong> Building inscriptions omit the title, earlier <em>ṭirāz</em> could display it, and private caliphal <em>tawqīʿ</em> openly acknowledges the wazirate.'),('examtip','Different documents answer different questions','Distinguish public inscriptions, official chancery <em>sijills</em> and the caliph’s personal <em>tawqīʿ</em>. The apparent contradiction becomes the argument, not a defect in the evidence.')],
 6:[('memory','Militia succession chain','<strong>Juyūshiyya → Afḍaliyya → Asadiyya.</strong> Link each name to Badr, al-Afḍal, and Shīrkūh/Saladin; it traces continuity in military bases of power.'),('highyield','Decrees anchor the succession','The source cites surviving commissions for Ṭalāʾiʿ, Shāwar, Shīrkūh and Saladin, while stating that Badr’s own full decree is lost.')],
 7:[('highyield','The decisive formulation','The source’s conclusion: military commanders became real holders of governmental power while the imamate-caliphate retained the throne; public nomenclature lagged behind institutional reality.')]
}}

REV={
1:{
'Chapter Summary': '''<p>The shorter supplied explainer reads Michaelides (charta) A.169 as an encounter between <strong>personal vulnerability</strong> and <strong>caliphal authority</strong>. An anonymous woman seeks recovery of <strong>241 dinars</strong> allegedly owed by the deceased <em>šarīfa</em> Ṭāhira, Sitt al-Ḥasab. Her appeal, couched in humble chancery formulas, asks the Imām-Caliph to empower Judge Nūr al-Mulk to enforce her documented claim.</p><p>The case joins several layers of evidence: the Michaelides manuscript’s material features, the private/legal documentary setting, judicial proofs (<em>ḥujaj</em>), a prospective <em>tawqīʿ</em>, and the requested <em>waḍʿ al-yad</em>. Its formulaic opening and Middle Arabic spelling are evidence for the style of Fāṭimid petitioning. The petition is <strong>a request for enforcement</strong>, not by itself proof of a completed recovery.</p><p>Its closing appeal for “a new life” crystallizes the thesis: the prospect of economic restoration depended on converting a documented private debt into an enforceable intervention by the ruler’s administration.</p>''',
'One-Page Revision Sheet': '''<div class="revision-grid"><div class="revision-card"><h3>Document</h3><ul><li>Michaelides (charta) A.169</li><li>Paper · 46.1 × 17.3 cm</li><li>Fāṭimid reign of al-Āmir, 1101–1130 A.D.</li><li><em>Qiṣṣa</em>, with indented <em>basmala</em></li></ul></div><div class="revision-card"><h3>Two women</h3><ul><li>Anonymous petitioner: <em>al-mamlūka</em></li><li>Debtor: deceased <em>šarīfa</em> Ṭāhira / Sitt al-Ḥasab</li><li>Claim: <strong>241 dinars</strong></li></ul></div><div class="revision-card"><h3>Legal chain</h3><ul><li><em>Ḥujaj / iqrārāt</em>: proofs of debt</li><li><em>Mazālim</em>: grievance jurisdiction</li><li><em>Tawqīʿ</em>: caliphal rescript sought</li><li>Nūr al-Mulk: designated judge</li><li><em>Waḍʿ al-yad</em>: seizure requested</li></ul></div><div class="revision-card"><h3>Language / interpretation</h3><ul><li><em>Tuqabbil al-arḍ</em>: kisses ground</li><li><em>Tunhī ʿilā</em>: report</li><li><em>Tadraʿ</em>: petition</li><li><em>Ḥayāwa</em>: Middle Arabic form</li><li>Desired end: <em>ḥayātan mujaddadatan</em></li></ul></div></div>''',
'Key Definitions': '''<table><thead><tr><th>Term</th><th>Definition in this reading</th></tr></thead><tbody><tr><td><em>Qiṣṣa</em></td><td>Formal petition seeking intervention.</td></tr><tr><td><em>Al-mamlūka</em></td><td>Petitioner’s humble self-designation (“slave/servant”).</td></tr><tr><td><em>Šarīfa</em></td><td>Honorific connected here with descent from al-Ḥasan and al-Ḥusayn.</td></tr><tr><td><em>Mazālim</em></td><td>Ruler-linked forum of redress for wrongs.</td></tr><tr><td><em>Tawqīʿ</em></td><td>Requested sovereign rescript directing action.</td></tr><tr><td><em>Waḍʿ al-yad</em></td><td>Putting a hand on assets; seizure/enforcement.</td></tr><tr><td><em>Ḥujaj / iqrārāt / ʿudūl</em></td><td>Legal proofs / debt acknowledgments / certified witnesses.</td></tr><tr><td><em>ʿAlāma</em></td><td>Judicial motto or mark of certification.</td></tr><tr><td><em>Ḥayāwa</em></td><td>Non-classical Middle Arabic word-form for “life.”</td></tr></tbody></table>''',
'Key Tables': '''<p>Condensed recap of the <strong>Document Profile</strong> and <strong>Chancery Formula</strong> tables already presented in §§1.2 and 1.5.</p><table><thead><tr><th>Layer</th><th>Remember</th><th>Why it matters</th></tr></thead><tbody><tr><td>Physical</td><td>A.169; paper; 46.1 × 17.3 cm</td><td>Material evidence for an actual petition.</td></tr><tr><td>Social</td><td>Anonymous claimant / Sitt al-Ḥasab</td><td>Power and status imbalance.</td></tr><tr><td>Procedure</td><td>Proofs → rescript → judicial action</td><td>Separate appeal from enforcement.</td></tr><tr><td>Formula</td><td>Begin, bless, bow, report, request</td><td>Chancery hierarchy and submission.</td></tr><tr><td>Outcome sought</td><td>“A new life”</td><td>Material restoration through justice.</td></tr></tbody></table>''',
'Memory Aids': '''<div class="callout-grid"><div class="callout callout--memory"><div class="tag">🟪 From §1.3</div><p><strong>“The servant claims; the noblewoman owes.”</strong></p></div><div class="callout callout--memory"><div class="tag">🟪 From §1.4</div><p><strong>Appeal → Rescript → Seizure.</strong></p></div><div class="callout callout--memory"><div class="tag">🟪 From §1.5</div><p><strong>Begin → Bless → Bow → Report → Request.</strong></p></div></div>''',
'Possible Examination Questions': '''<div class="exam-q"><span class="qtype">Short answer</span><p>Identify Michaelides (charta) A.169, its material, approximate date and claimed sum.</p></div><div class="exam-q"><span class="qtype">Definition</span><p>Distinguish <em>mazālim</em>, <em>tawqīʿ</em> and <em>waḍʿ al-yad</em>.</p></div><div class="exam-q"><span class="qtype">Comparison</span><p>Compare the legal and social roles of the anonymous petitioner and Sitt al-Ḥasab.</p></div><div class="exam-q"><span class="qtype">Conceptual</span><p>Why are formulaic phrases such as <em>tuqabbil al-arḍ</em> evidence for administrative hierarchy?</p></div><div class="exam-q"><span class="qtype">Application</span><p>Reconstruct the steps needed to move from a written debt acknowledgement to seizure of estate assets.</p></div><div class="exam-q"><span class="qtype">Long essay</span><p>Explain how one Fāṭimid petition illuminates the relationship between documentary culture, access to justice, gender and sovereign power.</p></div>'''
},
2:{
'Chapter Summary': '''<p>The supplied explainer asks whether the <em>amīr al-juyūsh</em> was really a <em>wazīr</em>. The answer is intentionally paradoxical: <strong>yes in delegated administrative power, but not consistently in formal public designation.</strong> In 466/1074 Badr al-Jamālī entered a collapsing Fāṭimid state with his personal military forces and redirected authority from the <em>arbāb al-aqlām</em> to the <em>arbāb al-suyūf</em>.</p><p>The earlier civilian office drew on <em>wizāra</em>/<em>wasāṭa</em>, the Moses/Aaron and Joseph models, and careers such as those of Ibn Killis, al-Jarjarāʾī and al-Yāzūrī. Badr’s purge and military pacification produced a different holder of the powers of office. The source explains the avoided titles <em>wazīr</em> and <em>Sultan</em> by different political considerations, although ministerial insignia and residences remained.</p><p>The decisive comparison is between public materials (inscriptions and formal decrees) and the caliph’s direct <em>tawqīʿ</em>, which openly calls later military commanders wazīrs. The successor militias and surviving decrees carry this institutional logic through Shīrkūh and Saladin.</p>''',
'One-Page Revision Sheet': '''<div class="revision-grid"><div class="revision-card"><h3>The old office</h3><ul><li><em>Wizāra</em>: high and relatively independent office</li><li><em>Wasāṭa</em>: intermediary</li><li>“Lords of the Pen”</li><li>Models: Aaron (assistance), Joseph (stewardship)</li></ul></div><div class="revision-card"><h3>Break of 466/1074</h3><ul><li>100 ships: Acre → Damietta</li><li>Badr’s <em>Juyūshiyya</em></li><li>Banquet purge; campaigns and restored control</li><li>30,000 against the Saljūq force (source figure)</li></ul></div><div class="revision-card"><h3>Title paradox</h3><ul><li>Official label: <em>amīr al-juyūsh</em></li><li>Practical powers: wazīr-like delegation</li><li><em>Sultan</em> avoided for separate reasons</li><li><em>Dār al-wizāra</em> and ministerial insignia survive</li></ul></div><div class="revision-card"><h3>Evidence and continuity</h3><ul><li>Building inscriptions omit <em>wazīr</em></li><li><em>Ṭirāz</em> and <em>tawqīʿ</em> reveal office identity</li><li>Juyūshiyya → Afḍaliyya → Asadiyya</li><li>Ṭalāʾiʿ, Shāwar, Shīrkūh, Saladin decrees</li></ul></div></div>''',
'Key Definitions': '''<table><thead><tr><th>Term</th><th>Definition in this reading</th></tr></thead><tbody><tr><td><em>Arbāb al-aqlām / al-suyūf</em></td><td>Lords of the Pen / Lords of the Sword: two bases of authority.</td></tr><tr><td><em>Wizāra / wasāṭa</em></td><td>Wazirate as an office / intermediary role.</td></tr><tr><td><em>Amīr al-juyūsh</em></td><td>Commander of the armies; Badr’s chosen official designation.</td></tr><tr><td><em>Wizārat tafwīḍ</em></td><td>Wazirate of delegation, involving very broad powers.</td></tr><tr><td><em>Sijill</em></td><td>Formal written decree or commission.</td></tr><tr><td><em>Tawqīʿ</em></td><td>The caliph’s personal endorsement/signature or note.</td></tr><tr><td><em>Ṭirāz</em></td><td>Official textile inscription serving as evidence of titulature.</td></tr><tr><td><em>Dār al-wizāra</em></td><td>Ministerial residence retained as a symbol of the office.</td></tr></tbody></table>''',
'Key Tables': '''<p>Recap of the <strong>bureaucratic profiles</strong>, <strong>title/function</strong>, and <strong>militia succession</strong> tables introduced in the main reading.</p><table><thead><tr><th>Regime</th><th>Basis of authority</th><th>Key interpretive test</th></tr></thead><tbody><tr><td>Civilian wazirate</td><td>Fiscal and chancery expertise</td><td>Explicit title, administrative career and models.</td></tr><tr><td>Badr’s military delegation</td><td>Personal army and all-encompassing authority</td><td>Title suppressed, actual powers expanded.</td></tr><tr><td>Successor military wazīrs</td><td>Militias and caliphal commissions</td><td>Personal <em>tawqīʿ</em> confirms wazirate.</td></tr></tbody></table><table><thead><tr><th>Militia</th><th>Leader / continuity</th></tr></thead><tbody><tr><td>Juyūshiyya</td><td>Badr al-Jamālī</td></tr><tr><td>Afḍaliyya</td><td>Al-Afḍal, Badr’s son</td></tr><tr><td>Asadiyya</td><td>Asad al-Dīn Shīrkūh → Saladin</td></tr></tbody></table>''',
'Memory Aids': '''<div class="callout-grid"><div class="callout callout--memory"><div class="tag">🟪 From §2.1</div><p><strong>“The sword holds the office; the pen loses its monopoly.”</strong></p></div><div class="callout callout--memory"><div class="tag">🟪 From §2.2</div><p><strong>Aaron assists; Joseph administers.</strong></p></div><div class="callout callout--memory"><div class="tag">🟪 From §2.4</div><p><strong>Name → Powers → Insignia.</strong></p></div><div class="callout callout--memory"><div class="tag">🟪 From §2.5</div><p><strong>Stone → Cloth → Signature.</strong></p></div><div class="callout callout--memory"><div class="tag">🟪 From §2.6</div><p><strong>Juyūshiyya → Afḍaliyya → Asadiyya.</strong></p></div></div>''',
'Possible Examination Questions': '''<div class="exam-q"><span class="qtype">Short answer</span><p>What changed in 466/1074, and why does the source stress Badr’s personal military force?</p></div><div class="exam-q"><span class="qtype">Definition</span><p>Explain the distinction between <em>wizāra</em>, <em>wasāṭa</em> and <em>wizārat tafwīḍ</em>.</p></div><div class="exam-q"><span class="qtype">Comparison</span><p>Contrast the “Lords of the Pen” and “Lords of the Sword” in origins, source of authority and official titulature.</p></div><div class="exam-q"><span class="qtype">Document analysis</span><p>Why might building inscriptions, <em>sijills</em> and <em>tawqīʿāt</em> present different views of the same office?</p></div><div class="exam-q"><span class="qtype">Conceptual</span><p>Explain the “Sultan Paradox” and why it is separate from the avoidance of <em>wazīr</em>.</p></div><div class="exam-q"><span class="qtype">Long essay</span><p>Was the Fāṭimid <em>amīr al-juyūsh</em> a wazīr? Evaluate the evidence from administrative history, material symbols, caliphal signatures and militia succession.</p></div>'''
}}

ICONS={'definition':'🟦 Definition','concept':'🟩 Key concept','examtip':'🟨 Exam insight','mistake':'🟥 Common mistake','memory':'🟪 Memory aid','highyield':'⭐ High-yield'}

def callout(t,label,content):
    return f'<div class="callout callout--{t}" data-content-type="{t}" data-pagination="allow-split"><div class="tag">{ICONS[t]} · {html.escape(label)}</div><p>{content}</p></div>'

def improve_md(source,n):
    if n==1: return source
    a='''The Bureaucratic Ideal: Key Figures of the Pen,,

Figure,Year of Appointment,Role & Background

Yaʿqūb ibn Killis,367/977,Expert in finance and scholarly administration; the first true Fatimid wazīr.

Al-Jarjarāʾī,418/1027,A career bureaucrat who rose through the clerical hierarchy of the  dīwān  system.

Al-Yāzūrī,450/1058,"Strictly a ""man of the pen""; his fall preceded the final collapse of civilian authority."'''
    b='''**The Bureaucratic Ideal: Key Figures of the Pen**

| Figure | Year of Appointment | Role & Background |
|---|---|---|
| Yaʿqūb ibn Killis | 367/977 | Expert in finance and scholarly administration; the first true Fatimid wazīr. |
| Al-Jarjarāʾī | 418/1027 | A career bureaucrat who rose through the clerical hierarchy of the *dīwān* system. |
| Al-Yāzūrī | 450/1058 | Strictly a “man of the pen”; his fall preceded the final collapse of civilian authority. |'''
    assert a in source,'Pseudotable was not matched; do not silently lose its rows'
    return source.replace(a,b)

def extract_sections(source,n):
    if n==1:
        # Markdown ## numbered headings, discard only the source's initial title from body
        chunks=re.split(r'(?m)^## (\d+)\. (.+?)\s*$',source)
        assert len(chunks)==22, (n,len(chunks))
        return [(chunks[i+1].strip(),chunks[i+2].strip()) for i in range(1,len(chunks),3)]
    # section headings are ##### except initial ### title; keep all explanatory text
    source=re.sub(r'(?m)^### The Sword and the Pen: Deconstructing the Fatimid Wazirate’s Radical Transformation\s*\n','',source,count=1)
    chunks=re.split(r'(?m)^##### (.+?)\s*$',source)
    assert len(chunks)==15,(n,len(chunks))
    return [(chunks[i].strip(),chunks[i+1].strip()) for i in range(1,len(chunks),2)]

def supplementary_table(n, k):
    if n==2 and k==6:
        return """<div class="process-strip" role="group" aria-label="Personal military succession"><div class="process-step"><span class="step-no">01</span><strong>Juyūshiyya</strong><small>Badr</small></div><span class="process-arrow">→</span><div class="process-step"><span class="step-no">02</span><strong>Afḍaliyya</strong><small>Al-Afḍal</small></div><span class="process-arrow">→</span><div class="process-step"><span class="step-no">03</span><strong>Asadiyya</strong><small>Shīrkūh → Saladin</small></div></div><p class="table-caption">A second representation of the succession summarized in the main text; not a replacement for the source explanation.</p>""" + '''<table><thead><tr><th>Militia</th><th>Principal association</th><th>Institutional effect</th></tr></thead><tbody><tr><td>Al-Juyūshiyya</td><td>Badr al-Jamālī</td><td>Establishes the personal military basis</td></tr><tr><td>Al-Afḍaliyya</td><td>Al-Afḍal, Badr’s son</td><td>Transmits military influence through succession</td></tr><tr><td>Al-Asadiyya</td><td>Shīrkūh → Saladin</td><td>Extends the model into the final Fāṭimid wazirate</td></tr></tbody></table><p class="table-caption">Militia succession, organized from the source’s enumerated list.</p>'''
    if n==2 and k==4:
        return '''<table><thead><tr><th>Dimension</th><th>Public designation</th><th>Practical continuity</th></tr></thead><tbody><tr><td>Name</td><td>Amīr al-juyūsh rather than wazīr</td><td>Later caliphal notes call holders wazīrs</td></tr><tr><td>Powers</td><td>Military identity foregrounded</td><td>Delegated authority across state affairs</td></tr><tr><td>Insignia</td><td>Official inscriptions avoid the title</td><td><em>Dār al-wizāra</em> and collar of the wazīr persist</td></tr></tbody></table><p class="table-caption">Comparison derived from the title/function distinction in the supplied explainer.</p>'''
    return ''

ARABIC_RE=re.compile(r'[\u0600-\u06FF]+(?:[ \u0600-\u06FF]+)*')

def mark_arabic(markup):
    """Preserve the user's exact Arabic text while guaranteeing Arabic font shaping."""
    doc=BeautifulSoup(markup,'html.parser')
    for node in list(doc.find_all(string=True)):
        if not isinstance(node,NavigableString) or not ARABIC_RE.search(str(node)):
            continue
        fragments=[];position=0
        for match in ARABIC_RE.finditer(str(node)):
            if match.start()>position:fragments.append(NavigableString(str(node)[position:match.start()]))
            arabic=doc.new_tag('span',attrs={'class':'arabic','lang':'ar','dir':'rtl'})
            arabic.string=match.group(0)
            fragments.append(arabic);position=match.end()
        if position<len(str(node)):fragments.append(NavigableString(str(node)[position:]))
        for part in reversed(fragments):node.insert_after(part)
        node.extract()
    return str(doc)

def section_html(n, i, title, source_md):
    body=md(source_md)
    # Strip the source embedded subtitle only; all body prose stays verbatim in main.
    body=body.replace('<table>','<table data-pagination="repeat-header">')
    additions=CALLOUTS[n].get(i,[])
    cards=''.join(callout(*c) for c in additions)
    if len(additions) in (2,3):cards='<div class="callout-grid">'+cards+'</div>'
    # Plant callouts alongside the passage they explain, not just in the revision section.
    parsed=BeautifulSoup(body, 'html.parser')
    nodes=[x for x in parsed.contents if getattr(x,'name',None)]
    anchors={1:{1:0,2:1,3:0,4:2,5:1,6:0,7:0},
             2:{1:1,2:2,3:1,4:2,5:2,6:1,7:0}}
    anchor=nodes[min(anchors[n].get(i,0),len(nodes)-1)] if nodes else None
    if anchor:
        cluster=BeautifulSoup(cards,'html.parser')
        anchor.insert_after(cluster)
        body=str(parsed)
        cards=''
    body=mark_arabic(body)
    return f'''<div class="section" id="s{n}-{i}"><div class="section-number">§{n}.{i}</div>
      <h2>{html.escape(title)}</h2><div class="section-body">\n{body}\n{supplementary_table(n,i)}\n{cards}</div></div>'''

def revision(n):
    parts=[]
    for i,(name,body) in enumerate(REV[n].items(),1):
        if name == 'Possible Examination Questions':
            body='<div class="revision-grid exam-question-grid">'+body+'</div>'
        parts.append(f'''<div class="section" id="s{n}-rev-{i}"><div class="section-number">REV {i:02d}</div>
          <h2>{html.escape(name)}</h2><div class="section-body">{body}</div></div>''')
    return '\n'.join(parts)

def build(n):
    info=READINGS[n]
    original=(ROOT/'sources'/info['source']).read_text(encoding='utf8')
    content=improve_md(original,n)
    sections=extract_sections(content,n)
    assert len(sections)==7,(n,len(sections))
    roadmap=''.join(f'<li>{html.escape(item)}</li>' for item in info['roadmap'])
    body='\n'.join(section_html(n,i,title,part) for i,(title,part) in enumerate(sections,1))
    source_note='User-supplied explanatory text for Reading '+str(n)+'; original scholarly reading not independently supplied or verified.'
    output=f'''<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{info['accent']};">
      <div class="leaf">
        <div class="chapter-title-page">
          <div class="reading-eyebrow">Reading {n:02d} · Literature Dossier</div>
          <h1>{html.escape(info['title'])}</h1>
          <p class="subtitle">{html.escape(info['subtitle'])}</p>
          <hr class="gold-rule">
          <div class="opener-split">
            <div class="thesis-block"><p class="kicker">Central thesis</p><p>{html.escape(info['thesis'])}</p></div>
            <div class="roadmap"><p class="kicker">In this reading</p><ol>{roadmap}</ol></div>
          </div>
          <p class="source-cite">{html.escape(source_note)}</p>
        </div>
        {body}
      </div>
      <div class="revision-zone"><div class="revision-leaf">
        <div class="revision-kicker">Reading {n:02d} · Revision &amp; recall</div>
        {revision(n)}
      </div></div>
    </section>'''
    out=ROOT/'chapters'/info['file']
    out.write_text(output,encoding='utf8')
    soup=BeautifulSoup(output,'html.parser')
    assert len(soup.select('.section'))==13
    assert len(soup.select('.revision-zone .section'))==6
    assert len(soup.select('.chapter-title-page'))==1
    print(f'Generated Reading {n}: {out.name} ({len(output):,} chars), {len(soup.select(".callout--memory"))} memory cards')

if __name__=='__main__':
    for n in READINGS: build(n)
