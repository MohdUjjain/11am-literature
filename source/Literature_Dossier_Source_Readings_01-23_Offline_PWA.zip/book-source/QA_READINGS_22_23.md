# Readings 22–23 — Editorial, Publishing and Offline-App QA

Date: 2026-11-05. Sources: the two original Google Drive explanatory documents, archived byte-unchanged as `sources/22-raw-explainer.txt` and `sources/23-raw-explainer.txt`. Underlying scholarly publications have not been independently verified. Source-derived causal theories, the Fāṭimid glass-jeton dispute, and numerical comparisons retain explicit qualifiers.

## Editorial result

- **Reading 22 — The Monetary History of Egypt, 642–1517:** 7 main sections; **5 main pages**; 6 revision sections; 5 in-text memory aids, copied exactly into revision; 25 sidebar cards.
- **Reading 23 — 1068 in the Fayyum:** 6 main sections; **4 main pages**; 6 revision sections; 5 in-text memory aids copied exactly; 22 sidebar cards.
- Main text remains independently explanatory; the six-colored sidebar carries reinforcement, not the only occurrence of necessary evidence. The normal font size, spacing, paper size, table CSS, print engine, and chapter color system remain unchanged. Reading 19 remains reserved.
- Reading 22 covers coin versus account, bullion, the ṣayrafī, Byzantine/Umayyad transitions, Fāṭimid doctrinal and bullion issues, glass disks as disputed weights/currency, Ayyubid warfare, and the Mamluk/ Venetian/ copper turn. Reading 23 preserves pre-crisis irrigation engineering, 1030 dustūr, Naqlūn Coptic archive, Damūya prices, protection rights, the Lawāta interpretation and the numerical/archaeological aftermath, distinguishing chronological evidence from climate determinism.

## Actual PDF and screen checks

| Test | Result |
| --- | --- |
| New pair print, offline-font profile | 23 physical = 23 composed pages |
| New pair real bookmarks / Contents links | 31 / 2 |
| Complete 22-reading PDF | 239 physical = 239 composed pages |
| Complete bookmarks / Contents links | 336 / 22 |
| New cards exact passage-page matches | 47 / 47 |
| Complete cards exact passage-page matches | 441 / 442 |
| Inherited exception | `s4-6-n2` in Reading 04 under offline fonts; preserved as before |
| Measured overflow / browser errors | None |
| 390px mobile horizontal overflow | None (390px scroll / 390px viewport) |
| Alternate font-metric pair | 24 pages; passed |
| Reversed order 23,22 | 23 pages; passed |
| Prior completed chapters and shared publisher files | 27 files SHA-identical to the previous PWA checkpoint |
| PWA cache update | Version `11am-lit-reader-01-23-v2`; all 22 readings in one HTML file |

PDFs are composed with the available local fallback fonts during offline test; web display still uses the original remote font settings, and actual wrapping can vary when web fonts are loaded. The separately rendered full PDF is **not** pre-cached by the PWA. The service worker automatically stores the updated *entire HTML* when installed/updated online, and the Contents control allows manual save/refresh; browser eviction remains possible. User should verify the live site and offline launch on their device.

The linked source explainers are the only factual basis for these chapters; there was no independent reconciliation of differences between them and primary numismatic/archaeological publications. No citations or numbers have been silently added from outside research.
