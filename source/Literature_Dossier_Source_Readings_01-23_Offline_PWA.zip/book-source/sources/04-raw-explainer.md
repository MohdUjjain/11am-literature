### The Sword, the Pen, and the Performance of Power: Al-Afḍal b. Badr al-Jamālī and the Fatimid Response to the First Crusade

##### 1. The Enigma of the Vizierate: An Intellectual Invitation

At the sunset of the eleventh century, the Fatimid Imām-Caliphate—a Shīʿī Ismāʿīlī power claiming direct descent from the Prophet Muhammad—stood as a beacon of Mediterranean civilization. However, the transition from the exceptionally long reign of al-Mustanṣir (d. 1094) to the sudden, existential crisis of the First Crusade in 1097 exposed deep structural vulnerabilities. At the center of this storm stood the vizier al-Afḍal b. Badr al-Jamālī, a man whose historical memory has become a battleground for competing medieval narratives of masculinity.

The central thesis of this inquiry is that al-Afḍal’s reputation was meticulously constructed by two opposing forces: a state-sponsored "laudatory narrative" portraying him as a virile martial hero, and a later, polemical "shadow narrative" created by Ayyubid and Mamluk historians. These later critics sought to emasculate al-Afḍal by reframing his political maneuvers not as strategic decisions, but as the irrational outbursts of a tyrant ruled by passion—the very antithesis of the medieval masculine ideal.

**Roadmap of Inquiry**

- **The Blueprint of Manhood:**  Establishing the Aristotelian and  *adab* -based framework of masculinity as a performed state of rationality.
- **The Inherited Burden:**  Analyzing the administrative shift from the "Pen" to the "Sword" during the crisis of the late 11th century.
- **The Shadow Narrative:**  Deconstructing three specific case studies of alleged irrationality used to undermine al-Afḍal's legacy.
- **The Martial Performance:**  Examining the deployment of  *jihād*  rhetoric as a tool to compensate for a lack of battlefield experience.
- **The Al-Faramā Incident:**  A comparative analysis of how contemporary propaganda and later oral traditions divergent interpret the 1118 Frankish raid.

##### 2. The Blueprint of Manhood: Masculinity as an Artificial State

In the medieval Islamic intellectual milieu, masculinity was not merely a biological attribute but a precarious status known as  *muruwa*  (manliness), achieved through the cultivation of  *adab*  (refined conduct). This framework was heavily influenced by Aristotelian ethics, which posited that the ideal man was defined by the "rule of reason" over the "passionate element." To lose self-control was to descend into a state of "unmanliness" or "femininity," which medieval scholars associated with anarchy and social frailty.

The Binary of Medieval Masculinity,Masculine (The Ideal Ruler),Unmanly / Feminine (The Subject)

Primary Driver,Rationality and Self-Possession,"Passion, Impulse, and Emotion"

Political Role,"Order, Justice, and Protection","Anarchy, Frailty, and Instability"

Key Traits,"Wisdom, Martial Valor, Restraint","Jealousy, Excess Anger, Querulousness"

Intellectual Root,"Aristotelian ""Rule of Reason""","""The Soul of Passion"" (Source of Deviation)"

These standards served as a "grading rubric" for later historians. The ninth-century scholar al-Jāḥiz provided the intellectual blueprint for these attacks, writing that "Jealousy... is a common characteristic of women, by reason of their frailty." He further warned that "Anger is one of Satan’s characteristics, and passion shows itself in the guise of a woman." For a vizier like al-Afḍal, any evidence of excessive ire or jealousy was weaponized by later chroniclers to prove he was fundamentally unfit for the "masculine" duty of governance.

##### 3. Inheriting the Burden: From Badr al-Jamālī to al-Afḍal

The power wielded by al-Afḍal was an inheritance from his father, Badr al-Jamālī, who in 1074 combined the roles of  *wazīr*  (civil administrator) and  *amīr al-juyūsh*  (commander of the armies). Modern historians frequently utilize the terms  *wazīr al-qalam*  (Vizier of the Pen) and  *wazīr al-sayf*  (Vizier of the Sword) to describe this merger. However, these categories—much like Leila al-Imad’s use of  *wizārat al-tafwīḍ*  (executive) and  *wizārat al-tanfīdh*  (non-executive)—often reflect later Ayyubid administrative frameworks or Abbasid theories (such as those of al-Mawardi) projected backward onto the Fatimid state.

Unlike his father, a seasoned general from the Syrian frontier, al-Afḍal was a product of the Cairo court. His upbringing necessitated a specific performance of "martial masculinity" to justify his command over a professional military he did not rise through.

**Fact Check: Al-Afḍal’s Courtly Ascent**  Al-Afḍal was groomed for power within the palace walls, not the barracks. At the age of only  **14**  (c. 1080), he was granted the prestigious title  **"Sincere friend of the Caliph"**  ( *ṣifwat amīr al-mu’minīn* ). By 1087, his authority was so absolute that his name was included in the  **official sermon (**  ***khuṭba***  **)**  alongside the Caliph and his father—the ultimate symbolic recognition of political legitimacy in the Islamic world.

##### 4. The Shadow Narrative: Emasculation in the Later Sources

Historians from the Ayyubid and Mamluk periods (Ibn Ẓāfir, al-Nuwayrī, al-Maqrīzī) systematically dismantled al-Afḍal’s reputation by cataloging anecdotes of emotional instability.

**Three Case Studies of Irrationality:**

1. **The Crisis of Jealousy:**  Chroniclers allege al-Afḍal was so "strongly jealous" of his women that after spotting a slave girl merely looking toward the road from his roof terrace, he ordered her beheading. His subsequent public eulogy for her was framed by later writers not as romantic, but as the behavior of a "fool" guided by emotion rather than reason.
2. **The Tyranny of Forgetfulness:**  Sources claim al-Afḍal would imprison men in fits of rage and then—critically— **forget them** . Upon his death, 100,000 prisoners were reportedly released. This narrative emphasizes a lack of rational administrative follow-through; he was portrayed as a man of temporary "fits," a trait the  *adab*  tradition specifically categorized as unmanly.
3. **The Nizārī Schism (1094):**  While contemporary sources accept the succession of al-Mustaʿlī as a valid theological designation ( *naṣṣ* ), later polemics attribute the split to al-Afḍal’s personal "hatred." They claim al-Afḍal "lessened the importance" of the eldest son, Nizār, during al-Mustanṣir’s life, eventually manipulating the succession to spite Nizār for an old insult hurled at a palace gate. By reducing a major schism to a personal vendetta, these sources frame al-Afḍal as a tyrant who prioritized "feminine" spite over the stability of the Imāmate.

##### 5. The Martial Image: Jihād as a Performance of Legitimacy

To counter his image as a "courtier-vizier," contemporary writers like Ibn al-Ṣayrafī and Ibn al-Qulzumī emphasize al-Afḍal’s "violent masculinity" in three theaters: the suppression of the Alexandria rebellion, the recapture of Jerusalem from the Artuqids (1098), and the initial response to the Franks at Asqalān.

**The Language of Jihād**  Contemporaneous propaganda utilized the consonantal root  **j-h-d**  with surgical precision. By framing his actions as  *jihād* , al-Afḍal attempted to redress his lack of military pedigree. The term was a rhetorical bridge, signaling to the court that the vizier was personally fulfilling the virile duties of the "Sword of the Imām," even when he was merely "coordinating" rather than leading from the front.

##### 6. The Al-Faramā Incident: A Study in Propaganda vs. Reality

The 1118 raid on the coastal town of al-Faramā by King Baldwin of Jerusalem provides a stark contrast between state spin and the gritty reality of oral tradition.

- **The Contemporary Frame (Ibn al-Qulzumī):**  Centers on al-Afḍal’s "coordination." He is the master strategist who "raised a great army" and forced the Frankish retreat, preserving the dignity of the realm.
- **The Later Frame (Ibn Ẓāfir, al-Maqrīzī):**  Centers on  **devastation and divine intervention** . These sources detail the burning of mosques and the slaughter of an "invalid and his daughter." Crucially, they record that the Franks retreated only because Baldwin fell ill. The most evocative detail—that Baldwin’s companions "salted his body" after his death at al-ʿArīsh to return him to Jerusalem—renders al-Afḍal’s military response irrelevant.

The  *Kitāb al-Afḍaliyyāt*  preserves a state letter regarding al-Faramā that explicitly frames the event as a "decision to order  *jihād* ." This reveals the polemical intent: the vizier needed to transform a humiliating raid into a scripted victory of state-led "action to ruin the enemy."

##### 7. Conclusion: The Fragility of Historical Memory

Al-Afḍal’s performance of masculinity was a necessary survival strategy for a "Vizier of the Pen" holding a "Vizier of the Sword’s" office. He utilized the rhetoric of  *jihād*  to mask his military inexperience and secure his executive power. However, the survival of the "Shadow Narrative" demonstrates that state-sponsored propaganda is often less durable than the visceral, oral anecdotes of failure. While al-Afḍal sought to be remembered as the virile protector of the Fatimids, later history—judging him by the very  *adab*  standards he lived by—remembered him as the irrational tyrant who "forgot" his prisoners and split the faith out of spite.

**Conceptual Hierarchy of al-Afḍal’s Legacy**

- **The Context of Crisis:**  The pressure of the First Crusade and the transition from the "long reign" of al-Mustanṣir.
- **The Strategy of Performance:**
- The merger of administrative and military titles.
- The use of  *jihād*  rhetoric as a "redress" for a courtly upbringing.
- **The Narrative Conflict:**
- **State Propaganda:**  Durable only during the subject's life.
- **Oral/Polemical Tradition:**  The endurance of negative anecdotes of "unmanly" passion over "martial" achievement.

In the final analysis, the study of al-Afḍal b. Badr al-Jamālī offers a profound reflection on the Fatimid era—a period where the dignity of the Imām-Caliphate was maintained through a delicate, and ultimately fragile, balance between the sword of the general and the pen of the propagandist.
