The Nile and the Throne: Decoding 'The Greatest Calamity' of Fatimid Egypt
The Gift of the River and the Burden of the State
The historiography of Egypt is inextricably linked to the ancient maxim of Herodotus: "Egypt... is the gift of the river." This phrase has long fostered a deterministic view of the Nile, suggesting that the mere fluctuation of its waters dictated the rise and fall of dynasties. Yet, an autopsy of the Fatimid Caliphate’s mid-eleventh-century collapse reveals a more complex reality. While the river’s hydrological periodicity provided the spark for economic distress, the spark only became an all-consuming conflagration when the state’s capacity for management withered.
The central thesis of this inquiry is that the severity of a famine was determined not by the Nilometer alone, but by the state’s ability to coordinate agricultural infrastructure and curb the predatory self-interest of its own bureaucratic and military factions. We shall journey from the foundational hydraulics of Fatimid governance to the contained crises of the early 11th century, ultimately examining the total systemic failure known as  al-Shidda al-ʿUzma —the "Greatest Calamity."
First Principles: The Hydraulics of Fatimid Governance
In the medieval Mediterranean, statecraft was a form of applied hydrology. The Nile began to "breathe" in mid-June, with the agricultural year pivoting on the measurements taken at the Nilometer on al-Rawda Island. The vital threshold was 16 cubits; when the water touched this mark, the state celebrated  wafa’ al-Nil  (the abundance of the Nile), signaling that the flood was sufficient to reach the higher lands.
To translate this deluge into wealth, the Fatimid administration maintained a rigorous presence in the countryside:
* Infrastructure Maintenance:  The government oversaw the  jusur  (dykes) and  khuljan  (canals). This was a massive coordination effort, funded by specific taxes levied on landholders to ensure the water was distributed equitably across the provinces.
* The Agrarian Cycle:
* Irrigation:  Between September and November, officials managed the sequential opening of dams.
* Survey and Classification:  Once the flood receded, land was surveyed and classified based on water depth and previous crops to determine the  Kharaj  (land tax).
* Taqwiya (Reinforcement):  Recognizing that a peasant without resources could not produce revenue, the state provided  taqawi  (seed corn) to ensure the subsequent planting.
* The Fiscal Engine:   Kharaj  was the principal source of state specie. Consequently, urban food stability was viewed as the "basis of civilization." Ensuring the granaries of Cairo were full was not merely an act of piety, but a prerequisite for the survival of the throne.
Anatomy of a Proto-Crisis: Private Interest vs. Public Welfare
A Nile crisis often manifested as a psychological and economic "proto-crisis" months before the first crop failed. Because Nilometer levels were announced publicly throughout the summer, the merchant classes and high-ranking bureaucrats could anticipate a shortfall as early as July.
This foreknowledge triggered a conflict between private interest and the collectivity. Elite actors with significant liquid capital would immediately begin hoarding grain to speculate on rising prices. The Persian traveler Nasir-i Khusrau recorded a telling anecdote: during a period of low water, the Caliph summoned a Coptic merchant to purchase grain, only for the merchant to boast that he possessed enough stored supply to feed all of Egypt for six years. While likely hyperbolic, it underscores the scale of private granaries.
By the time the actual harvest reached the market in May, speculators had often driven prices to unreachable heights. The crisis, therefore, was frequently an "anticipatory inflation" where the shortage of bread was a result of market manipulation rather than a caloric deficit in the silos.
Case Studies in Containment: The Eras of al-Hakim and al-Zahir
In the early 11th century, the Fatimid state demonstrated that a robust administration could mitigate even severe hydrological failures. During the reigns of al-Hakim and al-Zahir, several low-Nile events were successfully managed through aggressive state intervention.
Crisis Management Strategy,Implementation and Context
Market Seizures,"Seizing over 150 private granaries and selling the contents to millers at fixed, state-mandated prices."
Monopolization,"Under al-Zahir, the state ""usurped the fiscal prerogative"" by commandeering grain shipments directly from ports to the palace to prevent middleman speculation."
Fiscal Relief,Suspending all customs and port duties on grain and rice arriving at Cairo to incentivize imports.
Punitive Regulation,"Rounding up and beating bakers, millers, and grain brokers found to be price-gouging or adulterating flour."
Austerity,"Cancelling lavish court rituals, such as the Feast of al-Ghadir, to conserve the treasury and avoid provocative displays of wealth."
Hydraulic Diplomacy:  A fascinating testament to the state’s sophisticated understanding of the river is the account of al-Hakim sending the Patriarch to Ethiopia. Rooted in the belief that the Ethiopians had diverted the river’s course, this mission illustrates how the Fatimids viewed Nile hydraulics as a politicized, trans-regional issue.
Despite these measures, the human cost remained grim. In 415/1024, Caliph al-Zahir observed corpses littering the streets after the Epiphany celebrations. He ordered their burial at state expense, acknowledging that even an efficient state could only cushion, not eliminate, the suffering of the destitute.
The Hinge of Fate: From Bureaucracy to Chaos
The administrative stability of the early 11th century collapsed following the assassination of the  wazir  al-Yazuri. This event served as the "hinge of fate," transitioning the caliphate from an era of strong central bureaucrats to one of fractured military rule. The subsequent disarray was total: in the 16 years following al-Yazuri, there were no fewer than 54  wazir  appointments.
This revolving door of leadership rendered the central government incapable of coordinating irrigation or providing  taqawi . External pressures exacerbated the internal rot. Most notably, a grain agreement with the Byzantine Empress Theodora failed when Caliph al-Mustansir refused to sign a requested defense pact. By prioritizing political autonomy over food security, the Caliphate lost a vital grain route precisely when it was most needed.
Al-Shidda al-ʿUzma: The Greatest Calamity (1062–1073)
The period known as  al-Shidda al-ʿUzma  was a "perfect storm" where administrative paralysis met interfactional warfare between Ottoman and Black troops. Contrary to popular myth, which blames a relentless seven-year drought, hydrological data confirms that the river often provided sufficient water.
Table 4.1: Nile Levels During the Era of Crisis (in Cubits)
Year (AH/AD),Nile Level,Context of the Collapse
446/1054,17.40,High flood; managed effectively by al-Yazuri.
451/1059,15.23,Low flood; signals the start of serious instability.
454/1062,17.16,"The ""Shidda"" begins despite a high flood."
457/1065,16.10,"Sufficient water, but factional war paralyzes farming."
460/1067,15.60,Natural low flood exacerbates the existing war.
462/1070,17.30,Excellent flood; famine persists due to lack of seed.
465/1073,16.30,Sufficient water; the eve of Badr al-Gamali's arrival.
The famine was driven by the total breakdown of the agrarian system. Peasants, terrified by marauding soldier factions, fled their lands. The historian Maqrizi provides a harrowing account of the result: the consumption of cats and dogs, and eventually, the descent into cannibalism.
The destitution reached the throne itself. Caliph al-Mustansir was reduced to relying on the charity of a pious lady for his daily bread. Most tragically, as the royal family attempted to flee to Syria, several of the Caliph’s wives and daughters fell at the gates of Cairo and died of starvation before they could escape the city.
Restoration: Badr al-Gamali and the New Order
The "Greatest Calamity" ended not because the Nile changed its behavior, but because the state regained its monopoly on force. In 466/1073, al-Mustansir summoned Badr al-Gamali, the military governor of Syria. Arriving with his Armenian troops, Badr restored order through "decisive and tough" measures, executing the corrupt officials and feuding warlords who had feasted on the country’s remains.
Taking the title  amir al-juyush  (commander-in-chief), Badr’s restoration was built on pragmatic reforms:
1. Tax Relief:  He granted farmers a three-year tax moratorium to allow the agrarian sector to reset.
2. Infrastructure Rebirth:  He focused the state's remaining specie on restoring the canals and dykes that had been neglected for a decade.
3. Economic Results:  Agricultural revenues soon surpassed pre-crisis levels, signaling the birth of a new age of military-led governance.
Synthesis: The Lessons of the Calamity
Al-Shidda al-ʿUzma  serves as a stark historical lesson: the relationship between a people and their environment is mediated entirely by the quality of the state. The "Greatest Calamity" was the manifestation of a collapse in centralized control. When the state failed to coordinate the river’s "gift," provide  taqawi , and control speculation, the social contract was severed.
Hierarchy of Crisis Factors:
1. Administrative Breakdown:  The primary driver; loss of coordination and seed supply.
2. Internal War:  Factional fighting that displaced the peasantry and bankrupted the treasury.
3. Hydrological Fluctuation:  The secondary spark that ignited pre-existing structural decay.
Glossary of Terms:
* Kharaj:  The principal land tax, the lifeblood of the Fatimid fiscal system.
* Taqwiya / Taqawi:  The "reinforcement" of the peasantry through the provision of high-quality seed corn.
* Shidda:  A period of intense hardship, specifically a famine induced by both natural and human factors.
* Wafa’ al-Nil:  The state celebration marking the Nile reaching the optimal level of 16 cubits.
Final Reflection:
"The lands remained uncultivated and fear prevailed... Famine spread because of want of provisions... Conditions worsened to the degree that people ate each other." —  Maqrizi
