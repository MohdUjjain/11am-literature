# Justice from the Imām: A 900-Year-Old Legal Mystery from the Cairo Genizah

## 1. Introduction: The 241 Dinars of Sitt al-Ḥasab

Across the distance of nine centuries, the physical reality of **Michaelides (charta) A. 169** remains startlingly intimate. To hold this 46.1 cm scroll of medieval paper is to feel the weight of a 12th-century crisis. The script is a rapid, professional cursiveness where the vertical extensions of the letters are strategically reduced—a hallmark of an era where administrative speed met legal precision. The document begins with an indented *basmala*, a visual breath before the plunge into the high drama of the Fāṭimid state. This is not merely an archival relic; it is a physical echo of a desperate appeal made during the reign of the Caliph al-Āmir bi-ʾAḥkām illāh (A.D. 1101–1130).

**The Thesis** This petition is a sophisticated window into the Fāṭimid administrative apparatus. It demonstrates a society where the *mazālim* (wrongs) courts served as a mechanism for social restoration, allowing even a commoner—identified here metonymically through the humble status of *al-mamlūka* (the slave/servant)—to bypass local bureaucracy and invoke the absolute authority of the Imām-Caliph to resolve an inheritance debt of staggering proportions.

**The Roadmap**

- **The Archive:** Tracing the provenance from the Michaelides Collection to its Cairo Genizah roots.
- **The Social Conflict:** A profile of the petitioner and the noble debtor, the *šarīfa* Sitt al-Ḥasab.
- **The Judicial Apparatus:** The role of the *tawqīʿ* (rescript) and the authority of the *mazālim* courts.
- **The Diplomatics of Power:** Decoding the rigid chancery formulas and Middle Arabic orthography.
- **The Final Recovery:** The process of *waḍʿ al-yad* (seizure) and the pursuit of a "new life."

## 2. The Source Context: From the Genizah to Cambridge

The document is a centerpiece of the Michaelides Collection, formerly the private cache of G. A. Michaelides and now a treasure of the Cambridge University Library. While the collection is a diverse tapestry of Arabic papyri and paper spanning centuries, this specific petition (*qiṣṣa*) shares a profound cultural and legal DNA with the Cairo Genizah. As scholar Geoffrey Khan observes, such petitions represent the "front end" of the legal process—they are the cries for justice that necessitated a direct appeal to the sovereign.

| Physical Profile of the Document | Details |
|---|---|
| Identifier | Michaelides (charta) A. 169 |
| Material | Medieval Paper |
| Dimensions | 46.1 cm x 17.3 cm |
| Script Style | Cursive, reduced vertical extensions |
| Era | Fāṭimid (Reign of al-Āmir, 1101–1130 A.D.) |
| Diplomatic Form | *Qiṣṣa* (Petition) with indented *basmala* |

## 3. The Social Drama: A Tale of Two Women

The document preserves a collision between two very different social worlds. The anonymous petitioner, referring to herself throughout as *al-mamlūka*, stands in stark contrast to the deceased debtor, the *šarīfa* Ṭāhira, known as Sitt al-Ḥasab.

**Terminology: The Šarīf and the Conjoined Construct** In the Fāṭimid hierarchy, the title *šarīf* was reserved for the sacred lineage of al-Ḥasan and al-Ḥusayn. Sitt al-Ḥasab’s status was reinforced by her father’s title: "Guarantor of the Caliphate and its Pride." In the technical language of Fāṭimid epigraphy, this is a "conjoined construct phrase"—a sophisticated linguistic structure (seen in other Genizah documents like T-S 12.470) that signaled the highest tier of the social elite.

**The Conflict** The debt in question was **241 dinars in cash**. To put this in perspective, medieval petitions often concerned far smaller sums; 241 dinars was an immense amount of capital, representing significant wealth or a life's savings. Under Islamic legal principles (cited in the *Tanbīh* of aš-Šīrāzī), death triggers the immediate maturation of all debts. The petitioner’s right to the estate was absolute, yet she faced a wall of probate inertia that only the Imām could breach.

## 4. The Mechanics of Power: The Mazālim and the Tawqīʿ

To bypass the standard judiciary, the petitioner sought a *tawqīʿ*—a caliphal rescript. This was the executive "stroke of the pen" that commanded a judge to act with the full weight of the *mazālim* court, an institution designed to right wrongs that fell outside the reach of the regular *qāḍī*.

**The Judicial Hierarchy** The petition names the judge **Nūr al-Mulk ʿUmdat al-ʾAḥkām** ("Light of the Kingdom, Stay of Judgments"). His grandiloquent title follows a strict 12th-century chancery pattern, reflecting the Fāṭimid practice of referring to high-ranking dignitaries by their honorifics rather than their personal names.

**The Flow of Administrative Authority:**

1. **Petitioner:** Submits the *qiṣṣa* (originally topped by a *tarjama*, or identifying name-tag).
2. **Caliph al-Āmir:** The "gracious presence" (*al-maqām al-karīm*) reviews the appeal.
3. **The Tawqīʿ:** An "exalted rescript" is issued, granting the request.
4. **Judge Nūr al-Mulk:** Receives the mandate to intervene.
5. **The Waḍʿ al-yad:** The judge performs a forcible seizure of the *mawjūd* (assets) to satisfy the debt.

## 5. Anatomy of a Petition: Decoding the Formulaic Language

Fāṭimid petitions were masterpieces of diplomatic formality, employing specific linguistic structures to emphasize the distance between the "slave" and the "Imām."

1. **Basmala:** The invocation, indented to mark the start of a royal appeal.
2. **Blessings:** Explicit prayers for al-Āmir and, crucially, for his **"pure sons"** (*wa-ʿalā abnāʾihi al-ṭāhirīn*), a formula that reinforces the Fāṭimid emphasis on their holy lineage.
3. **Submission:** The phrase *tuqabbil al-arḍ* (kisses the ground), a deferential formula strictly introduced during al-Āmir’s reign to replace earlier, less humble expressions.
4. **Narratio (The Report):** Beginning with *tunhī ʿilā* (reports to...), utilizing "all-embracing mercies" as a metonym for the Caliph himself.
5. **Petitio (The Request):** Beginning with *tadraʿ* (humbly beseeches), asking for the rescript to be issued.

| Chancery Formula | Michaelides A. 169 Usage | Arabic Terminology |
|---|---|---|
| The Report | "Reports to the mercies..." | *tunhī ʿilā* (تنهى الى) |
| The Request | "Humbly beseeches the mercies..." | *tadraʿ* (وتضرع) |
| Evidence | "Registered the legal proofs" | *athbatat al-ḥujaj* (اثبتت الحجج) |
| The Assets | "Seize the existing estate" | *mawjūd* (موجود) |
| The Goal | "A new life" | *ḥayāwa mujaddada* (حياوة مجددة) |
| The Closing | "The Hasbala" (God is sufficient) | *ḥasbu al-mamlūka Allāh* |

*Note on Orthography: The petitioner uses the term* ***ḥayāwa*** *(life), a hybrid Middle Arabic form that blends the ancient Qurʾanic spelling with Classical Arabic phonetics.*

## 6. The Legal Evidence: Hujaj and the Role of Notaries

The petitioner arrived at the *mazālim* court armed with *ḥujaj*—legal documents. These were likely *iqrārāt* (formal acknowledgments of debt) drafted by professional notaries and validated by *ʿudūl* (witnesses of certified honesty).

**The Personal Archive vs. The State Archive** A critical distinction in Fāṭimid diplomatics lies in the lack of a judge's *ʿalāma* (motto or certification) on this specific paper. Unlike the Mamlūk Ḥaram documents of Jerusalem, which were archived by the court, Michaelides A. 169 was the **petitioner’s personal copy**. It represents the beginning of the legal journey—the document the woman held in her hand as she waited for the Caliph's mercy. This explains its preservation in the Genizah context; it was a private record of a public plea.

## 7. Conclusion: "A New Life" and the Legacy of Justice

The petition concludes with a hauntingly beautiful request: that she might live a "**new life**" (*ḥayātan mujaddadatan*) through the Imām's beneficence. In the context of 241 dinars, this was no metaphor; the recovery of such a sum was the difference between destitution and dignity.

**Five Key Takeaways**

- **Direct Sovereign Access:** The *mazālim* system allowed individuals to bypass the standard judiciary and reach the Caliph.
- **The Weight of the 241 Dinars:** This massive sum explains the extraordinary step of a direct caliphal appeal.
- **Gender and the Law:** The document highlights the agency of women in medieval Egypt to manage significant financial disputes.
- **Chancery Evolution:** Formulas like "kissing the ground" and prayers for "pure sons" provide a precise chronological anchor to al-Āmir’s reign.
- **Immediate Liability:** The swift transition of debt from the living to the estate underscores the rigor of Fāṭimid probate law.

**Process Map: The Path to Restoration**

- **Iqrār:** Sitt al-Ḥasab acknowledges the 241-dinar debt before notaries.
- **Death:** The debtor passes; the debt becomes an immediate claim on the estate.
- **Registration:** The petitioner validates her *ḥujaj* (proofs) in the *majlis al-ḥukm* (court).
- **Petition:** Michaelides A. 169 is drafted and submitted to al-Āmir.
- **Execution:** A *tawqīʿ* is sought to trigger **waḍʿ al-yad**—the forcible seizure of assets by Judge Nūr al-Mulk.

The petition remains a profound testament to a medieval culture of documentation, preserved in the Michaelides Collection as a timeless cry for justice. Through it, we see the Fāṭimid state not just as a distant hierarchy, but as a living system where a single sheet of paper could promise a new life.
