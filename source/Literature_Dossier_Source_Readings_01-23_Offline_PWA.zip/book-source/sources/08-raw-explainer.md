The Lifeline of the Caliphate: The Fatimid Transformation of the Red Sea (969–1171)
1. Introduction: The Internal Sea of Egypt
In the 1030s, a high-ranking Fatimid administrator named al-Qudā‘ī recorded a striking geographical claim in his surveys:  "The sea of al-Qulzum the Red Sea stands within the territory of Egypt. It has this territory on its West, its East and on its North."  This was more than a cartographic observation; it was a bold declaration of Ismaili sovereignty over a maritime corridor that linked the Mediterranean world to the riches of the Indian Ocean.
As maritime historians, we must grapple with a central intellectual tension: Was this Fatimid dominance the result of a deliberate, grand geopolitical strategy, or was it merely the "invisible hand of the market" guiding the dynasty’s fortunes?
The Strategic Pivot of Fatimid Power  The evolution of Fatimid policy in the Red Sea reveals a dramatic shift between two distinct eras. From  969 to 1073 , the Red Sea served as a theater for  Ideological Expansion , where the dynasty sought religious legitimacy and the eventual overthrow of the Abbasid Caliphate in Baghdad. However, following the existential crises of the 1060s and the rising shadow of the Seljuks and Crusaders, the policy transformed into one of  Pragmatic Realpolitik (1073–1171) . In this second phase, the Red Sea became the primary economic artery of Egypt, providing the customs revenue and strategic raw materials essential for the caliphate’s very survival.
Our Intellectual Journey:
* The Vanguard of the  Da‘wa  :  How religious missions paved the way for political influence.
* The Great Crisis:  The collapse of the "Baghdad Dream" and the administrative revolution of Badr al-Jamālī.
* The Strategic Pivot:  The rise of southern ports and the integration of global Jewish merchant networks.
* Military Hegemony:  The deployment of the Red Sea flotilla to secure the spice routes.
* The Kārimī Networks:  The formalization of seasonal, large-tonnage convoys.
2. The Era of Ideology (969–1073): The Quest for Muslim Leadership
During their first century of Egyptian rule, the Fatimids viewed the Red Sea through the lens of the  da‘wa  (Ismaili predication). Control of this maritime space was a tool for political legitimacy, aimed squarely at their Sunni rivals in Iraq.
The Hijaz and the Holy Cities  The Fatimids prioritized control over Mecca and Medina above all else. Dominance over the Hijaz allowed the Fatimid Imam to be named in the  khuṭba  (Friday prayer), the ultimate symbol of leadership in the Muslim world. This followed the traditional geopolitical adage that the  "Hijaz has always been under the control of Egypt because it is the source of its supply."  By ensuring the flow of grain and provisions from Egypt, the Fatimids bound the Holy Cities to their cause.
The Yemen Connection  In the 1040s, the rise of ‘Alī al-Sulayḥī in Yemen established a powerful pro-Fatimid emirate that secured the southern reaches of the Red Sea. The influence of the  da‘wa  was not limited to the coast; it extended into remote regions like Multan in the Sind (modern Pakistan) and Oman, creating a network of loyalists that stretched across the Indian Ocean rim.
Trade as an Alibi  Historical evidence suggests that during this era, trade often served as a "mise-en-scène" for religious propagation. Missionaries frequently took the "appearance of traders" to move freely across borders without alerting the Abbasid police. In this phase, commerce was often the cover, not the primary objective.
Objective Category,Primary Objective: Ideology,Secondary Objective: Trade
Primary Goal,Subjugation of Abbasid Iraq; legitimacy in the Hijaz.,Provisioning the Holy Cities; missionary travel.
Mechanism,The  da‘wa  and religious predication.,"Trade as a ""mise-en-scène"" or cover for  dā‘īs ."
Key Regions,"Mecca, Medina, Yemen, and Multan (Sind).",Port of al-Qulzum (Suez).
3. The Turning Point: The Great Crisis and the Rise of Badr al-Jamālī
The mid-11th century brought a series of catastrophic shocks. The "Baghdad Dream"—the hope of a universal Ismaili Caliphate—effectively vanished in  1058–1059  when the general  al-Basāsīrī , acting in the Fatimid name, briefly took Baghdad only to be defeated shortly thereafter. By the 1060s, Egypt was engulfed in a brutal civil war and famine, while the Seljuk Turks advanced into Syria.
Badr al-Jamālī’s Reforms  In 1073, the arrival of the Armenian general Badr al-Jamālī marked a fundamental shift toward pragmatism. He consolidated power as the military vizier, bringing the  da‘wa  organization under his own administrative council ( majlis ). The mission was no longer a purely religious endeavor; it became a tool of the state. Badr’s realpolitik was absolute; he even forced the Coptic Patriarch to relocate to Fustat, utilizing the Church’s hierarchy to guarantee regular commercial relations and diplomatic stability with Nubia and Abyssinia.
The Survival Instinct  Facing the Seljuks and, later, the Crusaders (the "Franks"), the Fatimids required a professional military and a powerful fleet. To fund these, Egypt needed the customs revenue from the Red Sea. Furthermore, the Red Sea became the only reliable route for importing wood and iron—strategic materials required to maintain a navy capable of resisting the Frankish threat in the Mediterranean.
4. The Strategic Pivot: Aden, Aydhāb, and the Merchant Networks
As the state's focus shifted from religion to revenue, the geography of the Red Sea was transformed to accommodate larger merchant vessels.
The Shift in Ports  The northern port of al-Qulzum (Suez) declined as the southern port of Aydhāb rose. This transition was driven by the treacherous winds and reefs of the northern Red Sea, which made the long sail to Suez dangerous for the heavier ships of the era. Aydhāb, closer to the Arabian and African markets, became the primary gateway for goods from Abyssinia, Zanzibar, and Yemen.
The Zuray‘ids of Aden  To secure the "lock of the Red Sea," the Fatimids granted the title of  dā‘ī  to the Zuray‘id rulers of Aden. This was a calculated diplomatic move to ensure the southern entrance to the sea remained under pro-Fatimid influence, even as the original religious fervor of the  da‘wa  began to fade.
The Jewish Trade Nexus  The Fatimids astutely utilized the local Jewish merchant community to facilitate global trade. By encouraging the relocation of the Palestinian Gaonate to Cairo, the Fatimids gained direct influence over the  Nagīd  (chief of the Jews). A key figure was  Maḍmūn b. Ḥasan b. Bundār  in Aden. He was a titan of commerce: a shipowner, the  wakīl al-tujjār  (representative of merchants), and the  nāẓir  (supervisor) of the port of Aden. Maḍmūn cemented these geopolitical ties through a matrimonial alliance with Abū Zikrī Kohen Judah b. Joseph, a prominent merchant representative in Fustat, effectively weaving the markets of India into the social fabric of the Fatimid capital.
5. Military Intervention and the Red Sea Flotilla
For the first time, the Fatimids moved from passive oversight to direct military intervention. The "Maritime Historian" notes a shift from the coastal  jalbas  (small dhows) to a specialized naval presence.
The First Fleet: 1118  In 1118, the vizier al-Afḍal faced a grueling choice. While the Crusaders threatened the Mediterranean heartland, he diverted precious resources to the south. In response to pirate raids on Aydhāb by the Emir of Mecca, he dispatched five  ḥarrāriq —highly specialized fire-launcher vessels—to the Red Sea. This was a cinematic moment of military resolve: the deployment of elite "fire-ships" to secure the economic lifeline of the empire.
Expeditionary Forces  Despite the Frankish threat, the Fatimids sent elite forces of archers and cavaliers to Yemen under commanders like Ibn Najīb al-Dawla and Ibn al-Khayyāṭ. Their mission was to stabilize pro-Fatimid regimes and suppress any internal rebellions that threatened the commercial traffic.
The Dahlak Archipelago  The Dahlak islands, often described as a "pirate nest," were a critical stopover. Tombstones found in the archipelago suggest the presence of a local dynasty linked to the  Seljuk Turks , explaining why the Fatimids felt compelled to apply military pressure and diplomatic negotiation to ensure that their  marākib al-kabīr  (large vessels) could pass without harassment.
6. The Rise of the Kārimī: Convoys and Global Spices
By the 12th century, the Red Sea trade had evolved into the "Kārim" system, a highly organized maritime operation that redefined global commerce.
Defining the Kārim  As Eric Vallet’s research clarifies, the  Kārim  was not a specific social class, but a  navigation season  occurring from June to November. This system favored the use of  "large vessels" (  marākib al-kabīr  )  over the smaller coastal  "jalbas."  These larger ships used more direct routes between Aden, Dahlak, Suwākin, and Aydhāb, often sailing in convoys protected by the Fatimid navy.
The Logic of Strategic Exchange  The arrival of European merchants—particularly Italians from Genoa and Venice—in Alexandria changed the economic calculus. While they sought Egyptian flax, they were increasingly hungry for Indian spices, silk, and incense. The Fatimids leveraged this demand through a brilliant tax system: European merchants were granted tax exemptions on Red Sea products if they imported strategic materials like wood and iron, which were then used to build the very ships that defended Egypt.
Characteristics of the Kārim System:
1. Seasonal Convoys:  Navigation synchronized with the June–November winds.
2. Large Tonnage Vessels:  A transition from  jalbas  to  marākib al-kabīr .
3. Naval Protection:  Merchant vessels shielded by the Fatimid  ḥarrāriq  flotilla.
4. Direct Routes:  Focused on major hubs like Aden, Dahlak, and Aydhāb.
7. Conclusion: The Legacy of a Maritime Caliphate
The transformation of Fatimid policy in the Red Sea is a testament to the dynasty's adaptability. What began as a frontier for religious expansion ended as the prerequisite for state survival. Without the customs revenue and the strategic materials (wood and iron) secured through this maritime corridor, the Fatimid Caliphate could not have sustained its two-century resistance against the Crusader states.
Timeline of the Fatimid Red Sea
* 969:  Fatimid arrival in Egypt; the Red Sea becomes an ideological frontier.
* 1058–1059:  al-Basāsīrī’s failed attempt on Baghdad; the "imperialist dream" begins to fade.
* 1073:  Badr al-Jamālī assumes power; the shift to pragmatism and Realpolitik.
* 1118:  Deployment of the first Fatimid Red Sea fleet of  ḥarrāriq .
* 1171:  End of the Fatimid Dynasty.
Technical Lexicon
* Da‘wa:  The Ismaili religious mission and predication.
* Dā‘ī:  A high-ranking religious official and missionary.
* Nagīd:  The head of the Jewish community in Egypt and Yemen.
* Kārim:  The seasonal navigation system and merchant network of the Red Sea.
* Ḥarrāriq:  Naval vessels equipped with specialized fire-launchers.
* Marākib al-kabīr:  Large-tonnage vessels used in the Kārim trade, as opposed to coastal  jalbas .
Final Takeaway  The strategic importance of this sea is best summarized by the stark reality of the 12th century:  "The men in charge of Egypt knew that if the Red Sea trade stopped, Egypt could not resist to the Crusaders only with its own resources."  The Red Sea was not just a territory; it was the pulse of the Caliphate.
