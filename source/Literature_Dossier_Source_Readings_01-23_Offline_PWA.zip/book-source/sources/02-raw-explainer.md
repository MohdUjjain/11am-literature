### The Sword and the Pen: Deconstructing the Fatimid Wazirate’s Radical Transformation

##### The Crisis at the Heart of the Caliphate

In the depth of winter in 466/1074, a fleet of one hundred ships executed an unprecedented crossing from Acre to Damietta. Aboard this flotilla was Badr al-Jamālī, the Armenian  *mamlūk*  and military commander of Fatimid Syria, summoned in absolute secrecy by the Imam-Caliph al-Mustanṣir. The Fatimid state was then in the throes of a terminal decline, besieged by famine, fiscal collapse, and internal anarchy. Badr’s arrival was not merely a tactical intervention; it signaled a profound metamorphosis of the Islamic administrative state.

The central intellectual tension of this era lies in the displacement of the  *arbāb al-aqlām*  (Lords of the Pen) by the  *arbāb al-suyūf*  (Lords of the Sword). How did a frontier military man, far removed from the clerical and scholarly elite of Cairo, become the architect of a new governmental form? The advent of Badr al-Jamālī represents a unique institutional pivot: the birth of the "military wazīr." During this period, the formal title of  *wazīr*  was strategically suppressed in favor of  *amīr al-juyūsh*  (Commander of the Armed Forces), yet the functional power of the office was expanded to an absolute degree previously unknown in the caliphate.

**Roadmap for the Inquisitive**

- **The Classical Archetype:**  An analysis of the "Joseph" model of bureaucratic governance and the Caliphs’ early preference for direct management.
- **The Great Disruption:**  Narrating Badr al-Jamālī’s ruthless consolidation of power and his comprehensive military pacification of Egypt.
- **The Linguistic Mystery:**  Investigating the disappearance of the  *wazīr*  title and the "Sultan Paradox."
- **Evidence in the Shadows:**  Utilizing  *ṭirāz*  fabrics and caliphal signatures ( *tawqīʿ* ) to reveal the hidden continuity of the wazirate.
- **The Evolutionary Chain:**  Mapping the institutional lineage from the Syrian militias to the final wazirate of Saladin.

##### The Classical Archetype: The "Wazīr of the Pen"

Prior to the military revolution, the Fatimid chancery distinguished between  *wizāra*  (an office of high rank and substantial independence) and  *wasāṭa*  (a more malleable "intermediary" role). For much of the early dynasty, the Imam-Caliphs preferred the  *wasāṭa*  or direct management; indeed, after the death of the first great wazīr, Yaʿqūb ibn Killis, in 380 AH, the Caliphs appointed no wazīrs for the next thirty-eight years. This gap underscores a deliberate effort by the Imam-Caliphs to keep the administration "weak and malleable."

When the office of the wazirate was employed, it was grounded in specific Quranic and prophetic precedents:

- **The Moses/Aaron Model:**  Representing prophetic assistance and lineage. The Fatimid chancery manuals, such as the  *Mawādd al-bayān* , explicitly cited ʿAlī b. Abī Ṭālib as the "most perfect of wazīrs" ( *akmal al-wuzarāʾ* ), framing the office as a sacred support to the Imam.
- **The Joseph Model:**  A model of fiscal and resource management. The  *sijill*  (decree) of al-Jarjarāʾī famously quotes Joseph’s plea to Pharaoh: "Put me in charge of the storehouses of the land, for I am a guardian with great knowledge."

The Bureaucratic Ideal: Key Figures of the Pen,,

Figure,Year of Appointment,Role & Background

Yaʿqūb ibn Killis,367/977,Expert in finance and scholarly administration; the first true Fatimid wazīr.

Al-Jarjarāʾī,418/1027,A career bureaucrat who rose through the clerical hierarchy of the  dīwān  system.

Al-Yāzūrī,450/1058,"Strictly a ""man of the pen""; his fall preceded the final collapse of civilian authority."

The decree elevating al-Jarjarāʾī provided the complete rationale for the office, grounding the wazīr’s authority in both administrative necessity and the divine precedent of the Prophet’s assistance.

##### The Great Disruption: Badr al-Jamālī’s Ascent

Badr al-Jamālī’s consolidation of authority was a departure from all civilian precedent. Known formally as  *Amīr al-Juyūsh Badr* , his power was rooted in his personal Syrian militia, the  *Juyūshiyya* . Upon entering Cairo, he invited the incumbent local elite to a "day of festivities," which culminated in a banquet where Badr staged the systematic execution of his guests. This bloody purge effectively liquidated all potential local opposition, allowing Badr to assume the powers of the wazīr in practice, if not in name.

Badr’s military accomplishments secured his absolute hold over the land:

1. **The Eastern Delta:**  He decimated the Lawāta tribesmen, restoring order to the agricultural heartland.
2. **Alexandria:**  He successfully captured the city from renegade forces.
3. **Upper Egypt:**  His troops annihilated a combined force of Arab Bedouin and Sudanese militia near Aswān.
4. **The Saljūq Defeat:**  In the most critical test of his tenure, Badr assembled 30,000 troops to destroy a Saljūq invasion force, permanently ending the Turkish threat to Egypt.

Despite this absolute control, Badr was never formally designated as  *wazīr* . He was not a bureaucrat, nor did he emerge from the scholarly class; he was a "military dictator" who held authority over all state affairs, described in his commission as everything "save the throne of the caliph."

##### The Linguistic Mystery: Why the Title Vanished

The historian al-Maqrīzī noted that from the arrival of Badr, the term  *wazīr*  "fell out of use" in formal designations, though the holders were still "regarded as wazīrs" informally. This period saw the birth of a "wazirate of delegation" ( *wizārat tafwīḍ* ), an unprecedented institution that granted Badr powers that the political theorist al-Māwardī (who died before this shift) could not have envisioned.

**Titular Tension: Formal Designation vs. Practical Authority**

- **The Rejection of "Wazīr":**  The title was traditionally linked to the  *arbāb al-aqlām* . By shunning it, Badr emphasized his military identity as  *Amīr al-Juyūsh* .
- **The Sultan Paradox:**  It is often asked why Badr did not simply take the title "Sultan." Crucially, the Imam-Caliph al-Mustanṣir had already granted the title "Sultan" to his vassal in Yemen, ʿAlī b. Muḥammad al-Ṣulayḥī. The refusal to grant it to Badr in Egypt was a deliberate choice to avoid comparison with the Saljūq Sultans, whose independence from the Abbasid Caliph was seen as a threat to the caliphal institution itself.
- **Functional Continuity:**  While shunning the name, Badr accepted all the  *accoutrements*  of the office, including the use of residences known as the  *dār al-wizāra*  and the formal "collar of the wazīr."

##### Evidence in the Shadows: Inscriptions and Signatures

The formal record of Badr’s era is marked by a curious absence. While twenty building inscriptions for Badr survive, none mention the  *wazirate* . This contrasts with the earlier era of Ibn Killis, where the title  *wazīr*  was prominently displayed on  *ṭirāz*  (official state fabrics)—the specific province of the wazīr, as opposed to coinage, which was the domain of the  *qāḍī* .

However, the "smoking gun" of the office's identity is found in the  *tawqīʿ* —the personal, hand-written signature or note of the Caliph. While the chancery-drafted  *sijills*  were formal and often avoided the title, the Caliph’s personal correspondence was more explicit.

**Caliphal Acknowledgement of the Wazirate**

In the  *tawqīʿ*  appended to the decree of Ṭalāʾiʿ b. Ruzzīk, the Caliph al-Fāʾiz explicitly addresses him:  **"For our wazīr... May God... never cease to favour the days he spends in our wazirate."**

Furthermore, in the  *tawqīʿ*  for Asad al-Dīn Shīrkūh, the Caliph acknowledges the unprecedented nature of the military delegation, stating:  **"No other wazīr has had a commission (**  ***ʿahd***  **) like this one given to you."**

This evidence confirms that within the palace, the  *amīr al-juyūsh*  was recognized as the functional and legal wazīr, regardless of the public titular suppression.

##### The Evolutionary Chain: From Badr to Saladin

The military wazirate became a hereditary and militia-based institution. Power was not held through bureaucratic tenure but through the command of personal militias, which evolved as follows:

- **Al-Juyūshiyya:**  The original force of Badr al-Jamālī.
- **Al-Afḍaliyya:**  The militia of Badr’s son, al-Afḍal.
- **Al-Asadiyya:**  The militia of Asad al-Dīn Shīrkūh, inherited by Saladin.

While Badr’s full decree is lost, we possess the formal decrees ( *sijills* ) for four specific "Lords of the Sword" who followed his model: Ṭalāʾiʿ b. Ruzzīk, Shāwar, Shīrkūh, and Saladin (Ṣalāḥ al-Dīn Yūsuf). Saladin’s own decree of appointment as  *amīr al-juyūsh*  explicitly referenced the precedent of Badr and al-Afḍal, completing the cycle of the military wazirate.

##### Synthesis and Significance

The Fatimid  *amīr al-juyūsh*  was a wazīr in function but a military dictator in form. This transformation was a "unique development in the history of the Islamic wazirate," bridging the gap between the classical caliphate and the eventual Mamlūk Sultanate. By inviting these "rescuers," the Fatimid Imam-Caliphs granted the dynasty a "new lease of life," even as they surrendered the actual management of the empire to the  *arbāb al-suyūf* .

**Visual Summary of the Institutional Shift**

- **Core Change:**  Decisive transition from "Lords of the Pen" (bureaucrats) to "Lords of the Sword" (military commanders).
- **Key Power:**  Authority over all state affairs, summarized as everything "save the throne of the caliph."
- **Historical Impact:**  A unique administrative evolution where the military commander became the "real holder of power," effectively serving as the Sultan of Egypt under a different name.

As al-Maqrīzī definitively concluded, the  *wazīr*  of the sword, from the era of Badr al-Jamālī until the very end, had "become the sultan of Egypt, the real holder of power."
