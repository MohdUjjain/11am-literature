The Language of the Other: Identity Politics and Abbasid Macaronics
1. Introduction: The Sound of the Borderland
Step back into the 9th-century linguistic crucible of Baghdad. In the bustling markets and the sophisticated courts of the Abbasid Caliphate, the air was not merely thick with spices; it vibrated with a sharp, intellectual cacophony. It was here that the  faṣīḥ  (pure) Arabic of the desert met the urban,  muḥdath  (modern) sensibilities of a cosmopolitan empire. In this environment, poets began to engage in "macaronics"—a term derived from the Italian  macarone , suggesting a "gross mixture." In our philological context, this refers to the deliberate, often subversive, insertion of Persian vocabulary into the rigid architecture of Arabic verse.
While traditionalists might have dismissed these as mere linguistic play or crude humor, scholar Lara Harb argues for a far more potent reality. These linguistic "gross mixtures" were deliberate markers of "the foreign Other." They were tools used to navigate, manipulate, and occasionally dismantle the shifting social hierarchies between Arab-Muslim and Persian-Zoroastrian identities.
The Intellectual Roadmap of Our Investigation:
* The Mechanics:  How poets forced Persian phonetics into the uncompromising structures of Arabic grammar.
* The Zoroastrian Ideal:  An analysis of Abū Nuwās’s virtuosic use of Middle Persian sacred terminology.
* The Parody of Pretense:  How macaronics served to gatekeep identity by mocking "wannabe" Khurāsānīs.
* The Political Blade:  The use of Persian as a weapon of political delegitimization in the Umayyad era.
* Imperial Legitimacy:  The martial narrative of the Caliphate, where the "Other" renounces their identity to enter the "Inside."
* The Great Inversion:  The 10th-century shift where the "Other" becomes the "Self," and old prejudices are turned into parody.
2. First Principles: The Mechanics of a Mixed Tongue
The integration of Persian into Arabic poetry was rarely a seamless blend; it was a sophisticated "departure from the known limits" ( khurūjihī ʿan ḥadd mā yuʿraf ). The 9th-century scholar Abū Bakr Ibn Dāwūd categorized such poems alongside palindromes and acrostics—viewing them as aesthetic eccentricities that pushed the boundaries of what literature could endure.
Poets utilized three primary methods of  Linguistic Anatomy :
* Phonetic Adaptation:  Forcing Persian sounds into Arabic meters by altering internal vowels—transforming words like  nōg-rōz  into the voweled  nawkarūz  to satisfy the rhythm.
* Grammatical Integration:  Subjugating Persian nouns to Arabic syntax, adding the definite article ( al- ) and specific case endings ( i/u/a ) to force the foreign into the familiar.
* Aesthetic Eccentricity:  Using these insertions as an intellectual puzzle, challenging the listener to recognize the "Other" within the "Self."
The "Loanword" Trap  A critical distinction must be made between common Arabicized loanwords—technical terms that had comfortably settled into the lexicon—and "deliberate macaronics." One must not confuse a established poetic  genre  like  khamriyyāt  (wine poetry) with the intentional use of a Persian term where a perfectly adequate Arabic equivalent existed. In the latter, the poet bypasses the Arabic word specifically to highlight the "foreignness" of the subject, creating a deliberate friction between the language of the conqueror and the culture of the conquered.
3. Case Study I: Abū Nuwās and the Zoroastrian Ideal
In his  mujūniyyāt  (licentious poems), Abū Nuwās often turned his gaze toward the "Other." In his famed address to the Zoroastrian youth Bihrūz, he does not merely flirt; he performs a virtuosic display of Middle Persian terminology, elevating the object of his desire through an "Oath List" that mimics the sacred structure of the Quran.
The Sacred Dissonance
Quranic/Arabic Oath Structure (Implicit),Abū Nuwās’s Middle Persian Oath Vocabulary
Wa-sh-shamsi  (By the Sun),Mihr  (The commanding sun)
Wa-l-qamari  (By the Moon),Māh  (The verity of the moon)
Wa-l-sama'i  (By the Heavens),Isfihr  (The heaven) /  Mīnū karuzmān  (The heavenly paradise)
Wa-l-kitābi  (By the Book),Bustāq  (The Avesta) /  Zaradhusht  (Zarathustra)
Oaths by Sacred Rites,Barsum  (Ritual twigs kept in glass bottles for purification)
Narrative Tension and Irony  Abū Nuwās populates the poem with high-culture markers: priests ( harābidh ), fire temples ( Asṭanūs ), and the ritual  barsum  twigs. Yet, this philological bridge fails. In the final verse, Bihrūz rejects the poet with the sharp sting of the word  difahrī  ("outcast" or "damned"). The irony is profound: Abū Nuwās uses the "Other's" sacred language to seek union, but the "Other" uses that same identity to insist on ritual purity, refusing to be "touched" by the Arab Muslim poet.
4. Case Study II: The "Mutakharsin" and the Parody of Pretense
In another poem, Abū Nuwās targets Ḥusayn, a  mutakharsin —a "fake Khurāsānī" pretending to be from the prestigious eastern frontier. Here, the vocabulary shifts from the "sacred" to the "mundane," employing "shallow markers" to expose the target's superficiality.
* Culinary Markers:  He mocks Ḥusayn’s obsession with  lakhsh  (a garlicky noodle dish) and  rakhfīn  (dried sour milk).
* Sartorial Markers:  He focuses on  darz-i bīrūn —clothing sewn with an external seam, a specific fashion of Khurāsān.
By using these basic, stereotypical markers, Abū Nuwās reinforces a gatekept hierarchy. The macaronics here serve as a satire of pretension; they suggest that identity is not something one can simply "wear" through the choice of a seam or the consumption of a noodle.
5. The Political Blade: Ibn Mufarrigh and the Umayyad Insult
In the 7th century, Persian was a weapon of political delegitimization. The Basran poet Ibn Mufarrigh utilized it to strike at the Ziyādid family, who were  mawlā  (clients) rising within a zealously Arab dynasty. During a public humiliation where he was paraded through Basra, Ibn Mufarrigh responded to the crowd’s Persian taunts with a sarcastic "double insult."
The Sarcastic Etymology  Claiming his diarrhea was merely "water and wine" ( āb ast, nabīdh ast ), he called the Ziyādid matriarch, Sumayya,  rūsapīd  (white-faced/honorable).
* The Linguistic Evolution:  This was a devastating sarcasm. In the linguistic environment of the time,  rūsapīd  was so frequently used ironically to mock questionable lineage that it evolved into the New Persian  rūspī , meaning "whore."
By employing Persian, Ibn Mufarrigh simultaneously mocked the Ziyādids' foreign origins and their lack of "Arab" honor, utilizing the language of the "Other" to strip them of their standing in the "Inside."
6. Imperial Legitimacy: al-ʿUmānī’s Panegyric for Hārūn al-Rashīd
Under Hārūn al-Rashīd, macaronics served the martial narrative of the state. The poet al-ʿUmānī composed an  urjūza  describing an enemy warrior falling into the "lion’s paw" (the Caliph).
The poet uses the word  kard  (neck) to mark the enemy’s body as inherently "Other" at the moment of the Caliph's strike. Crucially, the defeated foe swears never again to drink  āb-i sard  (cold water). In this context, the renunciation of Persian "water" symbolizes a rejection of the "outside" Persian identity. The enemy "heals his thirst" by switching sides, pledging a  bayʿa  (allegiance) that brings him into the "Inside" of Islam and the Arab Caliphate.
7. The Great Inversion: Ibn al-Ḥajjāj and the 10th-Century Shift
By the 10th century, the "Great Inversion" occurred. The Buyids—Persian rulers—now held the reins of the Arabic empire. The poet Ibn al-Ḥajjāj, master of the obscene parody ( sukhf ), used macaronics to flip the power dynamic.
In his poem on the capture of the fortress of Ardumusht, he compares the military conquest to the penetration of a Persian boy. He uses Persian numbers ( du va sih —two and three) and quoted speech ( bikhuft —he has gone to sleep) to describe the scene.
This was no longer an attack on Persian identity. Instead, it was a  parody of Arab prejudice . In this "post-colonial" era, the "Other" had become the "Self." By using the old tropes of the "penetrated Persian," Ibn al-Ḥajjāj mocked the outdatedness of those very hierarchies, signaling that the master of the scene—and the empire—was now the very "Other" the old poems sought to exclude.
8. Conclusion: A Legacy of Cosmopolitan Tension
Macaronic verse was the battlefield where the medieval soul was defined. These poems challenged the concept of  faṣāḥa  (linguistic purity), revealing an Arabic literary world that was fragmented, sophisticated, and deeply cosmopolitan. They prove that language was never just a medium; it was a marker of power.
The Evolution of the Persian Marker:
* Umayyad Era (7th C):  A political blade. Used as a "double insult" to delegitimize questionable lineage and foreign origins.
* Early Abbasid Era (8th-9th C):  A cultural mirror. Used for parody, seduction, and the "Sacred Dissonance" of religious distinction.
* Late Abbasid/Buyid Era (10th C):  A subversive inversion. Used to mock established Arab prejudices in a world where the "Other" had become the ruler.
Ultimately, the deliberateness of these macaronic verses offers us a window into a world where every phonetic adaptation and grammatical integration was a meaningful act of identity politics. It reminds us that in the medieval Near East, the most dangerous borders were not made of stone, but of syntax.
