The Architect of Inclusion: Power, Factionalism, and the Balancing Act of Buyid Shiraz
1. The "Invisible" Capital: Reclaiming the Political History of Shiraz
For decades, the historiography of Shiraz has been draped in the silken robes of the poet and the saint. A. J. Arberry, the eminent chronicler of Persian literature, famously asserted that Shiraz had "little to teach of the art of wise, just and stable government," suggesting its legacy was "exclusively spiritual and artistic." Yet, beneath this veneer of mystical tranquility lay a calcified reality: 11th-century Shiraz was a high-stakes arena of brutal political maneuvering, a capital where the survival of the state was negotiated daily in the shadow of the sword.
Central Thesis:  The relative stability of Shiraz under King Abu Kalijar was not a product of "wise or just" governance in the classical Hellenistic or Islamic tradition. Rather, it was a precarious and deliberate  inclusive balancing act . Stability was achieved not by the hegemony of one faction, but by the strategic integration of competing religious and ethnic rivals into the court—a model that leveraged intimacy as a tool of containment.
* The Rule of Abu Kalijar:  Navigating a fragmented Buyid world.
* The Three Power Brokers:  Profiles of the Da’i, the Qadi, and the Wazir.
* The Shiraz Model vs. Baghdad Chaos:  A comparative autopsy of 11th-century failure and success.
2. A Kingdom in Fragments: The World of Abu Kalijar
By the mid-11th century, the unified empire forged by 'Adud al-Dawla had dissolved into a "loose family confederation," a shattered mosaic of princely fiefdoms defined by internecine strife. Abu Kalijar (r. 415/1024 to 440AH/1048CE) emerged into this vacuum, forced to orchestrate order from chaos across Fars, Khuzistan, and eventually Iraq.
The primary driver of this instability was a virulent  Ethnic Rivalry  that served as the state's military backbone:
* The Daylamis:  Mountaineer infantry, traditionally the Buyid core, often leaning toward Shi'i or Ismaili sympathies.
* The Turks:  Elite cavalry, increasingly dominant, largely aligned with Sunni orthodoxy and the Abbasid Caliphate.
In the late Buyid period, these military factions functioned less as soldiers and more as political stakeholders; if a ruler failed to cater to their specific interests, the state did not merely falter—it evaporated.
3. The Da’i: Al-Mu’ayyad fi al-Din al-Shirazi and the Daylami Connection
To understand the weaponization of the pulpit, one must look to Al-Mu’ayyad fi al-Din al-Shirazi. An "Ismaili agent" representing the rival Fatimid Caliphate of Egypt, his currency was not gold, but spiritual leverage over the Daylami infantry. His autobiography, the  Mudhakkirat , reveals a man who understood that in the Buyid court, proximity to the King was the only relevant geography.
Al-Mu’ayyad calcified his position by convincing Abu Kalijar that his interests and the Daylamis' were one and the same. He famously declared:
"Verily the state is Daylami, the sultan is Daylami, and his entourage is entirely Daylami."
His power was so potent that it triggered a "Ramadan fast fracas" in 429/1038—a sectarian flashpoint where his very presence threatened to ignite a military riot. The resulting compromise was a masterclass in Buyid pragmatism: Al-Mu’ayyad "agreed" to an exile in the Daylami stronghold of Fasa, a strategic retreat that allowed the King to pacify the opposition without alienating the Daylami blade.
4. The Qadi: 'Abd Allah al-Fazari and the Sunni Establishment
Standing in stark opposition was the Sunni Qadi 'Abd Allah al-Fazari. While the Da'i represented the new ideological vanguard, the Qadi was the voice of the old guard—a family whose roots in Shiraz reached back to the Arab conquest.
The Qadi was a master of the  exclusivity of audience . His primary political weapon was the "trick": he orchestrated a private meeting with Abu Kalijar, carefully insulating the King from rival advisors to successfully advocate for Al-Mu’ayyad’s total expulsion. He didn't just want the Da'i gone; he issued a proclamation making the Ismaili's blood legal should he ever return. This was not mere piety; it was a move to neutralize a competitor for the King’s ear.
1. Turkish Cavalry:  The heavy-armored military counterweight to Daylami influence.
2. Mosque/Storyteller (Qussas) Networks:  Controlling the urban masses through the narrative power of the Friday sermon.
3. Merchant Class:  The financial elite who demanded Sunni stability for trade.
5. The Wazir: Bahram ibn Mafanna al-’Adil and the Art of the Mediator
If the Da’i and the Qadi were the poles of the state, the Wazir Bahram ibn Mafanna was its  linchpin . His role was not to be a partisan, but a political mediator who prevented any one group from becoming too powerful—or too desperate.
A "Counselor-General," Bahram was as adept at leading relief efforts in al-Ahwaz (421/1030) as he was at administrative reform. His "cultural competence" served as a bridge between factions; he curated a staggering intellectual legacy, maintaining libraries of 7,000 to 19,000 volumes, including  4,000 papers in the legendary script of the Banu Muqla .
Even his enemies were forced into a "chorus of praise." Al-Mu’ayyad, despite being frequently checked by the Wazir’s maneuvers, described him in his memoirs as being of  "consummate reason."  Bahram understood that a Wazir’s survival depended on his ability to appease both the Turkish cavalry and the Daylami infantry simultaneously.
6. The "Shiraz Model" vs. the "Baghdad Chaos"
The brilliance of the Shirazi system is best viewed through the dark lens of the "Baghdad Chaos." Under Jalal al-Dawla, the Buyid court in Baghdad collapsed because it failed the inclusive balancing act.
In Baghdad, Turkish troops predominated, and the lack of a Daylami counterweight led to a predatory environment. The city was a theater of horrors: Turkish soldiers threatened the ruler’s own harem, Arab and Kurdish tribesmen engaged in systematic looting, and the  'Ayyarun —para-military bandits—terrorized the markets.
The historian Roy Mottahedeh once described the ideal medieval ruler as a "distant arbiter." Abu Kalijar rejected this. He realized that in a fractured state,  intimacy was safety . By being "intimately involved" with every faction—Ismaili, Sunni, Turk, and Daylami—he made it impossible for any group to "opt out" of the state. If they were at the table, they weren't in the streets. He even dealt with the "Heretic" (al-Mariq), a former Ismaili courtier whose personal betrayal added a layer of poison to the court intrigue, yet even he was kept within the royal orbit to prevent him from inciting outside revolt.
7. Conclusion: The Precarious Success of the Idiosyncratic State
The interaction between the Qadi, the Wazir, and the Da'i reveals the true architecture of 11th-century Shiraz: a system where factional energy was channeled into court debate rather than street warfare. It was far too precarious to serve as a permanent blueprint for government, but it successfully shielded Shiraz from the fires that consumed Baghdad.
Visual Summary: The Power Structure of Shiraz
Name,Title,Military Base,Primary Interest
Al-Mu’ayyad,Da’i,Daylami Infantry,Ismaili Propagandism / Fatimid Ties
'Abd Allah al-Fazari,Qadi,Turkish Cavalry,Sunni Establishment / Legal Supremacy
Bahram ibn Mafanna,Wazir,General / Mediator,State Stability / Cultural Patronage
The Conceptual Hierarchy of the Balancing Act:
1. The King (Abu Kalijar):  The "Intimate Arbiter" who grants access to prevent revolt.
2. The Wazir:  The administrative filter who manages military stipends and civil grievances.
3. The Sectoral Representatives:  Factional leaders who trade military loyalty for court influence.
Final Takeaways:
* Inclusion as Strategy:  Stability was bought by inviting rivals into the inner circle, ensuring no group felt "snubbed" enough to resort to violence.
* Intimacy vs. Distance:  The Shiraz model proved that a ruler’s personal accessibility could be more effective than institutional strength.
* The Fragility of Peace:  This peace was a "personality-driven" construct; it relied on the individual skill of the Wazir and the King, leaving the state vulnerable to the eventual Seljuk tide.
Shiraz remains the city of poets, but we must remember that the silence of its gardens was bought with the noisy, messy, and brilliant inclusion of the court. The "spiritual" Shiraz of our imagination was only made possible by the "political" Shiraz that mastered the art of the impossible balance.
