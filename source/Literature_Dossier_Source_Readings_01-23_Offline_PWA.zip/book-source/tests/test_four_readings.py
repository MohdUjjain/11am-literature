#!/usr/bin/env python3
"""Source fidelity, all six semantic types, placed/recalled memory aids, and edition bounds."""
from pathlib import Path
from bs4 import BeautifulSoup
import sys,re,html,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import generate_initial_readings as g
import generate_readings_03_04 as g34

ROOT=Path(__file__).resolve().parents[1]
book=BeautifulSoup((ROOT/'output/book.html').read_text(encoding='utf8'),'html.parser')
sections=book.select('.chapter')
assert [int(x['data-chapter']) for x in sections][:4]==[1,2,3,4]
assert all(not c.select('.sidenote,.noted') for c in sections)
assert len(list((ROOT/'chapters').glob('*.html')))>=4
index=json.loads((ROOT/'course_index.json').read_text(encoding='utf8'))
assert index['readings']['19'] is None

def norm(s):
    return re.sub(r'\s+([),.:;])',r'\1',re.sub(r'([([])\s+',r'\1',re.sub(r'\s+',' ',html.unescape(s).replace('\xa0',' ')))).strip()

for n,info in g34.READINGS.items():
    ch=book.select_one(f'.chapter[data-chapter="{n}"]')
    assert ch is not None
    assert ch.select_one('.chapter-title-page h1').get_text(' ',strip=True)==index['readings'][f'{n:02d}']
    assert info['accent'] in ch['style']
    src=(ROOT/'sources'/info['source']).read_text(encoding='utf8')
    chunks=g34.extract_sections(g34.improve_md(src,n),n)
    assert len(ch.select('.leaf > .section'))==len(chunks)
    assert len(ch.select('.revision-zone .section'))==6
    for i,(title,block) in enumerate(chunks,1):
        section=ch.select_one(f'#s{n}-{i}')
        assert section is not None
        rendered_text=norm(section.select_one('.section-body').get_text(' ',strip=True))
        src_html=BeautifulSoup(g.md(block),'html.parser')
        for node in src_html.find_all(['p','li','td','th']):
            raw=norm(node.get_text(' ',strip=True))
            if len(raw)<16:continue
            assert raw in rendered_text, f'Reading {n} §{i}: source fragment missing: {raw[:140]}'
    for tag in ['definition','concept','examtip','mistake','memory','highyield']:
        assert ch.select_one('.leaf .callout--'+tag),f'{n} lacking {tag}'
    main_mems=[norm(m.get_text(' ',strip=True)) for m in ch.select('.leaf .callout--memory p')]
    revision_mems=[norm(m.get_text(' ',strip=True)) for m in ch.select('.revision-zone .callout--memory p')]
    assert len(main_mems)==5 and len(revision_mems)==5,(n,main_mems,revision_mems)
    for m in revision_mems:
        assert m in main_mems,(n,m)
    assert len(ch.select('.revision-zone .exam-question-grid .exam-q'))==6
    assert len(ch.select('.leaf table'))>=2
    assert len(ch.select('.revision-zone table'))>=2 if n==4 else True
    assert len(ch.select('.revision-zone table'))>=1
    assert len(ch.select('.revision-zone .revision-card'))==4
    print(f'PASS Reading {n}: {len(chunks)} full sections; 6 revision sections; 5 planted-recalled memory aids; all 6 callout types; original text retained')
print('PASS Editional integrity: foundational chapters 1–4 present, original chapter 1 and 2 unchanged in this build, 19 unknown')
