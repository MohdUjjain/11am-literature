#!/usr/bin/env python3
"""Structure/source fidelity QA for the November 2026 two-reading dossier."""
from pathlib import Path
import json,re,sys,html
from bs4 import BeautifulSoup
import mistune

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import generate_initial_readings as g
md=mistune.create_markdown(plugins=['table'])


def norm(s):
    return re.sub(r'\s+([),.:;])',r'\1',re.sub(r'([([])\s+',r'\1',re.sub(r'\s+',' ',html.unescape(s).replace('\xa0',' ')))).strip()

index=json.loads((ROOT/'course_index.json').read_text(encoding='utf8'))
assert index['planned_reading_count']==26
assert len(index['readings'])==26
assert index['readings']['19'] is None
assert len(list((ROOT/'chapters').glob('*.html')))>=2
assembled=(ROOT/'output'/'book.html').read_text(encoding='utf8')
book=BeautifulSoup(assembled,'html.parser')
assert len(book.select('.chapter'))>=2
assert not book.select('.sidenote,.noted')
assert [s.get('data-chapter') for s in book.select('.chapter')][:2]==['1','2']
assert len(book.select('.chapter[data-chapter="1"]')) == 1

for n,info in g.READINGS.items():
    ch=book.select_one(f'.chapter[data-chapter="{n}"]')
    assert ch and ch.select_one('.chapter-title-page h1').get_text()==info['title']
    assert len(ch.select('.leaf > .section'))==7
    assert len(ch.select('.revision-zone .section'))==6
    assert len(ch.select('.revision-zone .section h2'))==6
    original=(ROOT/'sources'/info['source']).read_text(encoding='utf8')
    content=g.improve_md(original,n)
    sec=g.extract_sections(content,n)
    assert len(sec)==7
    for i,(title,chunk) in enumerate(sec,1):
        chapter_section=ch.select_one(f'#s{n}-{i}')
        assert chapter_section and chapter_section.select_one('h2').get_text()==title
        body_text=norm(chapter_section.select_one('.section-body').get_text(' ',strip=True))
        source=BeautifulSoup(md(chunk),'html.parser')
        original_block=source.get_text(' ',strip=True)
        # Every original individual paragraph/list item/table cell is retained
        # without a full-content rewrite. Notes and diagrams may be interspersed.
        for node in source.find_all(['p','li','td','th']):
            raw=norm(node.get_text(' ',strip=True))
            if len(raw)<16:continue
            assert raw in body_text, f'Original source fragment missing: reading {n} §{i}: {raw[:100]}'
        for t in ('definition','concept','examtip','mistake','memory','highyield'):
            assert ch.select_one('.leaf .callout--'+t),f'Missing semantic {t} callout: {n}'
    memories=[norm(x.get_text(' ',strip=True)) for x in ch.select('.revision-zone .callout--memory p')]
    main_memory=[norm(x.get_text(' ',strip=True)) for x in ch.select('.leaf .callout--memory p')]
    for mem in memories:
        assert any(mem in p for p in main_memory), f'Memory not placed in main text: {mem}'
    assert len(memories)==(3 if n==1 else 5)
    assert ch.select_one('.revision-zone .revision-grid.exam-question-grid')
    assert len(ch.select('.revision-zone .exam-question-grid .exam-q'))>=6
    assert len(ch.select('.leaf table'))>=(2 if n==1 else 3)
    assert len(ch.select('.revision-zone table'))>=2
    print(f'PASS Chapter {n}: preserved source paragraphs/lists/cells, 7 sections, 6 revision parts, {len(memories)} in-text memory aids')
print('PASS Index: 26 planned slots, 19 intentionally unknown; foundational readings 1–2 intact')
