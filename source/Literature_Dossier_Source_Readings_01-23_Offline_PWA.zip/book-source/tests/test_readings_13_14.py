#!/usr/bin/env python3
"""Manual batch 13/14 integrity and exact-passage pagination smoke test."""
from pathlib import Path
from collections import Counter
import hashlib,json
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import fitz
ROOT=Path(__file__).resolve().parents[1]
M=json.loads((ROOT/'NEW_READINGS_13_14_MANIFEST.json').read_text(encoding='utf8'))
H=json.loads((ROOT/'PRE_13_14_HASHES.json').read_text(encoding='utf8'))
for rel,digest in H.items():
    assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest, f'previous file modified: {rel}'
source_stats={};total=0
TERMS={13:['Himmel','Liesel','Max','Hans','Rosa','Erik','Death','April','May','scissors','Molching','crossword','yellow hole','tightrope','Goebbels','jewels','brown'],
       14:['Basra','Ikhwān','Rasāʾil','Epistle 7','Epistle 8','Epistle 22','Epistle 52','potentiality','actuality','nāmūs','logos','ethos','pathos','animal','King of the Jinn','maqna','al-Fārābī','Muhammad','Universal Soul']}
for n in (13,14):
    raw=(ROOT/'sources'/f'{n:02d}-raw-explainer.txt').read_bytes()
    expected=M['source_sha256'][str(n)]
    assert hashlib.sha256(raw).hexdigest()==expected, f'source bytes mismatch {n}'
    doc=BeautifulSoup(next((ROOT/'chapters').glob(f'{n:02d}-*.html')).read_text(encoding='utf8'),'html.parser')
    assert int(doc.select_one('.chapter')['data-chapter'])==n
    sections=doc.select('.leaf > .section')
    assert len(sections)==(6 if n==13 else 7)
    assert [s['id'] for s in sections]==[f's{n}-{i}' for i in range(1,len(sections)+1)]
    assert len(doc.select('.revision-zone .section'))==6
    assert not doc.select('.leaf .prose .callout')
    notes=doc.select('.leaf .passage > aside .callout')
    expected_notes=20 if n==13 else 25
    assert len(notes)==expected_notes
    assert len({c['data-note-id'] for c in notes})==len(notes)
    assert {c['data-content-type'] for c in notes}=={'definition','concept','examtip','mistake','memory','highyield'}
    assert all(c.find_parent(class_='passage')['data-anchor'] in c['data-note-id'] for c in notes)
    mem=[x for x in notes if x['data-content-type']=='memory']
    assert len(mem)==len(doc.select('.revision-zone .callout--memory'))==(5 if n==13 else 6)
    assert len(doc.select('.leaf table'))==2
    fulltext=doc.get_text(' ',strip=True).casefold()
    missing=[term for term in TERMS[n] if term.casefold() not in fulltext]
    assert not missing,(n,'source topic(s) lost',missing)
    source_stats[n]={'sections':len(sections),'passages':len(doc.select('.leaf .passage')),'notes':len(notes),'note_types':dict(Counter(c['data-content-type'] for c in notes)),'tables':2,'memory_aids':len(mem),'source_bytes':len(raw)}
    total+=expected_notes
errors=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=browser.new_context(viewport={'width':1500,'height':950})
    pg=ctx.new_page()
    pg.on('pageerror',lambda e:errors.append(str(e)))
    pg.route('https://fonts.googleapis.com/**',lambda r:r.abort())
    pg.route('https://fonts.gstatic.com/**',lambda r:r.abort())
    pg.set_content((ROOT/'output/book.html').read_text(encoding='utf8'),wait_until='domcontentloaded')
    pg.locator('#range-spec').fill('13,14')
    pg.evaluate('window.DossierPrint.build()')
    diag=pg.evaluate('window.__dossierPrintDiagnostics')
    assert not diag.get('error') and not diag.get('overflows'),diag
    result=pg.evaluate('''() => {
       let pages=[...document.querySelectorAll('#print-root > .printed-page')];
       let cards=[...document.querySelectorAll('#print-root .side-note-card')];
       return {pages:pages.length, cards:cards.map(c=>{
         let pg=c.closest('.printed-page'),a=c.getAttribute('data-note-anchor');
         return {id:c.getAttribute('data-note-id'),chapter:pg?.getAttribute('data-print-chapter'),anchor:a,
                 match:!!pg?.querySelector('.page-main-column [data-anchor="'+a+'"]')};
       }),
       clipped:pages.some(p=>{let b=p.querySelector('.printed-body');return b&&b.scrollHeight>b.clientHeight+2;})};
    }''')
    assert len(result['cards'])==total
    assert len({x['id'] for x in result['cards']})==total
    assert all(x['match'] for x in result['cards']),[x for x in result['cards'] if not x['match']]
    assert not result['clipped']
    assert not errors,errors
    ctx.close()
    mob=browser.new_context(viewport={'width':390,'height':844})
    mp=mob.new_page()
    mp.route('https://fonts.googleapis.com/**',lambda r:r.abort())
    mp.route('https://fonts.gstatic.com/**',lambda r:r.abort())
    mp.set_content((ROOT/'output/book.html').read_text(encoding='utf8'),wait_until='domcontentloaded')
    screen=mp.evaluate('''() => ({view:document.documentElement.clientWidth,
                    scroll:document.documentElement.scrollWidth})''')
    assert screen['scroll']<=screen['view']+2,screen
    mob.close();browser.close()
# Recheck the complete volume without mutating any earlier chapter. The 01-12
# source has one inherited exact-anchor exception under offline fonts.
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=browser.new_context(viewport={'width':1500,'height':950})
    pg=ctx.new_page()
    pg.route('https://fonts.googleapis.com/**',lambda r:r.abort())
    pg.route('https://fonts.gstatic.com/**',lambda r:r.abort())
    pg.set_content((ROOT/'output/book.html').read_text(encoding='utf8'),wait_until='domcontentloaded')
    pg.evaluate('window.DossierPrint.build()')
    full_cards=pg.evaluate('''() => [...document.querySelectorAll('#print-root .side-note-card')].map(c=>{
       const p=c.closest('.printed-page'),a=c.getAttribute('data-note-anchor');
       return {id:c.getAttribute('data-note-id'),samePage:!!p?.querySelector('.page-main-column [data-anchor="'+a+'"]')};
    })''')
    assert len(full_cards)==254
    unexpected={x['id'] for x in full_cards if not x['samePage']} - {'s4-6-n2'}
    assert not unexpected,unexpected
    full_exceptions=[x['id'] for x in full_cards if not x['samePage']]
    browser.close()
PDF=ROOT.parent/'Complete_01-14_QA.pdf'
report={'result':'PASS','previous_01_12_hashes':len(H),'readings':source_stats,'new_sidebar_exact_alignments':total,
        'pair_composed_pages':result['pages'],'mobile':screen,'full_sidebars':len(full_cards),
        'full_exact_alignments':len(full_cards)-len(full_exceptions),'full_known_legacy_exceptions':full_exceptions,
        'javascript_errors':errors}
if PDF.exists():
    pdf=fitz.open(PDF)
    assert len(pdf)==146
    assert len(pdf.get_toc())==218
    assert sum(len(p.get_links()) for p in pdf)>=14
    assert all(abs(p.rect.width-960)<1.2 and abs(p.rect.height-540)<1.2 for p in pdf)
    assert pdf.xref_get_key(pdf.pdf_catalog(),'PageMode')==('name','/UseOutlines')
    report.update(full_pdf_pages=len(pdf),pdf_bookmarks=len(pdf.get_toc()),pdf_contents_links=sum(len(p.get_links()) for p in pdf))
else: report['full_pdf']='not bundled; run export_bookmarked.py before checking physical PDF'
(ROOT/'QA_READINGS_13_14_MACHINE.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps(report,indent=2,ensure_ascii=False))
