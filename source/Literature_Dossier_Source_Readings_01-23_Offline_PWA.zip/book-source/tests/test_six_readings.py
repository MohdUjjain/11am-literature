from pathlib import Path
from bs4 import BeautifulSoup
import re,csv,zipfile
R=Path(__file__).resolve().parents[1]
b=BeautifulSoup((R/'output/book.html').read_text(),'html.parser')
assert [int(c['data-chapter']) for c in b.select('.chapter')[:6]]==list(range(1,7))
z=zipfile.ZipFile(R.parents[1]/'upload/Literature_Dossier_Source_Readings_01-04.zip')
for name in z.namelist():
 if '/chapters/' in name or name.split('/')[-1] in ['styles.css','engine.js','head-template.html','cover.html']:
  assert (R/Path(name).relative_to('book-source')).read_bytes()==z.read(name),name
for n in [5,6]:
 c=b.select_one(f'#chapter-{n}');main=c.select_one('.leaf');plain=' '.join(main.get_text(' ',strip=True).split())
 for line in (R/'sources'/f'{n:02d}-raw-explainer.md').read_text().splitlines():
  line=line.strip()
  if not line:continue
  if ',' in line and (line.startswith(('Quranic/','Wa-','Oaths by','Crisis Management','Market Seizures,','Monopolization,','Fiscal Relief,','Punitive Regulation,','Austerity,','Year (AH/AD),')) or re.match(r'^\d{3}/\d{4},',line)):
   texts=next(csv.reader([line]))
  else:texts=[re.sub(r'^(?:\* |\d+\. )','',line)]
  for text in texts:assert ' '.join(text.split()) in plain,(n,text)
 assert len(main.select('.section'))==8
 assert len(c.select('.revision-zone .section'))==6
 for tag in ['definition','concept','examtip','mistake','memory','highyield']:assert main.select('.callout--'+tag)
 a=[x.get_text() for x in main.select('.callout--memory p')];d=[x.get_text() for x in c.select('.revision-zone .callout--memory p')]
 assert len(a)==5 and a==d
 assert len(c.select('.exam-q'))==6
 print('PASS',n,'all supplied source lines/cells retained; 8 main + 6 revision sections; 5 recalled memory aids; 6 callout types')
print('PASS four earlier chapters and shared design/engine byte-for-byte unchanged')
