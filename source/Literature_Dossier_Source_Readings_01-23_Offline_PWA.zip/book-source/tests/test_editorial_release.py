#!/usr/bin/env python3
"""Portable source integrity gate for the editorial edition; run `python tests/test_editorial_release.py`."""
from pathlib import Path
from collections import Counter
import json,zipfile
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1]
check=json.loads((ROOT/'EDITORIAL_CHECKPOINT.json').read_text())
base=ROOT/check['source_baseline']
assert base.is_file(),'Missing archive for comparison'
with zipfile.ZipFile(base) as z:
 for n in range(1,9):
  fn=next((ROOT/'chapters').glob(f'{n:02}*.html')).name
  new=BeautifulSoup((ROOT/'chapters'/fn).read_text(),'html.parser')
  old=BeautifulSoup(z.read('book-source/chapters/'+fn),'html.parser')
  assert [x['id'] for x in old.select('.leaf .section')]==[x['id'] for x in new.select('.leaf .section')],f'{n} main section IDs changed'
  for selector in ['.chapter-title-page','.revision-zone']:
   assert str(old.select_one(selector))==str(new.select_one(selector)),(n,selector)
  for selector in ['.leaf table','.leaf .process-strip','.leaf svg']:
   assert [str(x) for x in old.select(selector)]==[str(x) for x in new.select(selector)],(n,selector)
  def idmap(doc):
   cards=doc.select('.leaf .passage > aside [data-note-id]')
   return {x['data-note-id']:(x['data-content-type'],x.select_one('.tag').get_text(' ',strip=True)) for x in cards},len(cards)
  o,oc=idmap(old); c,cc=idmap(new)
  assert o==c and len(c)==oc==cc,(n,'note ID/type/label or duplicates')
  assert len(new.select('.revision-zone .section'))==6,n
  assert not new.select('.leaf .prose .callout'),n
  assert (ROOT/'sources'/f'{n:02}-raw-explainer.md').read_bytes()==z.read(f'book-source/sources/{n:02}-raw-explainer.md'),(n,'raw source changed')
  if n==1:assert (ROOT/'chapters'/fn).read_bytes()==z.read('book-source/chapters/'+fn),'Reading01 should remain exact'
 for n in ['styles.css','engine.js','build.py','export_bookmarked.py','head-template.html','cover.html','course_index.json','progress.json']:
  assert (ROOT/n).read_bytes()==z.read('book-source/'+n),f'Core publisher changed: {n}'
assert len(list((ROOT/'chapters').glob('*.html')))>=8
assert sum(len(BeautifulSoup(p.read_text(),'html.parser').select('.leaf .passage > aside [data-note-id]')) for p in (ROOT/'chapters').glob('[0-9][0-9]-*.html') if int(p.name[:2])<=8)==128
assert sum(len(BeautifulSoup(p.read_text(),'html.parser').select('.leaf table')) for p in (ROOT/'chapters').glob('[0-9][0-9]-*.html') if int(p.name[:2])<=8)==15
print('PASS 8 chapters, 128 notes, 15 tables, revision and opener DOM, raw source bytes, core publisher unchanged')
