#!/usr/bin/env python3
"""Chapter 11/12 release checks: source integrity, exact note ownership, responsive screen, PDF readback.
Requires playwright, bs4, pymupdf. Run from any cwd.
"""
from pathlib import Path
from collections import Counter
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
import fitz,json,zipfile,hashlib
ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/mnt/data/Literature_Dossier_Source_Readings_01-10_Editorial.zip')
HTML=ROOT/'output/book.html'
PDF=Path('/mnt/data/dossier_11_12/Complete_01_12.pdf')
ASSIGNED={11:21,12:21}
TYPES={'definition','concept','examtip','mistake','memory','highyield'}
BASEFILES=['styles.css','engine.js','build.py','export_bookmarked.py','head-template.html','cover.html','course_index.json']
results={}
with zipfile.ZipFile(BASE) as z:
    for path in BASEFILES:
        assert (ROOT/path).read_bytes()==z.read('book-source/'+path),f'Shared publisher mutated: {path}'
    for n in range(1,11):
        target=next((ROOT/'chapters').glob(f'{n:02}-*.html'))
        assert target.read_bytes()==z.read('book-source/chapters/'+target.name),f'Chapter {n} mutated'
        sp=next((ROOT/'sources').glob(f'{n:02}-raw-explainer.*'))
        assert sp.read_bytes()==z.read('book-source/sources/'+sp.name),f'Original source {n} mutated'
results['baseline_01_10']='exact bytes (all 10 chapters + sources + 7 publisher files)'

for n,need in ASSIGNED.items():
    source=BeautifulSoup(next((ROOT/'chapters').glob(f'{n:02}-*.html')).read_text(encoding='utf8'),'html.parser')
    chap=source.select_one('.chapter')
    assert chap and int(chap['data-chapter'])==n
    sections=source.select('.leaf > .section')
    assert len(sections)==8 and [s['id'] for s in sections]==[f's{n}-{i}' for i in range(1,9)]
    assert len(source.select('.revision-zone .section'))==6
    notes=source.select('.leaf > .section .passage > aside .callout')
    assert len(notes)==need,(n,len(notes))
    assert not source.select('.leaf .prose .callout')
    assert {c['data-content-type'] for c in notes}==TYPES
    ids=[x['data-note-id'] for x in notes]
    assert len(ids)==len(set(ids)),(n,'note id duplicate')
    assert all(x.find_parent(class_='passage')['data-anchor'] in x['data-note-id'] for x in notes)
    aids=[x for x in notes if x['data-content-type']=='memory']
    revision_aids=source.select('.revision-zone .callout--memory')
    assert len(aids)==len(revision_aids)==5,(n,len(aids),len(revision_aids))
    assert len(source.select('.leaf table'))>=1
    original=(ROOT/'sources'/f'{n:02}-raw-explainer.txt').read_text(encoding='utf-8-sig')
    assert len(original)>8500
    results[f'{n}_source']={'sections':8,'passages':len(source.select('.leaf .passage')),
       'notes':need,'note_types':dict(Counter(c['data-content-type'] for c in notes)),'intro_memory':5,'revision_memory':5,
       'tables':len(source.select('.leaf table')),'source_bytes':len(original.encode())}
for n,markers in {
 11:['Anderson','blood','Qiṣāṣ','diya','Ḥanafī','Mālikī','Shāfiʿī','Ḥanbalī','dalīl','poison','staff','Ẓāhirī','Zufar','Abū Yūsuf','flickering','conspiracy','ascendant'],
 12:['Geniza','malshinut','moserim','ENA NS 31.21','autonomy by default','autonomy by design','Jerusalem','15,000','6,000','3,000','Shelomo','Nahum','1052','1029','calque','Badr']
}.items():
    doc=BeautifulSoup(next((ROOT/'chapters').glob(f'{n:02}-*.html')).read_text(),'html.parser')
    text=doc.get_text(' ',strip=True).casefold()
    missing=[x for x in markers if x.casefold() not in text]
    assert not missing, (n,'missing topic coverage',missing)
results['topic_coverage']='17/17 specific Reading 11 markers; 16/16 Reading 12 markers'

errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':1500,'height':950})
    page=context.new_page()
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.route('https://fonts.googleapis.com/**',lambda r:r.abort())
    page.route('https://fonts.gstatic.com/**',lambda r:r.abort())
    page.set_content(HTML.read_text(encoding='utf8'),wait_until='domcontentloaded')
    page.locator('#range-spec').fill('11,12')
    page.evaluate('window.DossierPrint.build()')
    diag=page.evaluate('window.__dossierPrintDiagnostics')
    assert not diag.get('error') and not diag.get('overflows'),diag
    data=page.evaluate('''() => {
      const cards=[...document.querySelectorAll('#print-root .side-note-card')];
      const pages=[...document.querySelectorAll('#print-root > .printed-page')];
      return {
        composed:pages.length,
        cards:cards.map(c=>{
          const parent=c.closest('.printed-page'); const a=c.getAttribute('data-note-anchor');
          return {id:c.getAttribute('data-note-id'),anchor:a,chapter:parent?.getAttribute('data-print-chapter'),
            exact:!!parent?.querySelector('.page-main-column [data-anchor="'+a+'"]')};
        }),
        geometry:pages.map(p=>({w:p.getBoundingClientRect().width,h:p.getBoundingClientRect().height})),
        clipped:pages.some(p=>{const body=p.querySelector('.printed-body');return body && body.scrollHeight>body.clientHeight+2})
      }
    }''')
    assert len(data['cards'])==42 and len(set(c['id'] for c in data['cards']))==42
    assert all(c['exact'] for c in data['cards']),(list(c for c in data['cards'] if not c['exact']))
    assert not data['clipped']
    assert not errors,errors
    results['exact_page_alignment']={'notes':len(data['cards']),'aligned':sum(c['exact'] for c in data['cards']),'pages_composed':data['composed']}
    page.close()
    phone=context.new_page(viewport={'width':390,'height':844}) if False else None
    # New context is required to simulate phone rather than override the desktop.
    mcontext=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1)
    mobile=mcontext.new_page()
    mobile.route('https://fonts.googleapis.com/**',lambda r:r.abort())
    mobile.route('https://fonts.gstatic.com/**',lambda r:r.abort())
    mobile.set_content(HTML.read_text(encoding='utf8'),wait_until='domcontentloaded')
    dims=mobile.evaluate('''() => ({view:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,
      count:document.querySelectorAll('.chapter[data-chapter="11"] .passage').length})''')
    results['phone_390px']=dims
    # Some wide tables allow their own horizontal scrolling, but document itself should not overflow.
    assert dims['scroll'] <= dims['view']+2, dims
    mcontext.close();context.close();browser.close()

pdf=fitz.open(PDF)
assert len(pdf)==127,(len(pdf),'unexpected full page count')
assert len(pdf.get_toc())==189
assert pdf.xref_get_key(pdf.pdf_catalog(),'PageMode')==('name','/UseOutlines')
assert sum(len(p.get_links()) for p in pdf)>=12
assert all(abs(p.rect.width-960)<1.2 and abs(p.rect.height-540)<1.2 for p in pdf)
assert all(1<=pg<=len(pdf) for level,label,pg in pdf.get_toc())
assert any('Amiri' in f[3] for pg in pdf for f in pg.get_fonts(full=True))
results['full_pdf']={'pages':len(pdf),'bookmarks':len(pdf.get_toc()),'links':sum(len(pg.get_links()) for pg in pdf)}
REPORT=ROOT/'QA_READINGS_11_12_MACHINE.json'
REPORT.write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps(results,indent=2,ensure_ascii=False))
