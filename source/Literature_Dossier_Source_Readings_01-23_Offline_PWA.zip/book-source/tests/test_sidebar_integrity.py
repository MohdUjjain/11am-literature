#!/usr/bin/env python3
"""Portable smoke gate for the 8-reading sidebar checkpoint. Source parsing + PDF readback."""
import argparse
from pathlib import Path
from collections import Counter
from bs4 import BeautifulSoup
import json,fitz
SRC=Path(__file__).resolve().parents[1]
EXPECTED={1:15,2:16,3:18,4:19,5:14,6:14,7:15,8:17}
CATS={'definition','concept','examtip','mistake','memory','highyield'}

def check_source():
 files=sorted((SRC/'chapters').glob('*.html'))
 assert len(files)>=8
 observed={}
 for f in files:
  s=BeautifulSoup(f.read_text(encoding='utf-8'),'html.parser')
  ch=s.select_one('.chapter');n=int(ch['data-chapter'])
  if n not in EXPECTED:continue
  notes=s.select('.leaf > .section .passage > aside .callout')
  assert len(notes)==EXPECTED[n],(n,len(notes))
  assert not s.select('.leaf .prose .callout'),n
  assert len(s.select('.revision-zone .section'))==6,n
  assert set(c.get('data-content-type') for c in notes).issubset(CATS),n
  ids=[x['data-note-id'] for x in notes]
  assert len(ids)==len(set(ids)),n
  assert all(x.find_parent(class_='passage').get('data-anchor') for x in notes)
  observed[n]=len(notes)
 assert observed==EXPECTED
 return observed

def check_pdf(path):
 d=fitz.open(path)
 assert len(d)>=25
 toc=d.get_toc()
 assert len(toc)>100
 assert d.xref_get_key(d.pdf_catalog(),'PageMode')==('name','/UseOutlines')
 assert all(abs(x.rect.width-960)<1.2 and abs(x.rect.height-540)<1.2 for x in d)
 links=sum(len(x.get_links()) for x in d)
 assert links>=8,(links,'Contents links missing')
 assert any('Amiri' in f[3] for sheet in d for f in sheet.get_fonts(full=True)), 'Missing Arabic font'
 assert all(1<=num<=len(d) for _,_,num in toc)
 return {'pages':len(d),'bookmarks':len(toc),'links':links}
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--pdf',type=Path)
 args=parser.parse_args()
 r={'source_notes':check_source()}
 if args.pdf:r['pdf']=check_pdf(args.pdf)
 print(json.dumps(r,indent=2))
