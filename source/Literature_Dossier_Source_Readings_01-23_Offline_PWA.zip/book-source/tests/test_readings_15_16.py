#!/usr/bin/env python3
"""Manual readings 15–16 acceptance: immutable base, source and exact-card checks."""
from pathlib import Path
from collections import Counter
import zipfile,hashlib,json
import fitz
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
base=Path('/mnt/data/Literature_Dossier_Source_Readings_01-14_Editorial.zip')
manifest=json.loads((root/'NEW_READINGS_15_16_MANIFEST.json').read_text())
fixed=[]
with zipfile.ZipFile(base) as z:
    for name in z.namelist():
        if name.startswith('book-source/chapters/') and name.endswith('.html') or name in ['book-source/styles.css','book-source/engine.js','book-source/build.py','book-source/export_bookmarked.py','book-source/cover.html','book-source/head-template.html','book-source/course_index.json']:
            rel=name.removeprefix('book-source/')
            assert (root/rel).read_bytes()==z.read(name), 'modified prior chapter/publisher: '+rel
            fixed.append(rel)
terms={
 15:['Ṭayyib','dawr al-satr','Dāʿī al-muṭlaq','ẓāhir','bāṭin','taʾwīl','Yemen','Surat','Mumbai','1915','Adamji','72','37%','1979','1981','2014','Qutbuddin','khatna','Jamea'],
 16:['Shuʿūbiyyah','Qays','Kalb','Marj Rāhiṭ','Māriyah','Khārijī','mawālī','Barmecides','al-Maʾmūn','ahl al-taswiyah','49:13','Mathālib','al-Haytham','zandaqah','Daydān','Ibn Waḥshiyyah','Ibn Qutaybah','Ibn García','al-Zamakhsharī']
}
per={};count=0
for num in (15,16):
    raw=root/'sources'/f'{num:02d}-raw-explainer.txt'
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==manifest['source_sha256'][str(num)]
    files=list((root/'chapters').glob(f'{num:02d}-*.html'))
    assert len(files)==1,files
    d=BeautifulSoup(files[0].read_text(encoding='utf8'),'html.parser')
    assert d.select_one('.chapter')['data-chapter']==str(num)
    sections=d.select('.leaf > .section')
    assert len(sections)==(7 if num==15 else 8)
    assert len(d.select('.revision-zone .section'))==6
    assert not d.select('.leaf .prose .callout')
    notes=d.select('.leaf article.passage > aside .callout')
    assert len(notes)==(23 if num==15 else 26)
    assert len({x['data-note-id'] for x in notes})==len(notes)
    assert all(x['data-note-id'].startswith(x.find_parent('article')['data-anchor']) for x in notes)
    assert {x['data-content-type'] for x in notes}=={'definition','concept','examtip','mistake','memory','highyield'}
    mem=[x for x in notes if x['data-content-type']=='memory']
    revisions=d.select('.revision-zone .callout--memory')
    assert len(mem)==len(revisions)==(5 if num==15 else 6)
    assert [x.select_one('p').decode_contents() for x in mem]==[x.select_one('p').decode_contents() for x in revisions]
    full=d.get_text(' ',strip=True).casefold()
    missing=[x for x in terms[num] if x.casefold() not in full]
    assert not missing,(num,missing)
    per[num]={'main_sections':len(sections),'passages':len(d.select('.leaf article.passage')),'side_cards':len(notes),'memory_aids':len(mem),'tables':len(d.select('.leaf table')),'source_bytes':len(raw.read_bytes()),'type_counts':dict(Counter(x['data-content-type'] for x in notes))}
    count+=len(notes)

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=browser.new_context(viewport={'width':1500,'height':900})
    pg=ctx.new_page(); errors=[]
    pg.on('pageerror',lambda err:errors.append(str(err)))
    pg.route('https://fonts.googleapis.com/**',lambda r:r.abort())
    pg.route('https://fonts.gstatic.com/**',lambda r:r.abort())
    pg.set_content((root/'output/book.html').read_text(encoding='utf8'),wait_until='domcontentloaded')
    pg.locator('#range-spec').fill('15,16');pg.evaluate('window.DossierPrint.build()')
    d=pg.evaluate('window.__dossierPrintDiagnostics')
    v=pg.evaluate('''() => {let pages=[...document.querySelectorAll('#print-root>.printed-page')];return {
      pages:pages.length,
      items:[...document.querySelectorAll('#print-root .side-note-card')].map(c=>{let p=c.closest('.printed-page'),a=c.getAttribute('data-note-anchor');return {id:c.getAttribute('data-note-id'),anchor:a,valid:!!p?.querySelector('.page-main-column [data-anchor="'+a+'"]')}}),
      clipped:pages.some(p=>{let el=p.querySelector('.printed-body');return el&&el.scrollHeight>el.clientHeight+2})}}
    ''')
    assert not errors,errors
    assert not d.get('error') and not d.get('overflows'),d
    assert not v['clipped']
    assert len(v['items'])==count,(len(v['items']),count)
    assert len({x['id'] for x in v['items']})==count
    assert all(x['valid'] for x in v['items']),[x for x in v['items'] if not x['valid']]
    mob=browser.new_context(viewport={'width':390,'height':844})
    mp=mob.new_page();mp.route('https://fonts.googleapis.com/**',lambda r:r.abort());mp.route('https://fonts.gstatic.com/**',lambda r:r.abort())
    mp.set_content((root/'output/book.html').read_text(encoding='utf8'),wait_until='domcontentloaded')
    mobile=mp.evaluate('''() => ({width:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})''')
    assert mobile['scroll'] <= mobile['width']+2,mobile
    mob.close();ctx.close();browser.close()

pair=Path('/mnt/data/dossier_15_16/Readings_15-16_initial.pdf')
pdf=fitz.open(pair)
assert len(pdf)==v['pages']
assert len(pdf.get_toc())==33
assert sum(len(p.get_links()) for p in pdf)>=2
assert all(abs(p.rect.width-960)<1.5 and abs(p.rect.height-540)<1.5 for p in pdf)
report={'status':'PASS','unchanged_previous_files':len(fixed),'readings':per,'exact_linked_cards':count,
        'pair_composed_pages':v['pages'],'pair_physical_pages':len(pdf),'pair_bookmarks':len(pdf.get_toc()),
        'pair_contents_links':sum(len(p.get_links()) for p in pdf),'browser_errors':errors,'mobile':mobile,'font_profile':'offline'}
(root/'QA_READINGS_15_16_MACHINE.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps(report,indent=2,ensure_ascii=False))
