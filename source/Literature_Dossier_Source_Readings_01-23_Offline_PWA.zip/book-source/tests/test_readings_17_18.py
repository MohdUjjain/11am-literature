#!/usr/bin/env python3
"""Acceptance tests for manual batch 17–18; expected unmodified 01–16 edition."""
from collections import Counter
from pathlib import Path
from zipfile import ZipFile
import hashlib, json, os
import fitz
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

R=Path(__file__).resolve().parents[1]
BASE=Path(os.environ.get('DOSSIER_BASE_ZIP','/mnt/data/Literature_Dossier_Source_Readings_01-16_Editorial.zip'))
MAN=json.loads((R/'NEW_READINGS_17_18_MANIFEST.json').read_text(encoding='utf-8'))
fixed=[]
with ZipFile(BASE) as z:
 for name in z.namelist():
  if (name.startswith('book-source/chapters/') and name.endswith('.html')) or name in [f'book-source/{x}' for x in ['styles.css','engine.js','build.py','export_bookmarked.py','cover.html','head-template.html','course_index.json']]:
   rel=name.removeprefix('book-source/')
   assert (R/rel).read_bytes()==z.read(name),f'Prior source or publishing component modified: {rel}'
   fixed.append(rel)
expected={17:{'terms':['antimajoritarian','ḥaqq','fiqh','Sharīʿa','ḥudūd','shubha','khalīfa','amāna','Muʿtazila','Ibn Rushd','Ibn Bājja','ʿAbd al-Jabbār','colonial','Aquinas'],'sections':7,'notes':23,'memory':5,'tables':2},
          18:{'terms':['Wicker Bar','Carl Luce','Tina','Janine','Little Shirley Beans','Sally Hayes','Allie','Phoebe Weatherfield','Benedict Arnold','Colorado ranch','elephants','Central Park','record fragments'],'sections':6,'notes':20,'memory':5,'tables':2}}
checks={};total=0
for n,ex in expected.items():
 raw=R/'sources'/f'{n:02d}-raw-explainer.txt'
 assert hashlib.sha256(raw.read_bytes()).hexdigest()==MAN['source_sha256'][str(n)]
 path=list((R/'chapters').glob(f'{n:02d}-*.html'));assert len(path)==1
 soup=BeautifulSoup(path[0].read_text(encoding='utf-8'),'html.parser')
 body=soup.select_one('.leaf');assert body
 assert len(body.select(':scope > .section'))==ex['sections']
 assert len(soup.select('.revision-zone .section'))==6
 notes=soup.select('.leaf article.passage > aside .callout')
 assert len(notes)==ex['notes']
 assert len(set(c['data-note-id'] for c in notes))==len(notes)
 assert all(c['data-note-id'].startswith(c.find_parent('article')['data-anchor']) for c in notes)
 typ=Counter(c['data-content-type'] for c in notes)
 assert set(typ)=={'definition','concept','examtip','mistake','memory','highyield'}
 mem=[c.select_one('p').decode_contents() for c in notes if c['data-content-type']=='memory']
 collection=[c.select_one('p').decode_contents() for c in soup.select('.revision-zone .callout--memory')]
 assert len(mem)==ex['memory'] and mem==collection
 assert len(body.select('table'))>=ex['tables']
 assert not body.select('.prose .callout')
 all_text=soup.get_text(' ',strip=True).casefold()
 missing=[t for t in ex['terms'] if t.casefold() not in all_text]
 assert not missing,(n,missing)
 checks[n]={'main_sections':ex['sections'],'passages':len(body.select('article.passage')),'side_notes':len(notes),
            'types':dict(typ),'memory_duplicated_in_revision':len(mem),'tables':len(body.select('table')),'missing_terms':missing}
 total+=len(notes)

with sync_playwright() as playwright:
 browser=playwright.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 ctx=browser.new_context(viewport={'width':1500,'height':900})
 pg=ctx.new_page();errors=[];pg.on('pageerror',lambda err:errors.append(str(err)))
 pg.route('https://fonts.googleapis.com/**',lambda route:route.abort())
 pg.route('https://fonts.gstatic.com/**',lambda route:route.abort())
 pg.set_content((R/'output/book.html').read_text(),wait_until='domcontentloaded')
 pg.locator('#range-spec').fill('17,18');pg.evaluate('window.DossierPrint.build()')
 diag=pg.evaluate('window.__dossierPrintDiagnostics')
 audit=pg.evaluate('''() => {const pp=[...document.querySelectorAll('#print-root>.printed-page')]; const c=[...document.querySelectorAll('#print-root .side-note-card')];return {page_count:pp.length,
 cards:c.map(x=>{let p=x.closest('.printed-page'),a=x.getAttribute('data-note-anchor');return{id:x.getAttribute('data-note-id'),anchor:a,match:!!p?.querySelector('.page-main-column [data-anchor="'+a+'"]')}}),
 clipped:pp.some(p=>{let b=p.querySelector('.printed-body');return b&&b.scrollHeight>b.clientHeight+2})}}''')
 assert not errors,errors
 assert not diag.get('error') and not diag.get('overflows') and diag.get('notesUnplaced')==0,diag
 assert len(audit['cards'])==total and all(x['match'] for x in audit['cards'])
 assert len(set(x['id'] for x in audit['cards']))==total
 assert not audit['clipped']
 ctx.close()
 mob=browser.new_context(viewport={'width':390,'height':844});p=mob.new_page();p.set_content((R/'output/book.html').read_text(),wait_until='domcontentloaded')
 mobile=p.evaluate('''()=>({screen:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})''')
 assert mobile['scroll']<=mobile['screen']+2,mobile
 mob.close();browser.close()
pair=fitz.open(R/'output/Readings_17-18_first.pdf')
full=fitz.open(R/'output/Complete_01-18.pdf')
assert len(pair)==audit['page_count']==25
assert len(pair.get_toc())==31
assert sum(len(p.get_links()) for p in pair)>=2
assert len(full)==192 and len(full.get_toc())==278
assert sum(len(p.get_links()) for p in full)>=18
assert all(abs(p.rect.width-960)<1 and abs(p.rect.height-540)<1 for p in full)
res={'status':'PASS','base_files_unchanged':len(fixed),'per_reading':checks,
     'exact_pair_side_notes':total,'pair_pages':len(pair),'pair_bookmarks':len(pair.get_toc()),
     'full_pages':len(full),'full_bookmarks':len(full.get_toc()),'full_contents_links':sum(len(p.get_links()) for p in full),
     'mobile':mobile,'pdf_profile':'offline','known_full_volume_exception':'s4-6-n2 (Reading 04)' }
(R/'QA_READINGS_17_18_MACHINE.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print(json.dumps(res,ensure_ascii=False,indent=2))
