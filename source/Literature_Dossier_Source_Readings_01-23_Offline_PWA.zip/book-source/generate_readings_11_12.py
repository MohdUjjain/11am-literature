"""Author Readings 11 and 12 against the canonical 01-10 sidebar edition.
Only adds new chapter files and raw source archives; never rewrites 01-10.
"""
from pathlib import Path
import html, json
ROOT=Path(__file__).resolve().parent

def P(text,*notes):
    return {'html':'<p>'+text+'</p>','notes':[dict(kind=a,title=b,body=c) for a,b,c in notes]}
def T(headers, rows, *notes):
    return {'html':'<table data-content-type="comparison" data-pagination="repeat-header"><thead><tr>'+''.join('<th>'+html.escape(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table>', 'notes':[dict(kind=a,title=b,body=c) for a,b,c in notes]}
def L(items,*notes):
    return {'html':'<ol>'+''.join('<li>'+x+'</li>' for x in items)+'</ol>','notes':[dict(kind=a,title=b,body=c) for a,b,c in notes]}
def S(title,*items):return {'title':title,'items':list(items)}

COLORS={'definition','concept','examtip','mistake','memory','highyield'}

def build(n,title,subtitle,thesis,sections,definitions,keytables,memory,questions,summary,cards,accent,source_id,file_slug):
    output=[f'<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{accent};"><div class="leaf"><div class="chapter-title-page">',
            f'<div class="reading-eyebrow">Reading {n:02d} · Literature Dossier</div><h1>{html.escape(title)}</h1>',
            f'<p class="subtitle">{html.escape(subtitle)}</p><hr class="gold-rule"/>',
            '<div class="opener-split"><div class="thesis-block"><p class="kicker">Central thesis</p>',
            '<p>'+thesis+'</p></div><div class="roadmap"><p class="kicker">In this reading</p><ol>',
            *['<li>'+html.escape(section['title'])+'</li>' for section in sections],'</ol></div></div>',
            f'<p class="source-cite">Source: supplied Drive explainer {n:02d} (Google Doc {source_id}). The original scholarly publication has not been independently checked. Historical legal doctrines and descriptions are those of the supplied account, not present-day legal guidance.</p></div>']
    types={};count=0
    for i,sec in enumerate(sections,1):
        output.append(f'<div class="section" id="s{n}-{i}"><div class="section-number">§{n}.{i}</div><h2>{html.escape(sec["title"])}</h2><div class="section-body">')
        for j,item in enumerate(sec['items']):
            anchor=f's{n}-{i}-p{j}'
            output.append(f'<article class="passage" data-anchor="{anchor}"><div class="prose">{item["html"]}</div>')
            if item['notes']:
                output.append('<aside aria-label="Study notes for this passage">')
                for k,note in enumerate(item['notes']):
                    typ=note['kind'];assert typ in COLORS
                    types[typ]=types.get(typ,0)+1;count+=1
                    output.append(f'<div class="callout callout--{typ}" data-content-type="{typ}" data-note-id="{anchor}-n{k}" data-pagination="allow-split"><div class="tag">{html.escape(note["title"])}</div><p>{note["body"]}</p></div>')
                output.append('</aside>')
            output.append('</article>')
        output.append('</div></div>')
    output.extend(['</div><div class="revision-zone"><div class="revision-leaf">',f'<div class="revision-kicker">Reading {n:02d} · Revision &amp; recall</div>'])
    def R(i,title,body):return f'<div class="section" id="s{n}-rev-{i}"><div class="section-number">REV {i:02d}</div><h2>{title}</h2><div class="section-body">{body}</div></div>'
    output.append(R(1,'Chapter Summary','<p>'+summary+'</p>'))
    output.append(R(2,'One-Page Revision Sheet','<div data-pagination="keep-together"><div class="revision-grid">'+''.join(f'<div class="revision-card"><h3>{h}</h3><p>{b}</p></div>' for h,b in cards)+'</div></div>'))
    output.append(R(3,'Key Definitions',T(['Term','Meaning in this reading'],definitions)['html']))
    output.append(R(4,'Key Tables',keytables))
    output.append(R(5,'Memory Aids','<div class="callout-grid">'+''.join(f'<div class="callout callout--memory" data-content-type="memory" data-pagination="allow-split"><div class="tag">Memory aid · From §{n}.{i} · {h}</div><p>{b}</p></div>' for i,h,b in memory)+'</div>'))
    output.append(R(6,'Possible Examination Questions','<div class="revision-grid exam-question-grid">'+''.join(f'<div class="exam-q"><span class="qtype">{cat}</span><p>{q}</p></div>' for cat,q in questions)+'</div>'))
    output.extend(['</div></div></section>'])
    p=ROOT/'chapters'/f'{n:02d}-{file_slug}.html';p.write_text(''.join(output),encoding='utf8')
    return dict(reading=n,file=p.name,sections=len(sections),passages=sum(len(s['items']) for s in sections),notes=count,note_types=types,revision_sections=6,memory_aids=len(memory))

# 11 — source-derived legal comparison, not a statement of current legal rules.
sec11=[
S('Why Homicide Looks Like a Private Wrong',
 P('The supplied account opens with J. N. D. Anderson’s comparative-law paradox: a European lawyer expects murder to be a public crime, whereas classical Islamic jurisprudence often treats <em>qatl</em> as a <strong>private wrong whose primary claimant is the victim’s family</strong>. The distinction is not that a death lacks public consequences. The legal scheme combines the heirs’ <em>right of blood</em> with an emerging public responsibility to restrain violence.',
  ('definition','Definition · Qatl','<em>Qatl</em> means homicide; its treatment here belongs to the classical legal schools described by the source.'),
  ('concept','Key idea · Two overlapping rights','<em>Right of the individual</em> = heirs’ claim; <em>right of God</em> = the community’s interest in public order.')),
 P('The source therefore describes a <strong>tort–crime hybrid</strong>, not a neat division between justice and vengeance. It asks how retaliation, payment, pardon, judicial inquiry and public punishment could operate within one tradition. Differences among the Ḥanafī, Mālikī, Shāfiʿī and Ḥanbalī schools are essential rather than exceptional.',
  ('examtip','Exam cue · Begin with the paradox','Explain how heirs may settle a homicide claim yet rulers still regulate proof and public order.'),
  ('memory','Memory aid · Private plus public','<strong>Heirs’ right + judge’s proof + ruler’s order.</strong>'))),
S('From Tribal Blood-Feud to Controlled Retaliation',
 P('In the account’s reconstruction of pre-Islamic Arabia, tribal blood-feuds could expand a single killing into retaliation against many members of the opposing group. The new legal order restricted revenge through <strong>individual liability</strong>, proof of deliberate and wrongful culpability, and <strong>judicial oversight</strong> before retaliation could be sanctioned. Tribal affiliation no longer made every clansman a substitute victim.',
  ('memory','Memory aid · The three checks','<strong>Person → Purpose → Proof.</strong> Punish the responsible person, establish wrongful intent, and require judgment.')),
 T(['Predominant right','Representative cases','Who may end the claim?'],[
 ['Public / “right of God”','<em>Sariqa</em> (theft), <em>zinā</em>, wine-drinking','The supplied account presents no private pardon once proceedings begin.'],
 ['Private / individual right','Homicide, wounding (<em>jināyāt</em>)','Heirs may seek retaliation, remit or settle, within school-specific rules.']],
  ('mistake','Common mistake · Private ≠ unregulated','Private standing for the heirs does not mean that retaliation can occur without a ruler or judge.'))),
S('Qisāṣ, Diya and the Heirs’ Power to Remit',
 P('<em>Qiṣāṣ</em> means retaliation in kind; <em>diya</em> is monetary compensation. Because the heirs hold the claim, their power to forgive may bar retaliation for everyone. But the schools differ on whether heirs can <em>insist</em> on diya rather than accepting an agreed settlement. The Ḥanafīs and Mālikīs generally deny unilateral substitution, while Shāfiʿīs and Ḥanbalīs allow a choice.',
  ('definition','Definition · Qiṣāṣ / diya','<em>Qiṣāṣ</em>: retaliation; <em>diya</em>: compensation in lieu of or for a killing under specified rules.'),
  ('highyield','High-yield · One heir can change the outcome','The source reports that remission by one competent heir cancels retaliation for the others, although payment claims require separate analysis.')),
 T(['School','Can heirs require diya?','Guardian of a minor heir'],[
 ['Ḥanafī','No unilateral insistence; may negotiate settlement','May settle if in the ward’s interest.'],
 ['Mālikī','Generally no unilateral insistence','May remit where judged beneficial.'],
 ['Shāfiʿī','Yes, heirs may choose','May remit for an actual need of funds.'],
 ['Ḥanbalī','Yes, heirs may choose','May remit for an actual need of funds.']],
  ('memory','Memory aid · Who may choose?','<strong>Shāfiʿī + Ḥanbalī: choose</strong> between retaliation and compensation. <strong>Ḥanafī + Mālikī: settle</strong> rather than insist.'))),
S('Status, Equality and the Ascendant Exception',
 P('Classical <em>talion</em> raised a question beyond guilt: could an offender be executed when victim and killer differed in gender, religion or freedom? The four schools described here ultimately allow retaliation for a man killing a woman, while the source reports gender-differentiated diya. On religion, the Ḥanafī school permits qiṣāṣ when a Muslim kills a protected non-Muslim (<em>dhimmī</em>); the other schools in this account generally require compensation instead. The source similarly describes the Ḥanafīs as permitting retaliation for the killing of an enslaved person by a free person, unlike most others.',
  ('concept','Key concept · Equality is contested','Sex, religious standing and freedom affect the schools’ rules differently. Do not infer a single uniform doctrine.'),
  ('mistake','Avoid conflating punishment and valuation','Equal access to qiṣāṣ in one category does not imply identical historical diya rates.')),
 P('A parent who kills a descendant is generally exempted from qiṣāṣ in the Ḥanafī, Shāfiʿī and Ḥanbalī accounts. The Mālikī exception turns on exceptionally clear evidence of murderous intention, such as physically restraining a child before a fatal cutting. The source uses this contrast to expose tension between family hierarchy, proof of malice and the ruler’s interest in punishment.',
  ('highyield','High-yield · Mālikī ascendant rule','Exception to the usual parent exemption where deliberate intent is demonstrated with unusually strong evidence.'))),
S('Five Degrees of Culpability: The Ḥanafī Spectrum',
 P('Since intention cannot be seen directly, Ḥanafī jurists in the source rely on an external <em>dalīl</em>—particularly the instrument used—as evidence of mental purpose. The five-fold scheme distinguishes lethal assault from a non-lethal weapon used deliberately, accidents, acts without volition and indirect causes. Only the first category triggers qiṣāṣ under this classification; quasi-deliberate assault instead carries aggravated diya.',
  ('definition','Definition · Dalīl','An outward indicator used to infer a legally relevant inner intention.'),
  ('memory','Memory aid · Five-step intent ladder','<strong>Lethal → Non-lethal → Mistake → No volition → Indirect cause.</strong>')),
 T(['Ḥanafī category','Illustration / liability cue'],[
 ["Deliberate (<em>ʿamd</em>)",'Intentional lethal weapon; qiṣāṣ may apply.'],
 ["Quasi-deliberate (<em>shabah ʿamd</em>)",'Intentional strike with non-lethal implement; heavier diya.'],
 ['Accidental (<em>khaṭaʾ</em>)','Misidentified target or erroneous shot.'],
 ['Equivalent to accidental','Sleeper falls upon an infant; no purposeful act.'],
 ['Indirect (<em>bi-sabab</em>)','A pit dug by one person causes another’s death.']],
  ('examtip','Contrast · Mālikī test','The source describes the Mālikī test of deliberate wrongdoing more broadly: hostile, unjustified assault, less centered on weapon type.'))),
S('Causation: Poison, Neglect and Justified Killing',
 P('Difficult cases ask <em>what caused</em> a death and whether the accused’s act is sufficiently direct. In the source, Mālikīs and Ḥanbalīs can classify covert poisoning of an unwitting victim as deliberate, while Ḥanafīs and some Shāfiʿīs regard swallowing as a potentially intervening act. Non-Ḥanafī schools treat confinement without food or water until death as deliberate homicide; the Mālikī example extends to deliberately withholding nursing from an infant.',
  ('concept','Key concept · Causal interruption','If another act intervenes between poison and death, schools dispute how far homicide responsibility extends.')),
 P('A killing may be <em>hadar</em> (without liability) where a justification such as legitimate self-defense exists. The Ḥanafī <em>Hidāya</em> gives a context-dependent illustration: a sword threat licenses lethal defense; a staff threat may do so at night or where help is unavailable, but not necessarily by day in a populated town. This is an account of historical juristic reasoning, <strong>not practical self-defense advice</strong>. The source also connects public enforcement to cases categorized as apostasy, adultery or <em>ḥirāba</em> (brigandage).',
  ('definition','Definition · Hadar','A killing for which the classical legal account assigns no homicide liability.'),
  ('mistake','Common mistake · Do not modernize the rule','The Hidāya examples are historical legal illustrations, not current instructions about permissible force.'))),
S('Several Actors: Conspiracy, a Second Blow and Compulsion',
 P('Without conspiracy, the supplied account links qiṣāṣ to the participant whose assault was mortal. Where assailants <strong>conspired</strong>, Shāfiʿīs and Mālikīs may hold all direct participants answerable even if each blow was not fatal. A second-assailant dispute turns on whether the first person had already left only “flickering life”: Ẓāhirī and Mālikī positions identify the finisher as killer; the majority view described here can attribute death to the first assailant where recovery was impossible.',
  ('memory','Memory aid · Joint homicide','Ask <strong>agreement?</strong> Then <strong>whose blow?</strong> Then <strong>was recovery possible?</strong>')),
 T(['Compulsion: account in source','Qiṣāṣ falls on'],[
 ['Mālikī / Ẓāhirī / Shāfiʿī','Both coercer and direct actor.'],
 ['Ḥanafī / Ḥanbalī','Coercer; direct actor treated as an instrument.'],
 ['Zufar (Ḥanafī)','Direct actor only.'],
 ['Abū Yūsuf (Ḥanafī)','Neither, because doubt prevents qiṣāṣ.']],
  ('highyield','High-yield · Coercion divides the schools','Compulsion can shift liability from the hand that strikes to the person threatening it; four positions are supplied.')),
 P('An accomplice who merely restrains the victim may face a distinct and severe non-qiṣāṣ sanction. The source says the Ẓāhirīs and some Ḥanbalīs prescribed imprisonment until death for such an assistant, interpreting punishment through the act of holding the victim. These variants illustrate why assigning criminal responsibility requires more than simply counting participants.')),
S('Conclusion: The Public Interest Within a Private Claim',
 P('The argument ends where its opening paradox began: the heirs’ claim to retaliation or remission remained central, yet judicial investigation, limits on vengeance and growing ruler-led punishment introduced a public dimension. In this account, <em>taʿzīr</em> and the ruler’s action for victims without relatives express an emergent idea of crime without erasing the law of the private “right of blood.” The core intellectual lesson is to compare <strong>intent, evidence, equality, causation and standing</strong>—and to identify precisely where the four schools disagree.',
  ('examtip','Exam answer · Build the distinction','Opening paradox → heirs’ choice → school variation → public judicial authority.')))
]

memory11=[
 (2,'Three checks','<strong>Person → Purpose → Proof.</strong> Individual liability, wrongful intention and judicial judgment.'),
 (3,'School split','<strong>Shāfiʿī / Ḥanbalī = choose</strong> diya. <strong>Ḥanafī / Mālikī = settle</strong>, not unilaterally demand.'),
 (5,'Intent ladder','<strong>Lethal → Non-lethal → Mistake → No volition → Indirect.</strong>'),
 (7,'Joint homicide questions','<strong>Agreement? Mortal blow? Recovery?</strong> Separate conspiracy, causation and second attacker.'),
 (1,'Private plus public','<strong>Heirs’ right + judge’s proof + ruler’s order.</strong>')
]
rev11_table=T(['Issue','Decisive juristic contrast'],[
 ['Choice of diya','Shāfiʿī/Ḥanbalī may insist; Ḥanafī/Mālikī generally negotiate.'],
 ['Victim status','Ḥanafīs differ from other schools on protected non-Muslims and enslaved victims.'],
 ['Mens rea','Ḥanafī weapon indicator versus broader Mālikī hostile-assault test.'],
 ['Poison','Mālikī/Ḥanbalī include covert poison; Ḥanafī/some Shāfiʿī identify intervening swallowing.'],
 ['Compulsion','Four stances distinguish coerced actor, coercer, both or neither.']])['html']
res11=build(11,'Homicide in Islamic Law','From tribal vengeance to a complex law of rights, intention and public order',
'The classical law described in the supplied article is a <strong>hybrid</strong>: heirs control much of the retaliation claim, but judicial oversight and public authority constrain vengeance. Divergences among the four schools turn on remission, equality, intention, causation and collective guilt.',
sec11,
 [('Qatl','Homicide.'),('Qiṣāṣ','Retaliation in kind, or talion.'),('Diya','Financial compensation or blood-money.'),('ʿĀqila','Family or tribal support group associated with blood-money for non-deliberate cases.'),('Dalīl','An outward indication from which intention is inferred.'),('Hadar','A killing assigned no legal liability in the doctrine discussed.'),('Ghīla','Killing by lure or ulterior motive, as listed in the source glossary.'),('Ḥirāba','Brigandage, treated by the source as an offense against public order.'),('Taʿzīr','Discretionary punishment associated with public justice.')],
rev11_table,memory11,
 [('Definition','Distinguish qiṣāṣ, diya and the two kinds of legal right.'),('Comparison','Which schools allow the heirs to insist on diya, and how does one heir’s pardon affect retaliation?'),('Short answer','Explain the three restrictions placed on pre-Islamic blood revenge.'),('Classification','Give the five Ḥanafī degrees of homicide and one example of each.'),('Problem','Compare the schools’ approaches to poison, neglect and the first/second assailant.'),('Long essay','How does classical homicide law develop an idea of public crime without eliminating the heirs’ “right of blood”?')],
'The source treats homicide as a legal hybrid: the victim’s heirs retain an important claim over retaliation and payment, while the judiciary controls proof and the ruler’s public responsibility grows. Islam’s limitations on tribal revenge impose individual fault, wrongful intent and judgment. The schools disagree over heirs’ power to demand diya, status-based equality in retaliation, ascendants, classifications of intent, poisonous or indirect causation, conspiracy and coercion. The Ḥanafī five-part intent scheme is distinguished from the Mālikī focus on hostile assault. The closing claim is an emerging public idea of crime within a law still structured by the family’s right.',
 [('Core paradox','Homicide: family-held claim operating inside public judicial order.'),('Remission','One heir’s forgiveness blocks talion; schools disagree on choosing diya.'),('Evidence & guilt','Five Ḥanafī degrees; weapon as indicator of hidden intention.'),('Hard cases','Status and family hierarchy; poison/neglect; conspiracy, compulsion and second blow.')],
'#6C527D','1M5PlDRwfk-2nzDFz7MdjGsBXAvBuFR8tbaHQucBkSZ4','homicide-islamic-law')

# 12 — source-based archival interpretation; distinguish supplied argument from proof.
sec12=[
S('The Cairo Geniza Changes the Question',
 P('The source uses the Cairo Geniza to challenge an image of Jews under the Fāṭimids as either a sealed-off minority or a community left alone by a weak state. Petitions, correspondence and administrative imitations suggest <strong>frequent negotiation with imperial authority</strong>. Jewish communal autonomy was simultaneously a technique of governance by proxy and a resource Jewish litigants could use against their own leaders.',
  ('concept','Key concept · Autonomy as a relationship','The source’s thesis is neither simple independence nor simple oppression: state-backed self-government and recourse to officials coexist.'),
  ('memory','Memory aid · The two-way bargain','<strong>State delegates → community governs; community petitions → state enforces.</strong>')),
 P('The methodological shift is from pronouncements by communal elites to the everyday actions visible in documentary fragments. Where prescriptive texts condemn appeal to outside courts, a victim or merchant may view the same appeal as the only workable remedy. The dossier follows this source framing without claiming that all Jewish communities or periods experienced the state identically.',
  ('examtip','Exam cue · Name the archive and perspective','Contrast elite norms with the litigant’s document; do not turn one case into a universal social rule.'))),
S('Malshinut and the “Traitor” Label',
 P('In communal polemic, <em>malshinut</em> (informing) and <em>moserim</em> (informants) could stigmatize Jews who brought disputes before non-Jewish authorities. Authorities such as Yehoshua Nagid characterized this as betrayal, sometimes threatening curse or exclusion. Yet the source argues that condemnation could protect local power: an appeal was especially valuable when a rabbinical tribunal could not enforce justice or was aligned with influential men.',
  ('definition','Definition · Malshinut','Informing/denunciation; often a pejorative communal classification of appeal to non-Jewish courts.'),
  ('mistake','Common mistake · Whose judgment?','“Traitor” is the accusation of certain communal elites, not the historian’s neutral label for every petitioner.')),
 P('The source cites Geniza fragment <strong>ENA NS 31.21</strong>: a woman abused by her husband and his family sought state intervention after communal mechanisms failed. Her in-laws attempted to portray her as an informer. The document is dated broadly <strong>from the mid-twelfth to mid-thirteenth century</strong> in the supplied text; that span extends beyond the end of Fāṭimid rule, so it illustrates a wider legal tension rather than securely dating every element to the dynasty.',
  ('highyield','Evidence · ENA NS 31.21','The woman’s appeal shows why state courts could offer protection when communal standing worked against a litigant.'))),
S('Autonomy by Default or by Design?',
 P('Drawing on Elka Klein, the account argues that privileges exist meaningfully only when a coercive institution will uphold them. Rabbinical decisions sometimes required the state’s power to fine, imprison or compel compliance. <strong>Autonomy by default</strong> arises from governmental neglect; <strong>autonomy by design</strong> is intentionally recognized and resourced by the ruler for administrative ends.',
  ('definition','Definition · Two autonomies','<em>Default</em> = rule because a state does not intervene. <em>Design</em> = recognized self-rule sustained by state authority.'),
  ('memory','Memory aid · Neglect vs charter','<strong>Default: unwatched.</strong> <strong>Design: delegated, watched, enforceable.</strong>')),
 T(['Comparison','Autonomy by default','Autonomy by design'],[
 ['Origin','Neglect or weak local interest','Intentional state policy / charter'],
 ['Authority','An unpoliced space','State-backed communal leaders'],
 ['Political role','Govern oneself because ignored','Manage compliance, taxation and order']],
  ('concept','Concept · Enforcement makes privileges real','Without coercive support, a communal legal entitlement may be ineffective in practice.'))),
S('The Jerusalem Yeshiva and the 1025 Tax Crisis',
 P('The Fāṭimid state supported the Jerusalem Yeshiva with a stipend. In the account this was a strategic response to the difficulties of governing the Syrian hinterland: scattered wealth, Bedouin raids and scarce troops made direct surveillance expensive. Religious solidarity and institutional leadership could mobilize taxpayers more effectively than constant military intervention. The source calls this a form of <strong>proxy rule</strong>, not merely royal charity.',
  ('highyield','High-yield · Yeshiva stipend','Support for communal leadership served imperial fiscal and political objectives in Syria.')),
 P('The 1025 tax crisis followed attacks by the <strong>Banū Jarrāḥ</strong>. The source reports a Jerusalem levy of <strong>15,000 dinars</strong>, of which Jews owed <strong>6,000</strong>: 3,000 each from Rabbanites and Qaraites. Gaʾon <strong>Shelomo ha-Kohen</strong> sought help from Fusṭāṭ, describing households forced to sell their possessions. Communal ties thus operated as a channel for extracting revenue from an already distressed population.',
  ('memory','Memory aid · 15–6–3–3','<strong>15,000 total → 6,000 Jewish share → 3,000 Rabbanite + 3,000 Qaraite.</strong>'),
  ('mistake','Common mistake · Not “state absence”','The state’s indirect method of collection demonstrates governance, not indifference.'))),
S('State Literacy in Ordinary Jewish Life',
 P('The Geniza preserves traces of mid-level state personnel seldom emphasized in elite chronicles. Individuals sought help from <em>amīrs</em> (commanders and governors), <em>qāḍīs</em> (Islamic judges), and officials bearing <em>al-dawla</em> titles such as <em>Sanī al-Dawla</em> or <em>Amīn al-Dawla</em>. This bureaucratic world mattered in ordinary disputes involving large debts, grain and taxation.',
  ('definition','Definition · Tawqīʿ','A rescript or authoritative written response issued through the state administration.'),
  ('concept','Key concept · State literacy','The capacity to identify offices, draft petitions, interpret chancery replies and use government procedures strategically.')),
 P('Merchants and householders could obtain a <em>tawqīʿ</em> to settle a dispute or challenge a <em>jizya</em> demand. These records resist a picture of a government encountered only as an outside oppressor: state process was complex and could be coercive, but litigants also learned to operate within it. The argument is about documented access, not equal access for every individual.',
  ('examtip','Source analysis · Different genres','Use Geniza paperwork to reconstruct administrative contact; chronicles usually privilege rulers and military elites.'))),
S('Nahum’s Petition and the Market’s Laughter',
 P('A vivid story from <strong>1052 CE</strong> records Nahum and another Jewish man laughing in the market of Sayfayn while holding a <em>ruqʿa mutarjama</em>, a petition with a header. A chancery <em>tawqīʿ</em> authorized Nahum’s group to separate from its synagogue and pray elsewhere. The state rescript gave one Jewish faction leverage over communal authority—an instance of <strong>autonomy negotiated through an outside power</strong>.',
  ('memory','Memory aid · Nahum’s smile','<strong>Petition → rescript → independent prayer.</strong> The document, not force, changed communal leverage.')),
 P('Bystanders reportedly could read and examine the unpointed, overligatured Arabic chancery writing. The source compares this with a <strong>1029 Mount of Olives</strong> pilgrimage dispute where Jewish elders also sought state enforcement. Both leader and ordinary congregant could draw upon the ruler’s coercive authority in an internal conflict.',
  ('highyield','High-yield · Ordinary readers of chancery Arabic','The market episode supports an argument about procedural knowledge beyond elite government circles.'))),
S('Chancery Mimicry and the Style of Obeisance',
 P('The account next treats Jewish diplomatic writing as a shared political language. In the later eleventh century it describes Jewish leaders adopting formal Fāṭimid court conventions to reinforce their own legitimacy: <strong>very wide line spacing</strong>, artificial <strong>word stacking</strong> near line ends, and set phrases echoing the caliph’s exalted presence. These were not casual decorations; visual form signalled delegated authority.',
  ('definition','Definition · Diplomatic calque','An adopted written convention or formula imitating an authoritative administrative style.'),
  ('memory','Memory aid · Three marks of prestige','<strong>Space → Stack → Formula.</strong> The appearance and wording of a document could perform power.')),
 P('The point is not that Jewish law ceased to be distinct. Rather, communal leaders operated in a common “Islamicate” political environment, borrowing forms with which subjects recognized sovereign command. The source associates these changes with Fāṭimid centralization around Badr al-Jamālī but supplies its own historical framing; the specific dates of the transformation would need independent checking against primary records.',
  ('mistake','Common mistake · Borrowing ≠ identical law','Shared chancery idioms do not erase separate religious jurisprudence or communal identities.'))),
S('Conclusion: Distinct Communities in a Shared State',
 P('The Geniza challenges the image of a Jewish “state within a state”: communal leaders collected taxes, litigants petitioned officials, and documents imitated Fāṭimid forms. <strong>Autonomy was negotiated</strong> within this shared order.',
  ('examtip','Essay structure · Three forms of dependence','Argue through <strong>enforcement → fiscal delegation → documentary mimicry</strong>, using specific Geniza cases.')))
]

memory12=[
 (1,'Two-way bargain','<strong>State delegates → community governs; community petitions → state enforces.</strong>'),
 (3,'Two autonomies','<strong>Default = unwatched.</strong> <strong>Design = delegated and enforceable.</strong>'),
 (4,'1025 levy numbers','<strong>15 → 6 → 3 + 3</strong> thousand dinars: total, Jewish share, communal split.'),
 (6,'Nahum’s petition','<strong>Petition → rescript → independent prayer.</strong>'),
 (7,'Visual statecraft','<strong>Space → Stack → Formula.</strong> Three chancery-derived marks.')
]
rev12_table=T(['Document or institution','What it reveals about state and community'],[
 ['ENA NS 31.21','A woman turns to state protection when local tribunal remedies fail; date range extends after the Fāṭimids.'],
 ['Jerusalem Yeshiva stipend','State support for proxy rule and compliance in the Syrian region.'],
 ['1025 tax levy','15,000 dinars total; 6,000 Jewish quota; 3,000 each for Rabbanites/Qaraites.'],
 ['Nahum’s 1052 rescript','State authority settles a Jewish internal prayer dispute.'],
 ['Chancery calques','Prestige and power expressed through layout and deferential formulae.']])['html']
res12=build(12,'Jews and the Fatimid Caliphate','The Geniza, delegated autonomy and the everyday practice of imperial power',
'The supplied study argues that Jewish communal autonomy was <strong>designed and maintained through Fāṭimid state power</strong>, not simply granted by absence. Geniza petitions expose how communal leaders and ordinary litigants used imperial enforcement for different, sometimes opposing, purposes.',
sec12,
 [('Cairo Geniza','Documentary corpus preserving everyday legal, social and administrative transactions.'),('Malshinut','Informing; in communal rhetoric, an accusation of appeal to external authority.'),('Moserim','Informants; those branded as betraying the community by going to outside courts.'),('Autonomy by default','Informal self-rule arising from state neglect.'),('Autonomy by design','State-sponsored and enforceable community governance.'),('Gaʾon','Leader of a major Jewish academy, such as the Jerusalem Yeshiva.'),('Tawqīʿ','A state rescript or administrative written reply.'),('Ruqʿa mutarjama','A petition with an identifying header.'),('Jizya','Capitation tax mentioned in the supplied Geniza administrative cases.'),('Diplomatic calque','A borrowed convention from a chancery’s visual or verbal style.')],
rev12_table,memory12,
 [('Definition','Distinguish malshinut from a litigant’s pragmatic state appeal.'),('Comparison','What is autonomy by default, and what is autonomy by design?'),('Source analysis','Explain why ENA NS 31.21 complicates the elite condemnation of informing.'),('Economic reasoning','How did the 1025 Jerusalem levy illustrate proxy rule through the Yeshiva?'),('Case study','Why does Nahum’s 1052 chancery rescript reveal grassroots state literacy?'),('Long essay','Explain how the Geniza revises the idea of a Jewish “state within a state” under the Fāṭimids.')],
'The Geniza account challenges a sharp division between autonomous Jews and an external Fāṭimid state. Communal leaders condemned <em>malshinut</em>, but litigants could depend on official protection when internal justice failed. The source distinguishes neglected self-rule from deliberate state-backed autonomy. The Jerusalem Yeshiva’s stipend and the 1025 tax levy illustrate proxy administration and fiscal extraction, while merchants, judges, amīrs and chancery rescripts reveal everyday “state literacy.” Nahum’s 1052 petition illustrates state intervention in synagogue conflict. Jewish leaders also adopted the forms of imperial diplomatic writing. Together these cases support an interdependent “Islamicate” political landscape, while individual chronological claims remain those of the supplied account.',
 [('Central thesis','Autonomy is maintained through state recognition, enforcement and delegation.'),('Authority and dissent','Elite accusations of informing can clash with litigants’ need for protection.'),('Four evidence sites','Yeshiva stipend, Jerusalem tax, Nahum petition, chancery mimicry.'),('Interpretive conclusion','Shared political forms coexist with distinct Jewish religious law.')],
'#557D6B','12znJEOq3lp-e_iyu_kJAFtnolW72M5pTJPC0di0pP9g','jews-fatimid-caliphate')

manifest={'batch':[11,12], 'source_ids':{'11':'1M5PlDRwfk-2nzDFz7MdjGsBXAvBuFR8tbaHQucBkSZ4','12':'12znJEOq3lp-e_iyu_kJAFtnolW72M5pTJPC0di0pP9g'}, 'source_files':['sources/11-raw-explainer.txt','sources/12-raw-explainer.txt'], 'chapter_stats':[res11,res12], 'policy':'Source-grounded editorial compression; sidebar notes exactly passage-linked; 5 target/6 acceptable; 6 revision sections per reading; all shared publishing code and chapter 01-10 byte-identical'}
(ROOT/'NEW_READINGS_11_12_MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps(manifest,indent=2,ensure_ascii=False))
