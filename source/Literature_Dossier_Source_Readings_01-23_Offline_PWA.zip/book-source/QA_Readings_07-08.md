# Readings 07–08 verification

| Selection | Physical pages | Bookmarks | Contents links |
|---|---:|---:|---:|
| [7, 8] | 28 | 38 | 2 |
| [1, 2, 3, 4, 5, 6, 7, 8] | 105 | 138 | 8 |
| [8, 7] | 19 | 24 | 2 |

Each PDF matched its composed page count with zero measured overflows or JavaScript errors. The reversed 8,7 export used alternate font metrics and excluded revision sections. Chromium rendered the actual PDFs. The 28-page pair was visually inspected, and all four revision cards for each reading fit on one page. The cumulative PDF contains embedded Amiri for earlier Arabic-script passages.

All paragraphs, headings, lists and source table cells were checked against the supplied Drive explainers. Each reading contains seven main sections, six revision sections, five in-context and collected memory aids, and six examination questions. The six preceding chapter files and shared design and compositor were byte-compared with the 01–06 source ZIP.

Reading 07 distinguishes the da‘i’s memoir from the explainer’s interpretation. Reading 08 flags the chronology of the “two-century resistance” phrase and the difference between the supplied readings’ 1073 and 1074 dates for Badr. These are source-based study notes. The original journal articles were not independently checked.

Next batch: 09–10. Reading 19 remains reserved.
