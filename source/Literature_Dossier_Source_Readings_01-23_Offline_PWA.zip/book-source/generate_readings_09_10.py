from pathlib import Path
import html, json, shutil, re
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parent

TYPES={'definition':'definition','concept':'concept','examtip':'examtip','mistake':'mistake','memory':'memory','highyield':'highyield'}

# Section data: {title, passages=[(narrative html, [type, label, note body])...]}
def pg(s, *notes):return {'html':s,'notes':[{'type':a,'title':b,'body':c} for a,b,c in notes]}
def S(title,*items):return {'title':title,'items':list(items)}
def table(head,rows):
    return '<table data-content-type="comparison" data-pagination="repeat-header"><thead><tr>'+''.join('<th>'+x+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table>'
def para(s):return '<p>'+s+'</p>'
def ol(items):return '<ol>'+''.join('<li>'+x+'</li>' for x in items)+'</ol>'

def build_reading(n,title,subtitle,thesis,secs,defs,keytable,memory,questions,summary,revision_cards,accent,source_id):
    sid=f's{n}'
    out=[f'<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{accent};">',
    '<div class="leaf"><div class="chapter-title-page">',
    f'<div class="reading-eyebrow">Reading {n:02d} · Literature Dossier</div><h1>{html.escape(title)}</h1>',
    f'<p class="subtitle">{html.escape(subtitle)}</p><hr class="gold-rule"/>',
    '<div class="opener-split"><div class="thesis-block"><p class="kicker">Central thesis</p>',
    para(thesis),'</div><div class="roadmap"><p class="kicker">In this reading</p><ol>',
    *[f'<li>{html.escape(sec["title"])}</li>' for sec in secs],'</ol></div></div>',
    f'<p class="source-cite">Source: supplied Drive explainer {n:02d} (Google Doc {source_id}). The original scholarly publication has not been independently checked; historical claims and rhetoric are attributed to the supplied account.</p>',
    '</div>']
    notes_count=0; note_types={}; novel_phrases=[]
    for i,sec in enumerate(secs,1):
        out.append(f'<div class="section" id="s{n}-{i}"><div class="section-number">§{n}.{i}</div><h2>{html.escape(sec["title"])}</h2><div class="section-body">')
        for k,item in enumerate(sec['items']):
            anchor=f's{n}-{i}-p{k}'
            out.append(f'<article class="passage" data-anchor="{anchor}"><div class="prose">{item["html"]}</div>')
            if item['notes']:
                out.append('<aside aria-label="Study notes for this passage">')
                for a,note in enumerate(item['notes']):
                    typ=note['type']; assert typ in TYPES
                    note_types[typ]=note_types.get(typ,0)+1
                    out.append(f'<div class="callout callout--{typ}" data-content-type="{typ}" data-note-id="s{n}-{i}-p{k}-n{a}" data-pagination="allow-split"><div class="tag">{html.escape(note["title"])}</div><p>{note["body"]}</p></div>')
                    notes_count+=1
                out.append('</aside>')
            out.append('</article>')
        out.append('</div></div>')
    out.extend(['</div><div class="revision-zone"><div class="revision-leaf">',f'<div class="revision-kicker">Reading {n:02d} · Revision &amp; recall</div>'])
    def rev(i,title,inner):
        return f'<div class="section" id="s{n}-rev-{i}"><div class="section-number">REV {i:02d}</div><h2>{title}</h2><div class="section-body">{inner}</div></div>'
    out.append(rev(1,'Chapter Summary',para(summary)))
    out.append(rev(2,'One-Page Revision Sheet','<div data-pagination="keep-together"><div class="revision-grid">'+''.join(f'<div class="revision-card"><h3>{h}</h3><p>{b}</p></div>' for h,b in revision_cards)+'</div></div>'))
    out.append(rev(3,'Key Definitions',table(['Term','Meaning in this reading'],defs)))
    out.append(rev(4,'Key Tables',keytable))
    out.append(rev(5,'Memory Aids','<div class="callout-grid">'+''.join(f'<div class="callout callout--memory" data-content-type="memory" data-pagination="allow-split"><div class="tag">Memory aid · From §{n}.{sec} · {h}</div><p>{b}</p></div>' for sec,h,b in memory)+'</div>'))
    out.append(rev(6,'Possible Examination Questions','<div class="revision-grid exam-question-grid">'+''.join(f'<div class="exam-q"><span class="qtype">{category}</span><p>{question}</p></div>' for category,question in questions)+'</div>'))
    out.extend(['</div></div></section>'])
    fname=ROOT/'chapters'/(f'{n:02d}-'+('philosophy-of-language-medieval-arabic.html' if n==9 else 'black-muslim.html'))
    fname.write_text(''.join(out),encoding='utf-8')
    return {'chapter':n,'file':fname.name,'sections':len(secs),'notes':notes_count,'types':note_types,'passages':sum(len(s['items']) for s in secs)}

# Reading 09: intellectual stages distinguish model, debate, theoretical responses, and legal implications.
sections9=[
S('Baghdad: A Dispute over Who Can Know Truth',
 pg(para('The supplied account situates a disputation at a Baghdad vizierial court in <strong>937/938 CE</strong>. The Syriac Christian Aristotelian <strong>Abū Bishr Mattā</strong> defended logic, while the grammarian <strong>Abū Saʿīd al-Sīrāfī</strong> challenged its claim to be indispensable for reaching truth. The scene is simultaneously philosophical and social: Greek-derived sciences, Arabic scholarship, linguistic competence and religious identity competed for authority.'),
 ('highyield','High-yield · What was disputed?','Whether logic alone supplies a universal test of truth, or whether knowing and communicating require mastery of particular languages.')),
 pg(para('Al-Sīrāfī used Mattā’s Syriac identity and Christianity polemically, including a jab at the Trinity. The important analytical distinction is between the <em>ad hominem</em> setting of the debate and the substantive question: <strong>can intellectual content be separated from the language that expresses it?</strong> The supplied text narrates the encounter and its precise dating; it is not independently verified against the medieval record.'),
 ('examtip','Exam tip · Separate rhetoric and argument','Describe both the cultural hostility and the philosophical issue; do not treat personal attacks as a logical refutation.'))),
S('Two Models of Meaning: Three Terms or Two',
 pg(para('The <strong>Hellenic tripartite model</strong> links vocal sounds (<em>phônai</em>), mental contents (<em>noêmata</em>) and things (<em>pragmata</em>): words signify objects through what the mind understands. The Arabic <strong>bipartite account</strong> foregrounds <em>lafẓ</em> (vocal form) and <em>maʿnā</em> (mental content), connected in particular acts of linguistic use. The difference concerns what a theory must account for, not whether Arabic scholars knew that things exist.'),
 ('definition','Definition · Lafẓ and maʿnā','<em>Lafẓ</em>: a spoken expression; <em>maʿnā</em>: its intelligible meaning or mental content.'),
 ('memory','Memory aid · Three versus two','<strong>Greek: Sound → Thought → Thing.</strong> <strong>Arabic: Lafẓ ↔ Maʿnā.</strong>')),
 pg(table(['Question','Hellenic account','Arabic account'],[
 ['Elements','Sound · mental content · thing','<em>lafẓ</em> · <em>maʿnā</em>'],
 ['Reference','Object grasped through an intermediary mental content','Meaning of expression established through contextual use'],
 ['Intellectual source','Aristotelian <em>De interpretatione</em>','Arabic literary, grammatical and legal inquiry']
 ])),
 pg(para('The translation movement of the eighth and ninth centuries brought Greek concepts into Arabic discussions already shaped by Qurʾanic language, poetry and jurisprudence. The supplied account invokes Saussure as a <em>modern comparison</em>; it should not be mistaken for a historical influence upon the medieval authors.'),
 ('mistake','Common mistake · Saussure is retrospective','The modern comparison is an explanatory analogy, not a source used by the tenth-century disputants.'))),
S('Mattā: Logic as a Universal Balance',
 pg(para('For Mattā, logic distinguishes valid from invalid thought as a <strong>balance</strong> distinguishes unequal weights. His target is not the idiom of a single language but <em>maʿqūlāt</em>, the intelligibles that the mind can grasp regardless of whether a proposition is spoken in Greek, Syriac or Arabic. The supplied account illustrates that universality with the identity of <strong>4 + 4 = 8</strong> across languages.'),
 ('definition','Definition · Maʿqūlāt','Objects of intellection; what the mind understands independently of the particular spoken words.'),
 ('memory','Memory aid · The balance','<strong>Mattā = mental balance.</strong> A weighing instrument checks valid thought across languages.')),
 pg(para('The persuasive force of his view is its promise of cross-cultural knowledge. Its vulnerability, as al-Sīrāfī argues, is that a claim to universal thought still has to be formulated in a particular language. Thus the quarrel concerns whether grammar is an incidental wrapper or an essential condition of correct reasoning.'))),
S('Al-Sīrāfī: Grammar, Polysemy and the Trap',
 pg(para('Al-Sīrāfī treated Aristotelian logic as a Greek intellectual product, not a self-evident instrument superior to all linguistic traditions. He pressed the point that whenever someone argues, a <em>lafẓ</em> conveys the intended <em>maʿnā</em>. A logician unable to analyze the expression may misread the very relation he claims to judge.'),
 ('concept','Key concept · Language is not a removable wrapper','A claim can be formally tidy yet fail if the expression’s contextual meaning is misunderstood.')),
 pg(para('The test phrase <strong>“Zayd is one of his brothers”</strong> exposes a reflexive problem: a person cannot count as one of his own brothers in the intended construction. For al-Sīrāfī, Mattā’s difficulty is not simply bad pronunciation; it demonstrates how grammatical interpretation affects logical judgment.'),
 ('memory','Memory aid · Zayd tests logic','<strong>Zayd → expression → interpretation.</strong> A flaw in the wording can become a flaw in the judgment.')),
 pg(para('A further difficulty is <strong>polysemy and homonymy</strong>: limited vocal forms serve a rich, potentially unbounded range of meanings. Drawing on al-Jāḥiẓ in the supplied account, al-Sīrāfī reverses Mattā’s claim to exclusive expertise: grammar can be understood as a logic derived from Arabic usage, while logic itself requires language.'),
 ('definition','Definition · Polysemy','One expression can bear several related meanings; context helps select the intended sense.'),
 ('examtip','Exam tip · Explain rather than quote','Use the Zayd example and the finite-words/infinite-meanings problem to explain the objection to universality.'))),
S('Al-Fārābī: Insulating Reason through Nutq',
 pg(para('Al-Fārābī’s reply distinguishes <strong>interior discourse</strong> (<em>al-nuṭq al-dākhil</em>)—the apprehension and combination of intelligibles in the soul—from <strong>exterior discourse</strong> (<em>al-nuṭq al-khārij</em>), their vocal articulation in a historically particular language. On this account, logic governs underlying thought even when grammars differ.'),
 ('memory','Memory aid · In and out','<strong>Inside: intelligible thought. Outside: language.</strong> Al-Fārābī separates the logical faculty from its vocal expression.')),
 pg(para('The source further identifies three senses of <em>nuṭq</em> among “the ancients”: the intellectual faculty, intelligibles formed in the soul, and vocal expression. It criticizes the universal-grammar claim as a <strong>philosophical presupposition rather than a language-by-language empirical survey</strong>. This is the supplied author’s evaluation of the argument, not a reported experiment performed by al-Fārābī.'),
 ('mistake','Common mistake · Status of the claim','Distinguish al-Fārābī’s proposed universality from the source’s criticism that it was not empirically established.'))),
S('The Juristic Test: “From Wall to Wall”',
 pg(para('In the jurisprudential setting, the question is not only whether an inference is valid but <strong>what a legal utterance denotes in practice</strong>. The example is a contract granting land “from the wall to the wall.” Without conventions governing boundaries and usage, a syllogism cannot fix the exact portion conveyed.'),
 ('memory','Memory aid · The wall','<strong>Wall → wording → customary meaning.</strong> Legal interpretation must know how the language is used.')),
 pg(para('Al-Shāfiʿī’s earlier insistence that revelation addresses Arabs in their own language supplies background for the breadth of meanings that jurists must interpret. The example limits an overambitious claim for pure logic; it does <strong>not</strong> show that valid reasoning is useless to jurisprudence.'),
 ('mistake','Common mistake · Not “logic is useless”','The case exposes the limits of abstract formalism when a dispute depends upon legal-language conventions.'))),
S('Avicenna: The Necessary Study of Language',
 pg(para('<strong>Avicenna (Ibn Sīnā)</strong> accepts that the primary object of logic lies in the mind, but argues that vocal forms cannot simply be ignored: their patterns affect the patterns of mental content. The supplied account thus describes a synthesis in which precise reasoning requires attention to linguistic ambiguity rather than pretending that it can be bypassed.'),
 ('highyield','High-yield · The Avicennian shift','Logic stays oriented to thought but now investigates expressions because form influences understanding.')),
 pg(table(['Mode of indication','Arabic term','How meaning is indicated'],[
 ['Congruence','<em>mutābaqah</em>','Expression denotes its whole indicated meaning (triangle → three-sided figure).'],
 ['Implication / inclusion','<em>taḍammun</em>','Expression includes part of what is meant (shape within the concept of a triangle).'],
 ['Concomitance / entailment','<em>iltizām</em>','One idea evokes a necessarily related idea (ceiling → supporting wall in the supplied illustration).']
 ]),
 ('memory','Memory aid · Whole · Part · Link','<strong>Mutābaqah = whole; taḍammun = part; iltizām = linked implication.</strong>')),
 pg(para('The source then turns to <strong>al-Jurjānī</strong> and the “mental content’s mental content”: an expression may lead the interpreter from one meaning to another, making figurative language and allusion intelligible subjects of analysis. This extension matters because it relates logical structure to the dynamic interpretation of texts.'),
 ('concept','Key concept · Meaning can lead beyond itself','Interpretation can involve a second mental movement, not just a static word-to-object match.'))),
S('Resolution: Rival Methods Become Complementary',
 pg(para('The supplied narrative ends with collaboration rather than victory by either party. The madrasa setting enabled logic and Arabic linguistic sciences to operate together once their ethnic and political rivalry receded. Its central conclusion is methodological: <strong>formal inference must be joined to attentiveness to the language through which meanings are expressed</strong>.'),
 ('examtip','Exam tip · Give the intellectual sequence','Mattā claims universality → al-Sīrāfī challenges language-independence → al-Fārābī divides inner/outer discourse → Avicenna incorporates language into logic.')))
]
keytable9=table(['Stage','Main question','Contribution / limit'],[
 ['Mattā','Can logic assess thought universally?','Balance for <em>maʿqūlāt</em>; language treated as secondary.'],
 ['Al-Sīrāfī','Can thought be judged without grammar?','Context, polysemy, and Zayd expose language-dependence.'],
 ['Al-Fārābī','Can logic be separated from expression?','Interior/exterior <em>nuṭq</em>; universality remains a philosophical claim.'],
 ['Jurists','What does the contract actually mean?','Wall-to-wall example demands customary/legal usage.'],
 ['Avicenna → al-Jurjānī','How can thought include linguistic mediation?','Modes of indication and interpretive movements.']])
res9=build_reading(9,'Philosophy of Language in the Medieval Arabic Tradition','The War of Words: Logic, Grammar, and the Quest for Truth in Medieval Baghdad',
 'The quarrel between Mattā’s supposedly universal logic and al-Sīrāfī’s contextual grammar develops into a theory in which reason requires attention to language: al-Fārābī distinguishes inner from outer discourse, and Avicenna makes patterns of expression integral to logical analysis.',sections9,
 [('Lafẓ','Vocal form: the expression articulated in a particular language.'),('Maʿnā','Meaning or mental content conveyed by a vocal form.'),('Maʿqūlāt','Intelligible objects grasped by the intellect.'),('Polysemy','The capacity of a word to bear multiple meanings in use.'),('Nuṭq','Rational discourse; the source distinguishes faculty, interior thought and exterior speech.'),('Mutābaqah','Indication by congruence with the whole meaning.'),('Taḍammun','Indication by an included part of a meaning.'),('Iltizām','Indication by a necessarily related meaning.')],keytable9,
 [(2,'Three versus two','Greek model: sound → thought → thing. Arabic model: vocal form <em>lafẓ</em> ↔ meaning <em>maʿnā</em>.'),(3,'The balance','Mattā’s image: logic weighs good and bad reasoning across languages.'),(4,'The Zayd test','If “Zayd is one of his brothers” is misinterpreted, correct logic cannot be separated from correct language use.'),(5,'Inside / Outside','Al-Fārābī’s inner thought vs. expressed language.'),(6,'The wall','Legal meaning depends on convention, not formal inference alone.'),(7,'Whole · Part · Link','<em>Mutābaqah</em> = whole; <em>taḍammun</em> = part; <em>iltizām</em> = associated necessity.')],
 [('Short answer','State the two Arabic components <em>lafẓ</em> and <em>maʿnā</em>.'),('Comparison','Compare the tripartite and bipartite theories of meaning.'),('Argument','Explain Mattā’s balance metaphor and al-Sīrāfī’s objection to it.'),('Application','Why is the wall-to-wall legal contract difficult to decide by abstract logic alone?'),('Technical','Distinguish interior and exterior <em>nuṭq</em> in al-Fārābī.'),('Long essay','Explain how Avicenna and al-Jurjānī transform the logic–grammar conflict into a productive synthesis.')],
 'The supplied account dramatizes a tenth-century intellectual contest over whether universal thought can be detached from the language of its expression. Mattā’s “balance” treats logic as a cross-linguistic standard. Al-Sīrāfī counters with grammatical examples and ambiguous wording. Al-Fārābī protects logical universality through inner and outer <em>nuṭq</em>; the juristic wall example tests that distinction in legal practice. Avicenna then accepts that linguistic form affects mental content and organizes indication as congruence, inclusion and concomitance. Al-Jurjānī extends interpretation to successive levels of meaning. The conclusion is an interaction of formal logic and Arabic linguistic inquiry, not their simple replacement.',
 [('Core dispute','Universal rational rules versus language-dependent interpretation.'),('Model contrast','Three terms: sound / thought / thing; two terms: <em>lafẓ</em> / <em>maʿnā</em>.'),('Evidence to reproduce','Mattā’s balance, Zayd’s brothers, the legal boundary wall.'),('Synthesis','Interior/exterior <em>nuṭq</em>; Avicenna’s whole / part / linked meanings.')],'#7866A2','1gKkdrFAY2KU8nHL3Vrlv8a9bd3U3B3dgSYDMB13fBGY')

# Reading 10: retain the source's historical vocabulary with attribution and explanatory distance.
sections10=[
S('The Two-Edged Sword: Publicity Becomes a Platform',
 pg(para('The supplied account follows the <strong>Nation of Islam (NOI)</strong> during 1959–1961 through a paradox: media coverage designed to alarm the public also brought the movement’s message to a national audience. This was the “two-edged sword”—public hostility could become unsolicited publicity. Before this, recruitment relied heavily on conversations, neighborhood work and columns in papers such as the <em>Amsterdam News</em> and <em>Los Angeles Herald Dispatch</em>.'),
 ('concept','Key concept · Two-edged visibility','Hostile attention threatened reputation while simultaneously expanding the movement’s reach.'),
 ('memory','Memory aid · Attack → Attention','<strong>Attack → Attention → Audience.</strong> Publicity carried a message beyond its original supporters.')),
 pg(para('Journalist <strong>Louis Lomax</strong> approached the NOI about a television documentary for the Mike Wallace Show; Elijah Muhammad consented after questioning him. At the same time, doctoral researcher <strong>C. Eric Lincoln</strong> began investigating the movement, prompted by a Clark College student’s critique of racial hierarchy and Christianity. Documentary journalism and academic attention thus opened two routes from local organization to broader visibility.'),
 ('highyield','High-yield · The two catalysts','Lomax / television and Lincoln / scholarly investigation expanded public attention in 1959.'))),
S('The Hate That Hate Produced: Who Frames Whom?',
 pg(para('The late-1959 programme <em>The Hate That Hate Produced</em> presented disciplined mosque life, the Fruit of Islam and veiled or white-scarved Muslim women through an alarming visual frame. The programme’s “shock” montage, as the supplied account describes it, encouraged viewers to read the movement as dangerous. The account compares the reaction to an earlier radio panic; that comparison is a rhetorical analogy rather than measured evidence of equivalent public response.'),
 ('examtip','Exam tip · Analyze the frame','Name the broadcast and explain how selective images and hostile labels framed interpretation.')),
 pg(table(['Labels in the coverage','Their implied argument'],[
 ['“Hate-teachers,” “violence-seekers”','Portray NOI members as irrational aggressors rather than interpreters of grievances.'],
 ['“Black supremacists,” “Black fascists”','Make NOI seem a mirror image of white racial domination.'],
 ['“Anti-Christian,” “Communist-inspired”','Associate the movement with feared outsiders to discredit religious and political claims.']
 ])),
 pg(para('The important interpretive question is not whether these labels were objectively justified—the explainer does not independently adjudicate them—but how <strong>language of condemnation could make the movement visible</strong> to precisely the people it sought to address.'),
 ('mistake','Common mistake · Labels are attributed','The listed descriptions are <strong>media characterizations</strong>, not neutral descriptions adopted by these notes.'))),
S('House and Field: Malcolm X’s Critique of Established Leadership',
 pg(para('When reporters sought denunciations from established Black leaders, Malcolm X deployed the historical contrast between <strong>“house Negro”</strong> and <strong>“field Negro”</strong>. In his polemical analogy the house figure aligns with the master’s interests, while the field figure remains closer to the exploited majority. By 1960, he used this distinction to challenge respectable, institutionally recognized leaders whom he described as deferential to white power.'),
 ('definition','Definition · House/field rhetoric','Malcolm X’s contested political analogy distinguishing accommodation to power from opposition to it; not a neutral taxonomy of people.'),
 ('memory','Memory aid · Who benefits?','Ask <strong>who authorizes the leader, who benefits, and whom the leader represents</strong> in Malcolm’s critique.')),
 pg(para('Phrases such as “black bodies with white heads” and “Modern Uncle Thomas” belong to Malcolm’s confrontational rhetoric, <strong>not the narrator’s factual classification</strong>. The intellectual function of the passage is to show how the NOI claimed authority to speak for the disempowered while accusing rival organizations of dependence.'),
 ('mistake','Common mistake · Historical polemic ≠ objective fact','Present these categories as Malcolm X’s argument within the source, not an established description of all Black leadership.'))),
S('The Debate Stage: Reframing Hostile Questions',
 pg(para('As a principal spokesman, <strong>Malcolm X</strong> tried to regain control of interviews from hosts whom he believed loaded questions in advance. He rehearsed an opening identification with Elijah Muhammad and answered accusations through analogies rather than accepting the interviewer’s premise. As one intentionally provocative example, the source records him mentioning Hitler and Stalin in response to a question about a “good” white man, explaining the reference in terms of pressure to open factory work to Black people. This is presented as evidence of a confrontational rhetorical tactic, not praise or endorsement of either figure.'),
 ('concept','Key concept · Counter-framing','Refuse an accusation’s premise, substitute a different moral analogy, and redirect the audience to the underlying grievance.')),
 pg(para('His <strong>“wolf and sheep”</strong> and <strong>“snake-bitten”</strong> arguments turned the charge of hatred into a question of self-protection: those exposed to danger should not be condemned simply for warning others. On martial training, he compared public alarm about the NOI’s judo and karate with the social acceptance of the Boy Scouts or YMCA. The same activity, he argued, was treated differently depending on who performed it.'),
 ('memory','Memory aid · Three defensive answers','<strong>Wolf/snake → self-protection; judo → double standard; Bible critique → historical domination.</strong>')),
 pg(para('His criticism of Christian missionary language presented religion as an ideological instrument used to justify conquest and slavery. These arguments are claims attributed to Malcolm and to the narrative; their significance is how he moved discussion from accusations about the NOI to the social history of those accusing it.'),
 ('examtip','Exam tip · Distinguish strategy from endorsement','Explain what each analogy is meant to achieve. Attribute the speaker’s judgments rather than presenting them as uncontested historical conclusions.'))),
S('Separation and Segregation: A Doctrinal Distinction',
 pg(para('The movement insisted that <strong>segregation</strong> and <strong>separation</strong> were not interchangeable. In its argument, segregation is a hierarchy enforced by a dominant group upon a subordinated one; separation is a voluntary decision by equals to organize their own social, economic and institutional life. The contrast was central to its claim that independence could produce dignity and self-determination.'),
 ('definition','Definition · Segregation / separation','In the NOI framing, imposed inequality versus chosen autonomy. This is the movement’s ideological distinction, not a universal dictionary rule.'),
 ('memory','Memory aid · Forced versus chosen','<strong>Segregation = imposed control.</strong> <strong>Separation = claimed voluntary independence.</strong>')),
 pg(table(['Segregation (as characterized by NOI)','Separation (as characterized by NOI)'],[
 ['Imposed by a more powerful group; the subordinate group depends on its rules.','Chosen collective autonomy; members aim to govern their own institutions.'],
 ['Dependence for employment, housing or resources.','Locally owned businesses, trade and support networks.']
 ])),
 pg(para('The <strong>“mother and child”</strong> metaphor compared the decision to organize separately to birth: continued attachment becomes damaging once a child is ready to live independently. The metaphor reveals the movement’s desired understanding of autonomy; it does not by itself establish whether the proposed separation would work in every social circumstance.'),
 ('mistake','Common mistake · Different purposes','The supplied account explains the NOI’s distinction; do not flatten both terms into the same meaning.'))),
S('Rehabilitating the “Man in the Mud”',
 pg(para('For the movement, its most persuasive answer to hostile publicity was a claimed practical result: people struggling with addiction or incarceration were said to change their lives through disciplined belonging. The supplied account presents this as evidence the media could not explain. It is an <strong>organizational testimony</strong>, not a controlled evaluation of treatment outcomes.'),
 ('highyield','High-yield · Why rehabilitation matters','The narrative opposes negative labels to visible cases of change, arguing that practice communicates more powerfully than publicity.')),
 pg(ol([
 '<strong>Admission:</strong> acknowledge addiction.',
 '<strong>Causality:</strong> relate drug use to the pain of racial subordination, as taught by the movement.',
 '<strong>Possibility:</strong> learn that change is attainable.',
 '<strong>Self-image:</strong> rebuild a sense of personal agency.',
 '<strong>Withdrawal:</strong> attempt a “cold turkey” break with continuous support from other members.',
 '<strong>Salvage:</strong> those who recover recruit or support others.'
 ]),
 ('memory','Memory aid · Six-stage recovery chain','<strong>Admit → Cause → Possible → Self → Withdraw → Salvage.</strong> The last stage turns a beneficiary into a helper.')),
 pg(para('The account stresses the role of former addicts who could speak to newcomers in familiar language and the visible rejection of “lye-conked” hairstyles as a symbol of a transformed identity. These details tie the chapter’s practical claim back to its main theme: a change in <strong>self-definition</strong> preceding a change in action.'),
 ('concept','Key concept · Identity becomes practice','Self-respect, supportive discipline and mutual recruitment form the movement’s account of social rehabilitation.'))),
S('Expansion in 1961: Institutions and Costs',
 pg(para('By <strong>1961</strong>, the supplied narrative describes more businesses, religious institutions and schools. <em>Muhammad Speaks</em> publicized a proposed <strong>$20 million Islamic Center in Chicago</strong>. The “Universities of Islam” offered schooling through high-school level in Chicago and junior-high level in Detroit. These were signs of internal organization and claims to economic independence, distinct from outside media exposure.'),
 ('highyield','High-yield · 1961 institutional markers','A proposed Chicago Islamic center, member businesses, and schools feature in the source’s growth narrative.')),
 pg(para('Elijah Muhammad’s move to <strong>Phoenix</strong> because of bronchial asthma gave Malcolm X more day-to-day responsibility for public affairs, while drawing attention from surveillance officials. The account presents this as another double consequence of visibility: greater organizational autonomy and heightened scrutiny.'),
 ('memory','Memory aid · Growth has a shadow','<strong>Growth → leadership autonomy → surveillance.</strong> Public attention is never only beneficial.'))),
S('The Warning: Fame Can Destabilize a Movement',
 pg(para('The chapter closes by linking media hostility, internal success and the danger of individual celebrity. In the source, Elijah Muhammad warns Malcolm X that growing public stature can attract jealousy from within the movement. The irony is deliberate: the same visibility that enables recruitment may also threaten solidarity.'),
 ('examtip','Exam tip · The two-edged motif returns','In an essay, connect the original media paradox to the closing warning about celebrity and internal jealousy.')),
 pg(para('The central argument is therefore not simply “publicity caused growth.” The account insists that <strong>reframed identity, voluntary organization and rehabilitation</strong> allowed the NOI to turn publicity into a claim of legitimacy; publicity alone could never accomplish that work.')))
]
keytable10=table(['Issue','Hostile/public frame','NOI counter-frame in the supplied account'],[
 ['Television coverage','Movement presented as a threat','Attention spreads the message to potential supporters.'],
 ['Hate rhetoric','Opposition characterized as hatred','Self-defense justified through wolf and snake analogies.'],
 ['Community leadership','Established leaders asked to condemn','Malcolm’s house/field distinction challenges perceived accommodation.'],
 ['Separation','Critics read it as segregation','NOI presents it as voluntary self-determination.'],
 ['Social rehabilitation','Treatment successes not foregrounded','Visible reform of former addicts treated as proof of practical power.'],
 ['Celebrity','Publicity increases influence','Increased jealousy and surveillance can threaten unity.']])
res10=build_reading(10,'Black Muslim','The Two-Edged Sword: The Rise of the Nation of Islam and the Rhetoric of Identity',
 'The supplied narrative treats hostile media attention as a two-edged sword: public condemnation unexpectedly widened the Nation of Islam’s audience, but lasting growth depended upon its rhetoric of dignity, claimed separation from imposed hierarchy, internal institutions and visible examples of personal rehabilitation.',sections10,
 [('Nation of Islam (NOI)','The religious and social movement whose public emergence in 1959–1961 is examined.'),('Two-edged sword','Metaphor for publicity that both harms a reputation and amplifies a message.'),('Counter-framing','Answering a hostile label by changing the analogy or terms of debate.'),('Fruit of Islam','Organized NOI men whose discipline and appearance featured in the television coverage.'),('Segregation','In the movement’s rhetoric, externally enforced racial hierarchy.'),('Separation','In the movement’s rhetoric, voluntarily chosen social and economic autonomy.'),('House/field analogy','Malcolm X’s polemical classification of accommodation and opposition to racial power.'),('Fishing','The movement’s metaphor for recruitment, including by members who had reformed their lives.')],keytable10,
 [(1,'Attack → Attention','The “two-edged sword”: coverage intended to condemn also makes the movement visible.'),(3,'Who benefits?','Malcolm’s house/field analogy asks whom recognized leadership actually serves.'),(4,'Three defensive answers','Wolf/snake = protection; judo = double standard; Bible critique = historical instrument of domination.'),(5,'Forced versus chosen','Segregation is portrayed as imposed hierarchy; separation as voluntary autonomy.'),(6,'Six-stage chain','Admit → Cause → Possible → Self → Withdraw → Salvage.'),(7,'Growth has a shadow','Institutions → greater autonomy → heightened surveillance and jealousy.')],
 [('Short answer','Identify the two developments that increased publicity for the NOI in 1959.'),('Source analysis','How did the television documentary frame the NOI, and how did the movement reinterpret that attention?'),('Rhetoric','Explain how Malcolm X used the house/field contrast to challenge established Black leadership.'),('Comparison','Distinguish segregation from separation in the movement’s own terms.'),('Process','Reconstruct the six stages of the rehabilitation narrative and explain the role of former addicts.'),('Long essay','Why does the two-edged-sword image apply both to media exposure and the later dangers of fame?')],
 'The source traces the Nation of Islam’s emergence from local recruitment to national recognition in 1959–1961. Television and scholarship brought attention; a hostile documentary presented the movement through frightening labels. Malcolm X responded by challenging established Black leadership, reframing accusations through animal analogies, and differentiating forced segregation from claimed voluntary separation. The account then treats the rehabilitation of former addicts, schools and member-owned businesses as practical evidence of institutional change. Its closing warning about jealousy shows that visibility creates internal as well as external risks. Expressions quoted from the era are presented as historical rhetoric rather than adopted judgments.',
 [('Central paradox','Hostile publicity harmed reputation but enlarged the possible audience.'),('Rhetorical techniques','House/field critique; wolf/snake and self-defense responses; religious criticism.'),('Key distinction','Imposed segregation versus asserted voluntary separation.'),('Practical and political outcome','Six-stage rehabilitation, growth of businesses/schools, and the cost of celebrity.')],'#8B6653','1Cij3HEy-SB3oqt7BbkWgXnR-pLyL3OVV4YIO_ynWL_E')

# Original Google Docs text/plain exports are already preserved in sources/09-raw-explainer.txt and sources/10-raw-explainer.txt.
manifest={'batch':[9,10],'drive_ids':{'9':'1gKkdrFAY2KU8nHL3Vrlv8a9bd3U3B3dgSYDMB13fBGY','10':'1Cij3HEy-SB3oqt7BbkWgXnR-pLyL3OVV4YIO_ynWL_E'},'chapter_stats':[res9,res10],'design':'unchanged editorial sidebar 01-08','policy':'5 main pages target, 6 accepted; preserve source reasoning','source_exports':'original Google Docs text/plain export retained in sources/'}
(ROOT/'NEW_READINGS_09_10_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
