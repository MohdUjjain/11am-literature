# Final Assigned Reading 26 — Editorial, Print, Offline Publishing QA

**Reading:** *The Warmth of Other Suns: The History of America’s Great Migration (Part 2)*. **Source:** Google Drive `1e8u-QMahqmdsghXcJ7srajh_A-NHWz8Il_bvnVXgarw` (complete text, unchanged bytes archived as `sources/26-raw-explainer.txt`). This is a source-grounded explainer, not independently verified against Isabel Wilkerson’s original text.

## Editorial decisions

The chapter preserves the 1996 South Side Chicago framing scene; Ida Mae’s March 1913 birth and “Tom” nickname; Joseph Brandon’s 1923 death with the source’s *possible*, retrospective diabetic-coma reading; Mississippi’s cotton-shaped school calendar; Kirks’s Philadelphia whipping; Jim Crow’s everyday hierarchy, the cornmeal-barrel gunfire, well, shop-doorway and parking restrictions; the 1928 suitors Alfonso Banks and George Gladney; the 15 October 1929 marriage shortly before the stock-market crash; and the 1926 Carter brothers’ lynching and relatives’ movement to Milwaukee. The supplied excerpt does **not** date Ida Mae’s eventual northward journey and the notes deliberately do not infer a year or itinerary.

Initially composed to 5 main sheets with an almost blank final sheet. A duplicated comparison table was removed from the final body passage since the same evidence is already in the collected revision tables. Final: **four main sheets**, one opener, **five revision sheets** (six subsections), total **10 chapter sheets** within the cumulative PDF. Its standalone PDF also includes an independent cover, so that file has **11 sheets**. No compositor/CSS typography changes were made.

## Verifiable integrity

- **New reading:** 6 main sections, 12 anchored passages, **24 study cards**, six semantic types, **six in-situ memory cards identically collected** in revision, all six revision subsections, one main comparison table, and two revision evidence tables.
- **Full source preservation:** all **24 previous chapter files** and **6 fixed publisher/index files** (30 total) byte-for-byte match the verified preceding 01–25 ZIP. Original Drive source export is archived verbatim.
- **Full-volume browser compositor:** **269 composed pages**, zero overflows and JS errors. **24/24 new exact passage matches**; **512/513 total matches**, the one inherited Reading 04 exception `s4-6-n2` remains unchanged under offline font metrics. 390-pixel mobile horizontal overflow test passes.
- **Complete bookmarked PDF:** **269 physical sheets** (960 × 540 pt), **378 real hierarchical bookmarks**, **25 working Contents links**, outline-sidebar-on-open. The first four sheets (cover + 3 Contents pages) were printed from the freshly rebuilt full HTML, preserving the updated contents listing and cover; older material was copied from the certified 259-sheet PDF, and the 10 new chapter sheets from the validated 11-sheet standalone PDF after removing its redundant cover. `publish_incremental_26.py` publishes this format reproducibly from these three inputs and validates links and bookmarks. The monolithic Chromium PDF export exceeded the session limit, therefore a false single-shot success is not claimed.
- The PWA service-worker version was incremented to **`11am-lit-reader-01-26-v4`**, enabling installed apps to install/activate a new complete HTML cache. The large PDF remains an optional download, not part of the automatic cache.

The source editor and print engine are unchanged; `head-template.html` was updated only to refresh OpenGraph metadata for the current edition.

### Alternate-font stress caveat

The 390-px mobile and deployed offline-font metrics both pass. A deliberately divergent fallback-font *metric-stress* export was attempted and the existing strict compositor refused to place the in-text `s26-3-p1-n1` memory aid on its anchor page. The previous reading chapter and shared compositor were not altered to mask this result. The delivered PDF uses the validated offline-font profile, and all 24 cards align under that profile; exact geometry may vary with different font availability. This is a known stress-test limitation rather than a claim that every possible font fallback is verified.
