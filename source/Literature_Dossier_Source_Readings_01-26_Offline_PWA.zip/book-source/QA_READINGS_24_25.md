# Readings 24–25 — Editorial, PDF and PWA Release QA

Date: 2026-11-05. Based solely on archived, unchanged Google Drive explainers `sources/24-raw-explainer.txt` and `sources/25-raw-explainer.txt`; academic originals were not independently checked.

## Editorial report

- Reading 24 **Fāṭimid Archivalia**: six main sections, **four main-note pages**, six full revision sections (five dark sheets); **23** passage-linked sidebar cards; **six** memory aids, identical in text to their revision counterparts. Preserves the lost/extant/fragment status of the eight evidence rows, the Vienna codex folio 185v line 8, sijillāt/mukhlaqāt/tawqīʿāt functions, and four different documentary survival paths.
- Reading 25 **Al-Muʿtaṣim and Abū Tammām**: six main sections, **four main-note pages**, six revision sections (five dark sheets); **24** sidebar cards; **seven** duplicated-in-revision memory aids. Preserves contradictory reception narratives, officials and roles, Zibatra/Amorium and conspiracy, name-pun, four oppositions, and line 52(ii)/68/70 argument.
- The initial five-page main-body layouts each ended with nearly empty continuation pages. A **controlled editorial reduction of redundant concluding prose** removed both, without modifying typography, shared CSS, tables, compositor code or revision content.

## Tests

| Test | Final result |
| --- | --- |
| New pair physical/composed pages | **22 / 22** |
| Standalone Reading 24 PDF pages | 11 (cover + contents + opener + 4 main + 5 revision) |
| Standalone Reading 25 PDF pages | 11 (same structure) |
| Complete twenty-four-reading PDF | **259 physical / 259 composed** |
| Full PDF real bookmarks | **364** |
| Full PDF internal Contents links | **24** |
| Pair bookmarks and Contents links | 30 bookmarks; 2 links |
| New sidebar cards with exact passage alignment | **47 / 47** |
| Complete sidebar cards with exact passage alignment | **488 / 489** |
| Inherited exception | Reading 04 `s4-6-n2` under offline font metrics |
| Five/six revision categories and mnemonic parity | **Six revision sections, six semantic colors per chapter; all 13 new mnemonic cues repeated** |
| Alternate font-metric export | 23 pages; passed |
| Reversed chapter order (25,24) | 22 pages; passed |
| Mobile 390px scroll width | 390px (no horizontal overflow) |
| Compositor clipping/browser errors | None detected |
| Previous chapters and shared publishing files | 27 source hashes identical to previous archive |
| Independent ZIP extraction/rebuild | Published index.html byte-identical |

## Publishing and offline caution

The HTML remains a single-file self-contained reader, with service-worker core precaching of the page/manifest/icons. App cache version: `11am-lit-reader-01-25-v3`; original PDF intentionally not auto-cached. Browser may evict cached data. Local HTTP service-worker testing in this container was blocked by Chromium policy (`net::ERR_BLOCKED_BY_ADMINISTRATOR`), so **real-device offline launching was not independently verified in this release**; existing tested service-worker logic is retained with only the cache version and chapter count changed. Online GitHub read-back and live-URL checks must be reported separately after publication.

The underlying Google Drive explainers (not primary readings) are the basis for the study content, and references to political motives, anonymous source transmission, and quoted contemporary accounts are presented as the explainer’s claims rather than independently established external facts.
