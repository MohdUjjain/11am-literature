# GitHub Pages / offline app publishing

The project Pages site is built from this modular book source. The `head-template.html` contains the PWA manifest link, install/offline controls, and the registration code. The JS print compositor and CSS design system are unchanged.

Rebuild the single-file `index.html` from the `book-source` folder:

```sh
python build.py --out index.html
```

Copy that `index.html`, `pwa/service-worker.js`, `pwa/manifest.webmanifest`, `pwa/icons/` and `.nojekyll` to the repository root. Do not auto-cache the full PDF. Make sure the Pages branch is `main` / `(root)`. On future updates bump the service worker VERSION and test offline reload after an online visit.

Offline cache: complete built HTML (all presently completed readings), app manifest, app icons. Google Fonts are attempted as optional runtime cache assets, not stored in repo. Browser cache eviction remains possible.

## Final assigned reading checkpoint (5 November 2026)

Reading 26 is integrated: 25 assigned/completed readings, 19 reserved. Cache `11am-lit-reader-01-26-v4`; full reader inside `index.html`, no PDF precache. Cumulative PDF 269 pages, 378 bookmarks, 25 working Contents links. Source editor and offline compositor unchanged; see `QA_READING_26.md`.
