#!/usr/bin/env python3
"""Controlled editorial module generation for sourced readings 24–25.
Only new chapter/source files are produced. Shared publisher untouched.
"""
from pathlib import Path
import html, json, re, shutil, hashlib
ROOT=Path(__file__).resolve().parent
CH=ROOT/'chapters'
SRC=ROOT/'sources'

def T(head, rows):
    def c(tag,s):return f'<{tag}>{s}</{tag}>'
    return '<table data-content-type="comparison" data-pagination="repeat-header"><thead><tr>'+''.join(c('th',h) for h in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(c('td',x) for x in row)+'</tr>' for row in rows)+'</tbody></table>'

D={
 24:dict(
   slug='24-fatimid-archivalia-narratives-documents', color='#7B678D',
   title='Fāṭimid Archivalia: Narratives and Documents in Late Fāṭimid Egypt',
   subtitle='The Living Archive: How Chronicles, Chancery Papers and Geniza Fragments Preserved a Dynasty',
   thesis='The source challenges the idea that Fāṭimid historical memory was simply erased after 1171. Earlier narratives and records survived through selective incorporation in later historiography, through chancery practice, religious transmission and the Cairo Geniza. Reconstructing the dynasty means tracing <em>how</em> documents were produced, circulated, re-used and preserved—not imagining one intact royal archive.',
   source='195zTII7oLX91Cxmq7G8sv6IRhmFNxaO0PKNVF27_-9M',
   sections=[
     ('The Archive as a Historical Argument',[
       ('<p>In the explainer’s opening anecdote, al-Muʿizz enters Cairo in <strong>973</strong> and answers a challenge to his ʿAlid lineage with a sword—<em>Dhū l-Fiqār</em>—and coins inscribed with Shīʿī formulae. Sword and money make legitimacy visible. Yet a third form of power is central to the article: <strong>writing</strong>. Chancery decrees, commemorative narratives and historical compilations could make Fāṭimid claims legible long after a ruler died.</p>',[
          ('concept','Three media of sovereignty','Sword signifies force, coin material success, and archive the durable claim to authority.'),
          ('memory','Memory · Sword / Coin / Script','<strong>Force → prosperity → inscription</strong>: three routes by which sovereignty becomes recognizable.')]),
       ('<p>Borrowing an archival vocabulary associated with Jacques Derrida, the account treats “archivalia” as the <strong>transmission and reframing of recorded memory</strong>. The loss of one royal library does not mean the loss of Fāṭimid history: writing reached Ayyubid and Mamluk books, religious collections and reused paper. Each chain of custody must be assessed for its perspective.</p>',[
          ('definition','Archivalia / percolation','Records and narratives survive by passing through later acts of selection, copying and citation.'),
          ('mistake','Survival ≠ intact archive','A later quotation may preserve lost writing; it is not proof that its original institutional archive survives.')])]),
     ('Who Framed the Fāṭimid Past?',[
       ('<p>The dynasty’s move from the Maghrib to Egypt invited different ways of writing the past. <strong>Al-Quḍāʿī</strong> (d. 1062), a vizieral official, offered an Egypt-centered account of the earlier Egyptian period. <strong>Al-Maqrīzī</strong> (d. 1442), in <em>Ittiʿāẓ al-ḥunafāʾ</em>, integrated Maghribi origins with the Egyptian history. <strong>Ibn Taghrībirdī</strong> (d. 1470) inserted Fāṭimid regnal years into a wider Islamic chronicle. Each frame defines the scope of “Fāṭimid history” differently.</p>',[
          ('highyield','Three historical scales','Al-Quḍāʿī: Egyptian; al-Maqrīzī: Maghrib + Egypt; Ibn Taghrībirdī: wider Islamic history.'),
          ('examtip','Compare historical frames','Explain what each chronology highlights and obscures, not just the authors’ dates.')]),
       ('<p>The <strong>Cairo Geniza</strong> supplies a contrasting perspective. The source calls it an “anti-archive”: documents lodged in a Fustat synagogue survived often <em>by default</em>, not because a state designed them as monuments to its own rule. Their petitions, commercial details and transregional connections help reconstruct administration and society beyond the official courtly voice. This contrast is one of <strong>archive-making purposes</strong>, not a simple claim that official evidence is false and Geniza evidence true.</p>',[
          ('definition','Geniza as anti-archive','A non-state repository preserving everyday papers by customary accumulation rather than royal selection.'),
          ('memory','Memory · Court / Community','<strong>Court chronicles</strong> narrate rule; <strong>Geniza fragments</strong> reveal transactions and contacts below it.')])]),
     ('The Destruction Myth and the Survival Map',[
       ('<p>Against the idea of a total archival break at the Ayyubid conquest of <strong>1171</strong>, the explainer highlights the later chroniclers <strong>Ibn al-Furāt</strong> and <strong>al-Maqrīzī</strong>, who transmitted material from lost Fāṭimid-era works. Even hostile writing survived: the polemicist <strong>Akhū Muḥsin</strong> supplied allegations against Fāṭimid descent. Later authors could reproduce these charges while contesting their truth. Survival of a polemic illustrates the breadth of the record, <em>not</em> independent confirmation of its accusations.</p>',[
          ('mistake','Do not equate copying with endorsement','A chronicler may transmit Akhū Muḥsin’s anti-Fāṭimid claims in order to discuss or reject them.'),
          ('concept','Later books as archives','Mamluk compositions can preserve verbatim or adapted remnants of vanished earlier texts.')]),
       ('<p>The late-Fāṭimid corpus mixes surviving works, lost works quoted later, and an unusual extant fragment. An “insider” with chancery experience could provide detailed institutional observation; an outsider or memoirist could contribute a different angle. Classify each text by <strong>survival status, date and route</strong>, not merely its title.</p>'+T(['Earlier author / work','Survival','Transmission or importance'],[
         ('Ibn Abī l-Ṣalt, <em>al-Risāla al-Miṣriyya</em>','Lost','Egypt c. 1096–1110; fragments via al-Maqrīzī'),
         ('Ibn al-Ṣayrafī, annalistic history','Lost','Known from Ibn al-Dawādārī'),
         ('Ibn al-Ṣayrafī, <em>al-Ishāra</em>','Extant','Viziers, 991–1125; read by Ibn al-Furāt and others'),
         ('Al-Muḥannak, <em>Taʾrīkh khulafāʾ Miṣr</em>','Lost','Underlying Ibn Muyassar and later al-Maqrīzī'),
         ('ʿUmāra al-Yamanī, <em>al-Nukat al-ʿaṣriyya</em>','Extant','Memoirs/visiers; used by Ibn Wāṣil and others'),
         ('Ibn al-Maʾmūn, <em>Sīrat al-Maʾmūn</em>','Lost','Via Ibn Ẓāfir, Ibn Muyassar and al-Maqrīzī'),
         ('Ibn Ṭuwayr, <em>Nuzhat al-muqlatayn</em>','Lost','Eyewitness 1121–60; later preserved in chronicles'),
         ('Anonymous, <em>Akhbār al-dawla al-Miṣriyya</em>','Surviving extract','History 1101–74 via Ibn al-Furāt')]) ,[
          ('highyield','Status is part of the evidence','“Extant,” “lost but quoted,” and “surviving extract” are different levels of access.'),
          ('memory','Memory · E / L / F','<strong>E</strong>xtant text; <strong>L</strong>ost but transmitted; <strong>F</strong>ragment embedded in later work.')])]),
     ('Vienna Codex and the Moment of Quotation',[
       ('<p>The clearest physical case is <strong>Vienna Cod. A. F. 117</strong>, volume three of Ibn al-Furāt’s <em>Taʾrīkh al-duwal wa-l-mulūk</em>. According to the supplied explainer, the sole known transcription of the anonymous <em>Akhbār al-dawla al-Miṣriyya</em> is embedded there. Its text begins at <strong>folio 185v, line 8</strong>: a visible point where a later historian’s account gives way to earlier written testimony. This is evidence of <strong>embedded preservation</strong>, not the rediscovery of the anonymous author’s whole original book.</p>',[
          ('highyield','Vienna A. F. 117: 185v, line 8','A precisely located passage documents how the anonymous <em>Akhbār</em> survives through Ibn al-Furāt.'),
          ('examtip','What does a manuscript witness prove?','It proves the passage was copied in this witness; chronology and completeness still require argument.')]),
       ('<p>Separate <strong>event, original written testimony, later selection and surviving manuscript</strong>. Their dates may differ, and a copied excerpt is not a neutral window onto the event.</p>',[
          ('memory','Memory · Event → Account → Copy','Trace <strong>event → written witness → later compilation → surviving manuscript</strong>.'),
          ('mistake','Don’t collapse dates','Event date, original text date and extant codex date are different analytical questions.')])]),
     ('Sijillāt, Petitions and the Life of State Paper',[
       ('<p>Documentation was also an active political instrument. <em>Sijillāt</em> designated official communications and instructive caliphal declarations; <em>mukhlaqāt</em> were festival communications to provincial governors; and <em>al-tawqīʿ ʿalā al-qiṣaṣ</em> described decrees/rescripts answering petitions. The reply to a petitioner presented the Imam-Caliph as supreme guardian of the vulnerable, while festival correspondence projected his presence beyond Cairo.</p>'+T(['Document form','Principal function'],[
         ('<em>Sijillāt</em>','Official announcements and guidance, including religious/emergency communication'),
         ('<em>Mukhlaqāt</em>','Festive dispatches to provincial officials, extending caliphal ritual presence'),
         ('<em>Tawqīʿ ʿalā al-qiṣaṣ</em>','Ruling in response to a petition; public enactment of justice')]),[
          ('definition','Sijill / tawqīʿ / mukhlaqa','Keep imperial announcements, petition-rescripts and festival dispatches distinct.'),
          ('memory','Memory · Declare / Celebrate / Decide','<strong>Sijill</strong>: declare; <strong>mukhlaqa</strong>: celebrate; <strong>tawqīʿ</strong>: decide a plea.')]),
       ('<p>High-quality <em>sulṭānī</em> paper in the Geniza implies a life cycle of production, use, disposal and reuse. Four survival paths emerge: <strong>original decrees</strong> (such as material at St Catherine’s in Sinai), <strong>Geniza fragments</strong>, <strong>state copies</strong>, and <strong>literary transcripts</strong> within chronicles or Tayyibī devotional collections. Even reused scraps can witness state administration.</p>',[
          ('concept','Four routes of survival','Originals; Geniza fragments; official copies; excerpts in historical or devotional books.'),
          ('examtip','Treat recycling as evidence','Paper’s second life helps explain survival without imagining a complete centralized repository.')])]),
     ('Men of the Pen and the Meaning of Continuity',[
       ('<p><strong>Ibn al-Ṣayrafī</strong> wrote chancery decrees and later recounted the viziers and Imams, aligning official records with sovereign self-representation. Geniza petitions instead reveal daily power—including the vizier <strong>al-Afḍal</strong>’s practical influence. Both perspectives are necessary.</p>',[
          ('concept','Top-down / bottom-up','Chancery history displays authority; transactional evidence tests how that authority worked.'),
          ('highyield','The article’s answer','Fāṭimid “writerly culture” survived through reused documents and later historiographical transmission.')]),
       ('<p>The archive was neither erased nor flawlessly preserved. <strong>Selection, copying, dispute and reuse</strong> made Fāṭimid writing survive in a partial but revealing textual afterlife.</p>',[
          ('memory','Memory · No archive ≠ no memory','<strong>Lost collection ≠ lost contents:</strong> ask where the narratives and documents traveled.')])])
   ],
   summary=[
      'The chapter disputes a simple “lost Fāṭimid archive” model. It understands <em>archivalia</em> as transmission through later chronicles, official copies, Geniza reuse, and religious collections. Preservation is selective; later quotation is not automatically neutral or complete.',
      'Al-Quḍāʿī, al-Maqrīzī and Ibn Taghrībirdī organized the dynasty in different spatial and chronological frames. The Geniza supplies a non-state archive of daily petitioning and transactions. Together they offer multiple, sometimes competing standpoints.',
      'The Vienna codex containing Ibn al-Furāt’s extract of the anonymous <em>Akhbār</em> gives a concrete point of textual preservation (185v, line 8). State forms such as <em>sijillāt</em>, <em>mukhlaqāt</em> and <em>tawqīʿāt</em> show documents acting as instruments of sovereignty before entering the archive.'
   ],
   sheet=[('Core thesis','The archive survives through mediation, not necessarily as one intact Fāṭimid library.'),('History frames','Al-Quḍāʿī: Egypt; al-Maqrīzī: integrated dynasty; Ibn Taghrībirdī: universal chronology.'),('Counter-archive','Geniza fragments preserve ordinary contacts and cases, often by default.'),('Destruction myth','Ayyubid 1171 does not entail the erasure of earlier narratives.'),('Transmission','Extant works, lost works quoted later, and embedded fragments must be distinguished.'),('Case study','Vienna Cod. A. F. 117, Ibn al-Furāt, fol. 185v line 8.'),('Chancery','Sijillāt, mukhlaqāt, tawqīʿ ʿalā al-qiṣaṣ.'),('Paper life','Administrative production → use → retention/disposal → reuse.'),('Interpretation','Official self-image and Geniza practice are complementary, not identical.')],
   definitions=[('Archivalia','Transferred and recontextualized records that preserve past writing'),('Percolation','Survival of older content through later authors’ copying and compilation'),('Cairo Geniza','Synagogue repository containing reused or deposited documentary materials'),('Anti-archive','Material accumulating outside a designed state memorial system'),('Sijillāt','State communications and proclamations'),('Mukhlaqāt','Festive communications to provincial officials'),('Al-tawqīʿ ʿalā al-qiṣaṣ','Rescripts answering petitions'),('Sulṭānī paper','High-quality government-associated paper'),('Chancery','Bureaucratic office producing formal state documents'),('Akhbār al-dawla al-Miṣriyya','Anonymous late-Fāṭimid narrative surviving as a later extract')],
   tables=[T(['Survival mechanism','Example','What it proves'],[
      ('Later chronicle','Ibn al-Furāt, al-Maqrīzī','Earlier narrative survives within newer history'),('Manuscript quotation','Vienna A. F. 117','A precise witness to a transmitted anonymous passage'),('State record','Sijill / tawqīʿ','Official writing enacted and recorded authority'),('Geniza reuse','Discarded government paper','State documents can outlive the state outside royal custody'),('Religious archive','Tayyibī caliphal letters','Devotional communities could preserve state correspondence')]),
      T(['Historian','Frame','Implication'],[('Al-Quḍāʿī','Egypt-centered','Earlier Egyptian state history'),('Al-Maqrīzī','Maghrib and Egypt','Integrated dynasty narrative'),('Ibn Taghrībirdī','Regnal years in broader Islam','Cross-dynastic chronology')])],
   questions=[('Thesis','What does “archivalia” add to the claim that the Fāṭimid archives were destroyed?'),('Method','Why is a later chronicle both a valuable source and a risky witness?'),('Comparison','Contrast an official chancery record with Cairo Geniza material.'),('Evidence','Why are Vienna A. F. 117 and folio 185v line 8 important?'),('Terms','Distinguish sijillāt, mukhlaqāt and tawqīʿ ʿalā al-qiṣaṣ.'),('Evaluation','What can the presence of Akhū Muḥsin’s polemic in later histories establish—and what can it not?'),('Context','Compare al-Quḍāʿī, al-Maqrīzī and Ibn Taghrībirdī as framers of Fāṭimid history.'),('Synthesis','Explain “written authority” using the court and Geniza together.')]
 ),
 25:dict(
   slug='25-mutasim-bridge-toil-abu-tammam-amorium', color='#916A57',
   title='Al-Muʿtaṣim’s “Bridge of Toil” and Abū Tammām’s Amorium Qaṣīda',
   subtitle='Sword, Scripture and Poetry: Turning a Troubled Military Victory into Legitimate Power',
   thesis='The supplied account reads Abū Tammām’s Amorium qaṣīda as more than a poem praising the victory of 223/838. Its antitheses recast an army’s success—and the purge of disloyal officers—as proof of the caliph’s providential mission. The “bridge of toil” and the comparison with Badr lend sacred legitimacy to al-Muʿtaṣim’s newer military order.',
   source='1h_qtzjbStTlqNEx7sTyvDP3ce3etK_q53aPNHBC-3q4',
   sections=[
     ('A Victory Poem the Caliph Did Not Readily Welcome',[
       ('<p>The source begins with a paradox: the pragmatic soldier-caliph <strong>al-Muʿtaṣim</strong> (r. 218–227/833–842) needed the public meaning a poet could give to his victories, but reportedly cared little for the demanding <em>badīʿ</em> art of <strong>Abū Tammām</strong>. Accounts disagree in texture. Ibn Khallikān says the poet recited his <em>Amorium qaṣīda</em> over three days to win payment. Al-Ṣūlī remembers the caliph disliking the poet’s hoarse voice and allowing another man to recite; the caliph gave silver while <strong>Isḥāq b. Ibrāhīm</strong> later rewarded him in gold. These <em>reception stories</em> differ.</p>',[
          ('concept','Reception is contested','Ibn Khallikān and al-Ṣūlī preserve differing reports of the poet’s hearing and reward.'),
          ('memory','Memory · Silver / Gold / Poem','Caliph: reportedly <strong>silver</strong>; discerning patron: <strong>gold</strong>. Ask who recognized the poem.')]),
       ('<p>The caliph’s taste reportedly favored lighter lyrics by <strong>Ibn Jāmiʿ</strong> and <strong>al-Ḥusayn b. al-Ḍaḥḥāk</strong> rather than tight dialectical argument. He admired an accessible line in Abū Tammām’s accession poem. Thus the critic’s problem is not “why was the poet brilliant?” but <strong>why such difficult verse mattered politically</strong> to a martial court. The poem’s larger audience included educated counselors and officials who could translate stylistic ingenuity into legitimacy.</p>',[
          ('definition','Badīʿ','Elaborate literary figures and conceptual ingenuity in poetry; not identical with light courtly lyric.'),
          ('examtip','Thesis beyond praise','Distinguish the ruler’s own taste from what the new regime needed its public poetry to accomplish.')])]),
     ('The New Men Behind the Throne',[
       ('<p>A group of officials linked the poet to a regime increasingly dependent on professional soldiers and politically agile administrators. The source’s term <strong>“new men”</strong> points to powerful figures with fewer traditional dynastic credentials, whose patronage helped make cultural capital a complement to military coercion. The <em>qaṣīda</em> therefore had an institutional audience beyond the caliph’s private pleasure.</p>'+T(['Official','Position in source','Connection with poet'],[
        ('Aḥmad b. Abī Duʾād','Chief qāḍī and counselor','Intellectual audience; helped persuade the caliph to listen'),
        ('Isḥāq b. Ibrāhīm al-Muṣʿabī','Spymaster/governor','Patron who appreciated and rewarded the poem'),
        ('Al-Ḥasan b. Wahb','Kātib in the vizieral circle','Partisan of Abū Tammām’s skill; connected to Ibn al-Zayyāt')]),[
          ('highyield','Political value of literary patronage','Counselors and secretaries, not just the caliph, made sophisticated praise usable.'),
          ('memory','Memory · Judge / Spy / Scribe','<strong>Judge</strong> Ibn Abī Duʾād; <strong>spy</strong> Isḥāq; <strong>scribe</strong> al-Ḥasan b. Wahb.')]),
       ('<p>The distinction helps explain the reported tension between poetic merit and its reception. <strong>Al-madhhab al-kalāmī</strong>—a dialectical method exploiting oppositions and arguments—could make a single military deed intelligible as an episode of world history and theological justice. That interpretive work might be lost on a listener seeking an uncomplicated song, but prized by officials responsible for articulating a caliphate’s public image.</p>',[
          ('definition','Al-madhhab al-kalāmī','A style using reasoning and pointed antitheses to build poetic argument.'),
          ('mistake','Court ≠ ruler alone','Different men at the same court could respond very differently to the same qaṣīda.')])]),
     ('Amorium, Prophecy and the Purge of 223/838',[
       ('<p>The campaign against <strong>Amorium</strong> (223/838) is framed as retaliation for the Byzantine attack on <strong>Zibatra</strong> and a legend about a captive woman’s appeal. The source describes al-Muʿtaṣim dramatizing his resolve: setting aside a wine goblet until his return and attaching shackles, a plowshare and provisions to his saddle. These anecdotes represent how the campaign was narrated as the commitment of a <em>ghāzī</em> (holy warrior); they are not neutral proof that every reported gesture occurred precisely as told.</p>',[
          ('concept','Campaign as staged resolve','The vow and saddle objects translate a military plan into a publicly meaningful commitment.'),
          ('definition','Ghāzī','Warrior framed as fighting in a religiously justified campaign.')]),
       ('<p>Counter-signs haunted the expedition. Astrologers invoked a western comet, and Byzantine diplomatic <em>kutub</em> (letters) allegedly mocked the prospect of success, predicting the city would fall only when fig and grape ripened. Yet a more dangerous rupture was internal: disaffected eastern Iranian officers plotted to put <strong>al-ʿAbbās b. al-Maʾmūn</strong> on the throne. According to the explainer, some <strong>seventy officers</strong> were tortured to death and al-ʿAbbās also died in the purge. A triumphant siege thus led into a politically ugly return march. The poem must convert that contradiction into a single story of rightful rule.</p>',[
          ('highyield','Two battles at once','Victory against Byzantium abroad; legitimacy crisis and purge at home.'),
          ('memory','Memory · Outer / Inner','<strong>Outer enemy:</strong> Amorium. <strong>Inner enemy:</strong> the al-ʿAbbās conspiracy.')])]),
     ('The First Antithesis: Sword Versus “Books”',[
       ('<p>The qaṣīda opens with the aphorism that the <strong>sword gives truer tidings than books</strong>. The statement is not a dismissal of all learning. In the source’s reading, “books” recalls Byzantine diplomatic writings and religious forecasts—and the astrologers’ discouraging predictions—against which the undeniable capture of Amorium stands as a decisive sign. Physical action defeats <em>particular</em> claims made by texts. The poet turns military outcome into a test of rival ways of knowing.</p>',[
          ('highyield','What are the “books”?','The source connects them with prophecy, astrology and Byzantine diplomatic claims, not knowledge in general.'),
          ('mistake','Not anti-intellectualism','The antithesis targets allegedly false predictions; the poem itself is intellectually intricate.')]),
       ('<p>Stories about the prediction that only <em>awlād al-zinā</em> (“illegitimate sons”) could capture the city sharpen the reversal. A reported retort makes the caliph’s Turks and non-Arab troops the very men who confound the prophecy. The discussion depends on a deliberately offensive slur found in the narrative: its historical role is to show how a hostile omen could be <strong>appropriated and inverted</strong> into confidence in the army that won.</p>',[
          ('concept','Poetic inversion','An enemy’s prediction is made to speak in favor of the army it meant to discredit.'),
          ('examtip','Interpret the opening line','Identify the books and the rhetorical reversal before claiming “action beats words.”')])]),
     ('The City, the Fire and the Poetic Contradictions',[
       ('<p>Abū Tammām plays upon <em>ʿAmmūriyya</em> (Amorium) and <em>maʿmūra</em> (flourishing or inhabited). The city appears as a proud, untouched female body, then is violently overcome. The poet’s image of a “black disaster” is contrasted with the glory claimed for the conquerors. These figures create an intentionally troubling texture: the same event is represented as <strong>devastation for one polity</strong> and <strong>deliverance for another</strong>. The imagery should be analyzed as rhetoric rather than accepted as unproblematic celebration.</p>',[
          ('concept','Name-pun and personification','ʿAmmūriyya/maʿmūra and the city-as-woman make conquest vivid and ideologically charged.'),
          ('memory','Memory · City / Fire / Light','<strong>City:</strong> personified; <strong>fire:</strong> destruction; <strong>light:</strong> victory’s asserted meaning.')]),
       ('<p>Contrasts drive the whole composition. Predictions and letters meet the blade; the burning city produces a “dawn of fire” alongside dark smoke; ritual purity and polluted violence shadow one another. The <em>badīʿ</em> technique does not simply decorate the story: it binds incompatible-looking facts into a coherent interpretation of power.</p>'+T(['Opposition','How it functions'],[
         ('Prediction / sword','Reported forecast is refuted by completed military deed'),
         ('Fire-light / smoke-darkness','Victory’s radiance accompanies the devastation it produces'),
         ('Sacred purpose / violence','Religious framing seeks to legitimate a coercive event'),
         ('Foreign war / domestic purge','One narrative of sovereignty must contain both')]),[
          ('memory','Memory · Four oppositions','<strong>Books/sword; light/dark; holy/violent; foreign/domestic.</strong> These power the poem.'),
          ('examtip','Form is not ornament','Show how antithesis does the political work of explaining contradictory events.')])]),
     ('The Bridge of Toil, Reckoning and Badr',[
       ('<p>At <strong>line 68</strong>, the caliph crosses a <strong>“bridge of toil”</strong> to reach God’s peace. The source relates this to eschatological passage and cites <strong>line 52(ii)</strong>, where al-Muʿtaṣim acts as <em>muḥāsib</em>—the “reckoner” assigning an account. This transforms march and campaign into something resembling a preparation for Last Judgment. The bridge is simultaneously military labor and a theological image: force becomes meaningful within a claimed divine accounting.</p>',[
          ('definition','Muḥāsib','A reckoner or one who calls another to account, here applied to caliphal action.'),
          ('memory','Memory · 52 / 68 / 70','<strong>52:</strong> reckoner; <strong>68:</strong> bridge of toil; <strong>70:</strong> Badr.')]),
       ('<p>At <strong>line 70</strong>, the poem invokes the <strong>“noble lineage of Badr”</strong>, comparing the victory with the Prophet’s earliest military triumph. In the explainer’s interpretation, that comparison helps confer religious standing upon a new army of Turkic soldiers, shifting legitimacy from discredited older eastern Iranian officers to service under the caliph.</p>',[
          ('highyield','Badr as legitimating analogy','A sacred military precedent is made to validate a new caliphal army and its commander.'),
          ('memory','Memory · Battle → Judgment → Badr','<strong>Conquest → divine accounting → Prophetic precedent</strong>: the poem’s political ascent.')])])
   ],
   summary=[
      'Abū Tammām’s Amorium <em>qaṣīda</em> is presented as a poetic response to the paradox of al-Muʿtaṣim’s regime: spectacular victory against Byzantium, paired with an internal conspiracy and violent purge. Divergent reports of the caliph’s reception of the poem show that the literary audience extended beyond the ruler himself.',
      'The poem deploys <em>al-madhhab al-kalāmī</em> and tightly organized oppositions. Its opening “sword versus books” overturns the particular Byzantine and astrological predictions that the city would not fall. Its personification of Amorium and its images of fire/light, purity/violence turn conflict into a purportedly coherent display of sovereignty.',
      'The “bridge of toil” in line 68, the <em>muḥāsib</em> in line 52(ii), and Badr in line 70 lift the campaign into a register of judgment and sacred precedent. The source argues that this helped legitimate the new Turkic military establishment against discredited older officers.'
   ],
   sheet=[('Central problem','How can a caliph celebrated for victory also be haunted by palace treachery?'),('Reception','Ibn Khallikān: three days; al-Ṣūlī: reluctance/substitute; Isḥāq rewards in gold.'),('Patrons','Aḥmad b. Abī Duʾād, Isḥāq b. Ibrāhīm, al-Ḥasan b. Wahb.'),('Campaign','223/838: Amorium; vows; prophecy; conspiracy involving al-ʿAbbās.'),('Opening maxim','Sword refutes specific books/omens, not learning as such.'),('Style','Badīʿ and al-madhhab al-kalāmī: dialectic, pun, personification, reversal.'),('City','ʿAmmūriyya/maʿmūra and a conquest imagined through violent personification.'),('Final architecture','Line 52(ii) reckoner → line 68 bridge of toil → line 70 Badr.'),('Thesis','Literature legitimizes the new military regime despite the purge.')],
   definitions=[('Qaṣīda','Extended formal ode; here a victory panegyric'),('Badīʿ','Dense rhetorical inventiveness, especially figuration and contrast'),('Al-madhhab al-kalāmī','Dialectical mode of poetic argument'),('Ghāzī','Warrior represented as fighting for religious ends'),('Amorium / ʿAmmūriyya','Byzantine city captured in 223/838'),('Maʿmūra','Flourishing / inhabited; used in the name-pun'),('Muḥāsib','One who calls to account, here imagined as the caliph'),('Badr','Early Muslim battle invoked as sacred precedent'),('Kātib','Secretary/literary administrator'),('Awlād al-zinā','Derogatory expression in the reported Byzantine prophecy'),('Al-ʿAbbās b. al-Maʾmūn','Caliphal nephew named in the alleged conspiracy')],
   tables=[T(['Element','Source detail','Political reading'],[
         ('Reception','Three-day recital or substituted reader; silver versus gold','Ruler’s taste differs from courtly intellectual needs'),
         ('Battle','Amorium, 223/838','Military victory seeks a public explanation'),
         ('Conspiracy','Officers and al-ʿAbbās','Foreign triumph threatened by internal instability'),
         ('Opening','Sword more truthful than “books”','Particular prophecies refuted by action'),
         ('Line 52(ii)','Muḥāsib, reckoner','Caliph as agent of accounting'),
         ('Line 68','Bridge of toil','Campaign refigured as sacred ordeal'),
         ('Line 70','Lineage of Badr','New army connected to Prophetic military legitimacy')]),
      T(['Who?','Court role','Poetic function'],[('Al-Muʿtaṣim','Caliph and campaign leader','Object and beneficiary of the ode'),('Aḥmad b. Abī Duʾād','Chief judge/counselor','Intellectual intermediary'),('Isḥāq b. Ibrāhīm','Governor/spymaster','Discerning patron'),('Al-Ḥasan b. Wahb','Secretary','Literary enthusiast')])],
   questions=[('Thesis','Why is the Amorium qaṣīda more than a report of military victory?'),('Sources','How do Ibn Khallikān and al-Ṣūlī differ about the court recital?'),('Politics','What does the al-ʿAbbās conspiracy add to the poem’s problem?'),('Close reading','Which “books” are challenged by the sword in the opening?'),('Rhetoric','Explain the name-pun and personification of Amorium.'),('Structure','How do lines 52(ii), 68 and 70 build a theology of victory?'),('Social history','What roles did the judges, secretaries and intelligence officials play in literary patronage?'),('Evaluation','How does comparing the new soldiers with Badr address the legitimacy of the caliph’s military shift?')]
 )
}

def render(n,d):
    memory=[]
    head=f'<section class="chapter" data-chapter="{n}" id="chapter-{n}" style="--chapter-accent:{d["color"]};"><div class="leaf">'
    toc=''.join('<li>'+html.escape(t)+'</li>' for t,_ in d['sections'])
    head+=f'<div class="chapter-title-page"><div class="reading-eyebrow">Reading {n} · Literature Dossier</div><h1>{d["title"]}</h1><p class="subtitle">{d["subtitle"]}</p><hr class="gold-rule"/><div class="opener-split"><div class="thesis-block"><p class="kicker">Central thesis</p><p>{d["thesis"]}</p></div><div class="roadmap"><p class="kicker">In this reading</p><ol>{toc}</ol></div></div><p class="source-cite">Source: supplied Google Drive explainer {n}, Google Doc {d["source"]}. Its reported events, arguments, quotations and document statuses are summarized as source claims; the underlying academic reading was not independently verified.</p></div>'
    for i,(title,passages) in enumerate(d['sections'],1):
        head+=f'<div class="section" id="s{n}-{i}"><div class="section-number">§{n}.{i}</div><h2>{title}</h2><div class="section-body">'
        for j,(prose,notes) in enumerate(passages):
            anchor=f's{n}-{i}-p{j}'
            head+=f'<article class="passage" data-anchor="{anchor}"><div class="prose">{prose}</div><aside aria-label="Study notes for this passage">'
            for k,(kind,title_,body) in enumerate(notes):
                assert kind in {'definition','concept','memory','examtip','mistake','highyield'}
                ident=f'{anchor}-n{k}'
                head+=f'<div class="callout callout--{kind}" data-content-type="{kind}" data-note-id="{ident}" data-pagination="allow-split"><div class="tag">{title_}</div><p>{body}</p></div>'
                if kind=='memory':memory.append((i,title_,body))
            head+='</aside></article>'
        head+='</div></div>'
    head+='</div><div class="revision-zone"><div class="revision-leaf"><div class="revision-kicker">Reading '+str(n)+' · Revision &amp; recall</div>'
    def rev(i,title,body):
        return f'<div class="section" id="s{n}-rev-{i}"><div class="section-number">REV {i:02d}</div><h2>{title}</h2><div class="section-body">{body}</div></div>'
    head+=rev(1,'Chapter Summary',''.join(f'<p>{x}</p>' for x in d['summary']))
    head+=rev(2,'One-Page Revision Sheet',T(['Anchor','Remember'],d['sheet']))
    head+=rev(3,'Key Definitions',T(['Term','Meaning in this reading'],d['definitions']))
    head+=rev(4,'Key Tables',''.join(d['tables']))
    head+=rev(5,'Memory Aids','<div class="callout-grid">'+''.join(f'<div class="callout callout--memory" data-content-type="memory" data-pagination="allow-split"><div class="tag">Memory aid · From §{n}.{i} · {title}</div><p>{body}</p></div>' for i,title,body in memory)+'</div>')
    head+=rev(6,'Possible Examination Questions','<div class="revision-grid exam-question-grid">'+''.join(f'<div class="exam-q"><span class="qtype">{typ}</span><p>{q}</p></div>' for typ,q in d['questions'])+'</div>')
    head+='</div></div></section>'
    path=CH/(d['slug']+'.html')
    path.write_text(head,encoding='utf-8')
    return {'chapter':n,'path':path.name,'sections':len(d['sections']),'passages':sum(len(x) for _,x in d['sections']),'cards':sum(len(y) for _,sec in d['sections'] for _,y in sec),'memory':len(memory),'bytes':path.stat().st_size}

if __name__=='__main__':
    for n in (24,25):
        orig=next(Path('/mnt/data').glob(f'{n} Blog*txt'))
        dst=SRC/f'{n}-raw-explainer.txt'
        shutil.copy2(orig,dst)
    stats=[render(n,D[n]) for n in D]
    (ROOT/'NEW_READINGS_24_25_MANIFEST.json').write_text(json.dumps({'readings':stats,'sources':{str(n):D[n]['source'] for n in D}},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(stats,ensure_ascii=False,indent=2))
