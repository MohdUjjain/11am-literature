#!/usr/bin/env python3
"""Fallback for large Chromium full-book exports: replace 4 printed front pages,
retain byte-verified earlier body PDF pages, append independently printed Reading26.
All Contents link targets and hierarchical bookmarks are normalized and tested.
Usage: python publish_incremental_26.py OLD.pdf FRONT4.pdf READING26.pdf OUT.pdf
The assembled source HTML is authoritative and can also be exported monolithically.
"""
from pathlib import Path
import sys,re,fitz

def publish(old_file,front_file,chapter_file,out_file):
    old=fitz.open(str(old_file));front=fitz.open(str(front_file));new=fitz.open(str(chapter_file));out=fitz.open()
    assert len(front)==4 and len(old)==259 and len(new)==11
    assert all(abs(p.rect.width-960)<1.2 and abs(p.rect.height-540)<1.2 for d in (old,front,new) for p in d)
    old_toc=old.get_toc();new_toc=new.get_toc()
    assert len(old_toc)==364 and len(new_toc)==15
    # Page numbers 1..4 are the newly composed cover and 3 contents pages.
    out.insert_pdf(front,from_page=0,to_page=3,links=False)
    # Earlier reading pages are lifted from the certified previous PDF unchanged.
    out.insert_pdf(old,from_page=4,to_page=len(old)-1,links=True)
    # The standalone new chapter begins with its own cover: skip that one page.
    out.insert_pdf(new,from_page=1,to_page=len(new)-1,links=True)
    assert len(out)==269
    chapter_dest={int(m.group(1)):pn for lvl,title,pn in old_toc if lvl==2 and (m:=re.match(r'Reading\s+(\d+)\s+[—-]',title))}
    chapter_dest[26]=len(old)+1
    assert len(chapter_dest)==25 and 19 not in chapter_dest
    # The partial front PDF uses unresolved named destinations (because body
    # pages were deliberately excluded from the print job). Replace with real
    # PDF GoTo annotations to the fully merged chapter opener pages.
    links_added=0
    for front_index in range(1,4):
        pg=front[front_index]
        for link in pg.get_links():
            target=link.get('nameddest') or link.get('uri','')
            m=re.search(r'print-chapter-(\d+)',target)
            if not m: continue
            n=int(m.group(1));dest=chapter_dest[n]
            out[front_index].insert_link({'kind':fitz.LINK_GOTO,'from':link['from'],'page':dest-1,'to':fitz.Point(0,0),'zoom':0})
            links_added+=1
    assert links_added==25,links_added
    # Chapter26's standalone toc is relative to its own cover (page1).
    # After skipping the cover and appending beyond page259: +258.
    final_toc=old_toc + [[lvl,label,pn+len(old)-1] for lvl,label,pn in new_toc[1:]]
    assert len(final_toc)==378
    assert final_toc[-14][1].startswith('Reading 26')
    out.set_toc(final_toc)
    out.xref_set_key(out.pdf_catalog(),'PageMode','/UseOutlines')
    out.set_metadata({'title':'Complete Literature Dossier Notes — Through Reading 26',
      'author':old.metadata.get('author') or 'Mohammed Husain Ujjainwala',
      'subject':'25 completed literature readings — Reading 19 reserved',
      'keywords':'Literature Dossier, 11AM, Reading 26, Great Migration, revision'})
    out_file=Path(out_file);out_file.parent.mkdir(parents=True,exist_ok=True)
    out.save(str(out_file),garbage=3,deflate=True)
    out.close();old.close();front.close();new.close()
    result=fitz.open(str(out_file))
    assert len(result)==269 and len(result.get_toc())==378
    assert sum(len(p.get_links()) for p in result)==25
    assert all(abs(p.rect.width-960)<1 and abs(p.rect.height-540)<1 for p in result)
    chapter26=[r for r in result.get_toc() if r[1].startswith('Reading 26')]
    assert len(chapter26)==1 and chapter26[0][2]==260
    for p in result:
        for link in p.get_links():
            if link['kind']==fitz.LINK_GOTO: assert 0<=link['page']<269
    print(f'PASS: {len(result)} physical pages, {len(result.get_toc())} hierarchical bookmarks, {links_added} working Contents links; {out_file}')
    result.close()
if __name__=='__main__':
    if len(sys.argv)!=5:raise SystemExit(__doc__)
    publish(*map(Path,sys.argv[1:]))
