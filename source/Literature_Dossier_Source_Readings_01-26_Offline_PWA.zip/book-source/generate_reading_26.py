#!/usr/bin/env python3
"""Source-grounded final Reading 26: preserves existing book engine and prior chapters."""
from pathlib import Path
import json, shutil, importlib.util
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prior_gen',ROOT/'generate_readings_24_25.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
T=mod.T
D=dict(
 slug='26-warmth-of-other-suns-great-migration-part-2',
 color='#5B7792',
 title='The Warmth of Other Suns: The History of America’s Great Migration (Part 2)',
 subtitle='Ida Mae Gladney · Family, Caste, Resistance and the Possibility of Leaving Mississippi',
 thesis='The supplied narrative uses Ida Mae Gladney’s childhood, marriage and eventual life in Chicago to make the Great Migration more than a movement on a map. It presents flight from the South as a response to a racial caste order that controlled work, education, movement and safety, while tracing the personal resilience and family decisions through which a “window out” became imaginable.',
 source='1e8u-QMahqmdsghXcJ7srajh_A-NHWz8Il_bvnVXgarw',
 sections=[
 ('Chicago, 1996: Reading a Life Backward',[
  ('<p>The narrative opens not in Mississippi but in <strong>Chicago in 1996</strong>. From a second-floor vestibule on the South Side, an elderly <strong>Ida Mae Gladney</strong> watches what the author calls a “street circus”: dealers, children serving as lookouts and risky encounters along the street. Residents still call her <strong>“Grandma.”</strong> She does not romanticize the danger; the point is that she has seen a different system of danger in the <strong>“Old Country,”</strong> the rural South from which she came. The respectful name recognizes a history that younger neighbors do not fully know.</p>',[
   ('concept','Frame: the ending comes first','The Chicago scene supplies a perspective from which to interpret the Mississippi childhood that follows.'),
   ('memory','Memory · Window / old country','<strong>1996 window → Mississippi past</strong>: the narrator looks backward from Ida Mae’s survival.')]),
  ('<p>The reading treats the <strong>Great Migration</strong> as a historical movement driven by more than prospective wages. The “invisible hand” of Southern racial caste shaped <strong>where people could stand, whom they could trust, which resources they could access and what violence they might face</strong>. Ida Mae’s spirit—called a “spark” in the supplied account—matters because departure required personal initiative inside a structure designed to block it. Her eventual Chicago life should not be mistaken for proof that the northern city was free of hardship.</p>',[
   ('highyield','Interpretive thesis','Migration is a search for dignity and safety under constraint, not simply relocation for economic opportunity.'),
   ('mistake','Do not idealize Chicago','The opening depicts urban danger too; the contrast concerns the particular coercions of Southern caste.')])]),
 ('1913–1923: Resilience and the Loss of Protection',[
  ('<p><strong>Ida Mae Brandon</strong> was born on <strong>5 March 1913</strong> in Chickasaw County, Mississippi. Her nickname <strong>“Tom”</strong> came from her adventurous, “tomboy” nature: she preferred physically demanding outdoor work, including chopping wood and killing snakes. That characterization is not merely colorful biography. It prepares the reader to see someone capable of meeting hardship without surrendering her agency.</p>',[
   ('definition','The Old Country','Ida Mae’s remembered rural Mississippi, where work, racial caste and fear structured daily life.'),
   ('examtip','Characterization as evidence','Explain how the nickname “Tom” establishes Ida Mae’s disposition before the major crises.')]),
  ('<p>Her father, <strong>Joseph Brandon</strong>, died in <strong>May 1923</strong> after illness following his rescue of hogs during flooding. No doctor attended him: Black medical care was scarce, white doctors were distant, and the family had no effective access. The account retrospectively suggests a possible <strong>diabetic coma</strong>, not a diagnosis available to them then. Ten-year-old Ida Mae watched the burial believing her father might still be in a “spell.” His death meant both bereavement and the loss of a protector in a dangerous social world.</p>',[
   ('highyield','Why the medical detail matters','Unequal access to treatment turns an individual family tragedy into evidence of structural vulnerability.'),
   ('memory','Memory · 1913 / 1923','<strong>1913:</strong> Ida Mae born. <strong>1923:</strong> Joseph dies; family protection is diminished.')])]),
 ('School, Cotton Seasons and the “Philadelphia” Whipping',[
  ('<p>Schooling followed the <strong>cotton calendar</strong>, beginning after the October harvest and ending when planting resumed in April. Children’s education thus yielded to plantation labor. Ida Mae attended a one-room school run by <strong>Amos Kirks</strong>, a severe teacher whose artificial leg children noticed. The text recalls oral memory aids—including a rhyme for spelling <em>Mississippi</em>—as examples of the resourcefulness of pupils given limited formal schooling.</p>',[
   ('definition','The lay-by','A relatively quiet period in the crop cycle, usually in midsummer, while cotton grows before harvest.'),
   ('concept','School calendar = labor calendar','The timing of the term shows how plantation work set limits on Black education.')]),
  ('<p>After Joseph’s death, Ida Mae faltered when spelling <strong>“Philadelphia.”</strong> Kirks whipped her publicly, pronouncing successive letters with blows of a switch. Her protest—<strong>“If I had a daddy, you wouldn’t have whooped me”</strong>—makes her loss of paternal protection explicit. A neighbor’s blunt disclosure that <strong>Santa Claus did not exist</strong> is a smaller but complementary blow. Together the episodes dramatize the contraction of childhood security: bodily discipline at school and the loss of comforting belief at home.</p>',[
   ('highyield','Philadelphia = turning point','The spelling incident converts a classroom punishment into an assertion about unequal power and fatherlessness.'),
   ('memory','Memory · Spell / strike / speak','<strong>Philadelphia</strong>: mistakes in spelling → whipping → Ida Mae names her loss.')])]),
 ('The “Invisible Hand”: Caste as Everyday Control',[
  ('<p>The reading’s central metaphor is an <strong>“invisible hand”</strong> governing the racial order. Its effects were visible: in <strong>Calhoun City</strong>, parking near the bank was designated for white residents while Black residents were directed elsewhere; the account says this pattern persisted into the 1950s. Yet the rules were not just physical. Fear of appearing to violate a community’s conventions could regulate behavior even without an explicit order. The example of an Alabama woman hiding a Catholic statuette illustrates the pressure of socially enforced boundaries, though it is not identical to racial oppression.</p>',[
   ('concept','Material + psychological caste','Spatial restrictions, customary etiquette and threatened violence together reproduce hierarchy.'),
   ('mistake','Not every example is equivalent','The religious-statuette anecdote illustrates social conformity; it must not erase the specific violence of anti-Black caste.')]),
  ('<p>Two episodes show the limits of protection. A drunken white farmer fired toward Black cabins; Ida Mae <strong>hid inside a barrel of cornmeal</strong> while shots struck nearby. On another occasion two young white men <strong>dangled her over a well</strong> as supposed amusement. Joseph subsequently stopped sending her to the blacksmith: he could not guarantee her safety. Even <strong>Miss Julie McClenna</strong>, relatively kind to Ida Mae, ceased taking her to town after a customer objected to Ida Mae using the front entrance. Benevolent individuals could not neutralize the coercive system.</p>',[
   ('highyield','Three incidents, one structure','<strong>Cornmeal barrel:</strong> arbitrary violence; <strong>well:</strong> impunity; <strong>shop doorway:</strong> enforced deference.'),
   ('memory','Memory · Barrel / well / door','<strong>Gunfire → physical terror; well → unanswerable threat; door → daily exclusion.</strong>')])]),
 ('1928–1929: Courtship, Marriage and Economic Dependence',[
  ('<p><strong>Children’s Day at New Hope Baptist Church</strong> in summer 1928 created a space of Black communal life beyond white-controlled work. Two suitors embodied contrasting futures: <strong>Alfonso Banks</strong> offered excitement and a feeling of freedom, while <strong>George Gladney</strong> represented perseverance and stability. Ida Mae chose George despite her mother <strong>Miss Theenie</strong>’s preference for a lighter-skinned man whom she associated with better prospects. These choices show personal judgment operating within constraints of color and class.</p>',[
   ('concept','Church as communal space','Community celebration makes possible a social world that the plantation order does not wholly define.'),
   ('examtip','Why compare the two suitors?','Banks and Gladney represent different kinds of possibility, not a simple right/wrong choice.')]),
  ('<p>Ida Mae married George on <strong>15 October 1929</strong>, on a porch and against her mother’s wishes. She had hidden under a bed the preceding day to avoid the dispute. Marriage altered the arena of dependence: from daughter in Miss Theenie’s household to wife working within a <strong>sharecropping economy</strong>. The marriage took place about two weeks before the <strong>stock-market crash</strong>; planters’ difficulties would fall especially hard on sharecroppers, who bore the risks of crop production without owning the land.</p>'+T(['Before marriage','After marriage','Underlying constraint'],[
   ('Daughter and “Tom”; family helper','Wife and field-work partner','Household labor expectations'),
   ('Subject to her widowed mother','More decisions within marriage','Racial caste persists'),
   ('Family subsistence','Sharecropper’s crop-share/ledger','Landowner and market still determine security')]),[
   ('definition','Sharecropping','Tenants cultivate a planter’s land for a crop share, often becoming tied to debts and the owner’s accounts.'),
   ('memory','Memory · 1928 / 1929','<strong>1928:</strong> courtship at Children’s Day. <strong>1929:</strong> marriage, then financial crash.')])]),
 ('1926 and After: The “Window Out”',[
  ('<p>The <strong>1926 lynching of the Carter brothers in Okolona</strong> cast fear over the area. When surviving members of the Carter family left for <strong>Milwaukee</strong>, the move became a signal that there was a <strong>“window out.”</strong> The chronological order matters: the signal of escape preceded Ida Mae’s own 1929 marriage and the crash, while the source’s storytelling gathers these pressures into one explanation of why people eventually departed.</p>',[
   ('highyield','Flight can be imaginable before it happens','The Carter family’s departure gives the possibility of migration a concrete precedent.'),
   ('mistake','Keep the chronology honest','The supplied excerpt does not date Ida Mae’s eventual move north; do not invent her departure year or route.')]),
  ('<p>The reading asks us to join <strong>personal agency</strong> to <strong>structural causation</strong>. The system restricted education, safety, medical care and economic independence; the lynching and worsening financial prospects exposed its brutality. Yet individuals had to recognize a possible alternative and act on it. The Chicago prologue returns here as an answer: Ida Mae survived the “hard soil” of Mississippi, but the final image of her white hair, compared with cotton, keeps the old laboring landscape inside the northern life.</p>',[
   ('concept','Historical argument from biography','A life story supplies concrete experiences through which the larger migration becomes intelligible.'),
   ('memory','Memory · Soil → window → sun','<strong>Hard soil</strong> constrains; <strong>window out</strong> offers escape; <strong>other suns</strong> signify another life.')])])
 ],
 summary=[
  'The reading opens with Ida Mae Gladney in Chicago in 1996, then returns to her childhood in Chickasaw County. Its argument is that the Great Migration was an exercise of personal initiative against a racial caste order rather than a straightforward search for better wages. The northern scene is not idyllic; it establishes the long historical distance Ida Mae has traveled.',
  'Born in 1913, Ida Mae lost her father Joseph in 1923 amid unequal access to medical care. The “Philadelphia” school whipping and later incidents involving gunfire, a well and the segregated entrance expose a social hierarchy that rendered Black family protection precarious. The “invisible hand” works through institutions, customary rules and threatened violence.',
  'Church courtship in 1928, marriage to George Gladney in October 1929 and the ensuing crash placed Ida Mae inside the risks of sharecropping. The 1926 Carter lynching and relatives’ move to Milwaukee revealed a “window out.” The excerpt explains the conditions and imagined possibility of departure without providing Ida Mae’s actual migration date or journey.'
 ],
 sheet=[
  ('Central claim','Great Migration = search for dignity and protection against racial caste, with agency under constraint.'),
  ('Narrative frame','Chicago window (1996) first; Mississippi origins unfold afterward.'),
  ('Ida Mae','Born 5 March 1913; “Tom” suggests courage and independence.'),
  ('Loss','Joseph Brandon dies May 1923; unequal access to doctors.'),
  ('School','Cotton seasonal calendar; Philadelphia whipping shows fatherless vulnerability.'),
  ('Caste','Segregated parking/doorway; arbitrary violence at the cornmeal barrel and well.'),
  ('Courtship','1928 Children’s Day; Alfonso Banks versus steadfast George Gladney.'),
  ('Marriage','15 October 1929; sharecropping and market collapse.'),
  ('Window out','1926 lynching of Carter brothers; family’s relocation to Milwaukee.'),
  ('Final image','Cotton-white hair in 1996 connects Ida Mae’s urban survival to remembered field labor.')
 ],
 definitions=[
  ('Great Migration','Mass movement of African Americans out of the South; here explained through an individual life'),
  ('Old Country','Ida Mae’s name for the remembered rural Southern world'),
  ('Invisible hand','Metaphor for pervasive, frequently unwritten caste restrictions'),
  ('Jim Crow','Historical regime of racial segregation and subordination referenced in the explainer'),
  ('Sharecropping','Farming another owner’s land for an agreed share of the crop'),
  ('The lay-by','Midseason interval of crop growth before harvest'),
  ('Caste','Deeply enforced social hierarchy constraining status and opportunity'),
  ('Agency','Capacity to decide and act even within oppressive conditions'),
  ('Window out','The imagined prospect of departing the Southern caste order'),
  ('Narrative frame','The 1996 scene that contextualizes the earlier biographical events')
 ],
 tables=[
  T(['Date','Episode','Reading significance'],[
   ('1913','Ida Mae Brandon born in Chickasaw County','Early resilience'),
   ('1923','Death of Joseph Brandon','Bereavement and weakened protection'),
   ('1926','Carter brothers lynched; survivors later leave','Terror and a possible escape'),
   ('1928','Children’s Day and courtship','Black communal life and individual choice'),
   ('15 Oct. 1929','Marriage to George Gladney','New household within sharecropping'),
   ('Late 1929','Market crash','Economic vulnerability deepens'),
   ('1996','Ida Mae at the Chicago window','Retrospective survival and remembered South')]),
  T(['Constraint','Concrete scene','Interpretive weight'],[
   ('Health','Joseph receives no doctor','Resources unequally distributed'),
   ('Education','Harvest/planting school calendar','Plantation demands override schooling'),
   ('Physical safety','Cornmeal barrel and well','Violence without effective redress'),
   ('Public space','Parking places and doorway','Humiliation made ordinary'),
   ('Livelihood','Sharecropping and crash','Financial dependence beyond individual control')])
 ],
 questions=[
  ('Narrative','Why begin the account with Ida Mae in Chicago in 1996?'),
  ('Character','How does the nickname “Tom” inform the portrayal of Ida Mae?'),
  ('Structure','Explain how Joseph Brandon’s death exposes institutional as well as personal vulnerability.'),
  ('Close reading','What does the Philadelphia whipping reveal about authority and fatherlessness?'),
  ('Caste','Use the cornmeal barrel, well and shop doorway to explain the “invisible hand.”'),
  ('Comparison','How do Alfonso Banks and George Gladney embody different possibilities?'),
  ('Chronology','Connect the Carter brothers’ lynching, Milwaukee departure, 1929 marriage and market crash without confusing their dates.'),
  ('Synthesis','In what sense was migration an act of agency under oppressive structural conditions?')
 ]
)
if __name__=='__main__':
 source=next(Path('/mnt/data').glob('26 Blog - The Warmth*.txt'))
 shutil.copy2(source,ROOT/'sources'/'26-raw-explainer.txt')
 x=mod.render(26,D)
 (ROOT/'NEW_READING_26_MANIFEST.json').write_text(json.dumps({'reading':x,'source_doc':D['source']},ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(x,ensure_ascii=False))
