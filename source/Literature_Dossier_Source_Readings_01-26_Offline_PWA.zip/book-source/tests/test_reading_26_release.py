#!/usr/bin/env python3
"""Readings 01–26 integrity, source and composed note QA; no reliance on source PDF parse."""
from pathlib import Path
from collections import Counter
from zipfile import ZipFile
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import hashlib,json,fitz
R=Path(__file__).resolve().parents[1]
BASE=Path('/mnt/data/Literature_Dossier_Source_Readings_01-25_Offline_PWA.zip')
with ZipFile(BASE) as z:
  fixed=[]
  for name in z.namelist():
    if (name.startswith('book-source/chapters/') and name.endswith('.html')) or name in [f'book-source/{x}' for x in ('styles.css','engine.js','build.py','export_bookmarked.py','cover.html','course_index.json')]:
      rel=name.removeprefix('book-source/')
      assert (R/rel).read_bytes()==z.read(name),f'Prior file changed: {rel}'
      fixed.append(rel)
  assert len([x for x in fixed if x.startswith('chapters/')])==24

f=next((R/'chapters').glob('26-*.html'));s=BeautifulSoup(f.read_text(),'html.parser')
notes=s.select('.leaf article.passage > aside [data-note-id]');revision=s.select('.revision-zone .section')
assert len(notes)==24 and len(revision)==6
assert len({x['data-note-id'] for x in notes})==len(notes)
assert set(x['data-content-type'] for x in notes)=={'definition','concept','memory','examtip','mistake','highyield'}
for x in notes:assert x['data-note-id'].startswith(x.find_parent('article')['data-anchor'])
memory=[x.p.decode_contents() for x in notes if x['data-content-type']=='memory']
collected=[x.p.decode_contents() for x in s.select('.revision-zone .callout--memory')]
assert len(memory)==6 and memory==collected
assert len(s.select('.leaf .section'))==6
assert len(s.select('.leaf table'))==1
assert len(s.select('.revision-zone table'))>=3
raw=(R/'sources/26-raw-explainer.txt').read_bytes()
assert raw==next(Path('/mnt/data').glob('26 Blog - The Warmth*.txt')).read_bytes()

with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  ctx=browser.new_context(viewport={'width':1500,'height':950});pg=ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.route('https://fonts.googleapis.com/**',lambda r:r.abort());pg.route('https://fonts.gstatic.com/**',lambda r:r.abort())
  pg.set_content((R/'output/book.html').read_text(),wait_until='domcontentloaded',timeout=30000)
  pg.evaluate('window.DossierPrint.build()');diag=pg.evaluate('window.__dossierPrintDiagnostics')
  audit=pg.evaluate('''() => {
   const pages=[...document.querySelectorAll('#print-root>.printed-page')];
   const notes=[...document.querySelectorAll('#print-root .side-note-card')];
   const res=notes.map(x=>{let p=x.closest('.printed-page'),a=x.getAttribute('data-note-anchor');
    return {id:x.getAttribute('data-note-id'),n:p?.getAttribute('data-print-chapter'),a,page:pages.indexOf(p)+1,match:!!p?.querySelector('.page-main-column [data-anchor="'+a+'"]')};});
   return {total_pages:pages.length,notes:res,clipped:pages.map((p,i)=>({i:i+1,el:p.querySelector('.printed-body')})).filter(x=>x.el&&x.el.scrollHeight>x.el.clientHeight+2).map(x=>x.i)}; }''')
  assert not errors and not diag.get('error') and not diag.get('overflows') and diag.get('notesUnplaced')==0,(errors,diag)
  assert audit['total_pages']==269 and len(audit['notes'])==513,(audit['total_pages'],len(audit['notes']))
  subset=[x for x in audit['notes'] if x['n']=='26']
  assert len(subset)==24 and all(x['match'] for x in subset)
  missing=[x for x in audit['notes'] if not x['match']]
  assert len(missing)==1,missing
  assert not audit['clipped']
  ctx.close()
  mob=browser.new_context(viewport={'width':390,'height':844});mp=mob.new_page()
  mp.route('https://fonts.googleapis.com/**',lambda r:r.abort());mp.route('https://fonts.gstatic.com/**',lambda r:r.abort())
  mp.set_content((R/'output/book.html').read_text(),wait_until='domcontentloaded',timeout=30000)
  widths=mp.evaluate('''() => ({scroll:document.documentElement.scrollWidth,client:document.documentElement.clientWidth})''')
  assert widths['scroll']<=widths['client']+2,widths
  mob.close();browser.close()

pdf=fitz.open('/mnt/data/Complete_Literature_Dossier_Editorial_Readings_01-26.pdf')
assert len(pdf)==269 and len(pdf.get_toc())==378
assert sum(len(p.get_links()) for p in pdf)==25
assert pdf.xref_get_key(pdf.pdf_catalog(),'PageMode')==('name','/UseOutlines')
assert all(abs(p.rect.width-960)<1 and abs(p.rect.height-540)<1 for p in pdf)
assert '25 readings' in pdf[1].get_text() and 'Reading 26' in pdf[3].get_text()
for link in pdf[3].get_links():
  if link['kind']==fitz.LINK_GOTO and link['page']==259:break
else:raise AssertionError('Contents link for Reading 26 missing')
assert pdf[259].get_text().startswith('READING 26')
assert 'Reading 26' in pdf.get_toc()[-14][1]
report={
 'status':'PASS','prior_chapters_and_publisher_files_preserved':len(fixed),
 'new_reading':{'number':26,'sections':6,'source_sha256':hashlib.sha256(raw).hexdigest(),'source_word_count':len(raw.decode('utf-8').split()),
     'cards':len(subset),'aligned':sum(c['match'] for c in subset),'memory_aids':len(memory),'revision_sections':len(revision),'main_tables':1},
 'full_composition':{'pages':269,'notes':len(audit['notes']),'exact_matches':sum(x['match'] for x in audit['notes']),
    'inherited_exceptions':missing,'clipped':audit['clipped']},
 'full_pdf':{'pages':len(pdf),'bookmarks':len(pdf.get_toc()),'contents_links':sum(len(p.get_links()) for p in pdf),
    'publisher':'Recomposed 4-page front matter + certified old body + independently composed Reading26'},
 'mobile':widths,'reserved_unassigned':[19], 'automations_disabled':True}
(R/'QA_READING_26_MACHINE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
