# FINAL ASSIGNED READING CHECKPOINT — READINGS 01–26 (READING 19 RESERVED) · 5 November 2026

**25 completed readings**; Reading 19 is intentionally unassigned. Reading 26 (*The Warmth of Other Suns*, Part 2) was added from a connected Google Doc and condensed to 4 main pages without altering the compositor. The entire book has **269 verified landscape PDF pages, 378 real bookmarks, 25 clickable Contents entries**. Offline PWA cache version **`11am-lit-reader-01-26-v4`**.

- 24 new cards / 24 exact passages; 513 total cards / 512 exact matches (one inherited Reading 04 note). Six revision subsections and six gathered memory aids. Prior 24 chapter files and 6 core publisher/index files were unchanged.
- Live publishing source: `build.py`, `head-template.html`, chapters, CSS and JS. The PDF printing fallback `publish_incremental_26.py` uses a freshly printed 4-page front matter + 255 earlier reading sheets + 10 new reading sheets and normalizes bookmarks and links.
- Drive source archived verbatim in `sources/26-raw-explainer.txt`. Generate only the new module with `generate_reading_26.py` if needed; **never re-run historical generators over curated chapters**.
- Test: `python build.py`, `python tests/test_reading_26_release.py` (expects the matching prior source and release PDF), and see `QA_READING_26.md`, `QA_READING_26_MACHINE.json`, `MANUAL_CHECKPOINT_READING_26.json`.
- The recurring automation remains disabled. Further manual work should focus on missing Reading 19 if provided, or whole-volume polish and QA.

---

# LATEST VERIFIED MANUAL CHECKPOINT — READINGS 01–18 · 5 November 2026

**This verified editorial/sidebar ZIP supersedes the 01–16 source for future manual work.** Readings 17 (*Cultivating Human Rights: Islamic Law and the Humanist Imperative*) and 18 (*The Catcher in the Rye*, Chapters 19–21) were authored from the named connected Google Drive explainers, archived without alteration in `sources/17-raw-explainer.txt` and `sources/18-raw-explainer.txt`.

- **Complete PDF: 192 landscape pages, 278 genuine bookmarks and 18 Contents links.** New pair PDF: 25 pages and 31 bookmarks. Both Readings 17 and 18 have 5 pages of main notes under the unchanged offline-font layout.
- New studies: 7 main sections / 23 side cards / 5 memory aids / 2 tables in Reading 17; 6 main sections / 20 side cards / 5 memory aids / 2 tables in Reading 18. All 6 dark revision sections in each, including independently collected copies of every contextual memory aid.
- **New note alignment: 43/43 exact-passage matching, zero overflows or browser errors; mobile width 390 px passed.** Full-book 345/346 aligned; inherited Reading 04 exception `s4-6-n2` remains and is not a new defect.
- **Existing files preserved**: all 16 earlier chapter HTML files and 7 publisher/index files are byte-for-byte identical to the prior verified 01–16 source archive. No changes to typography, geometry, page-break rules, styles or shared compositor.
- Source-derived quotes and interpretative claims are explicitly attributed to the user-supplied explainers, not independently verified against the original literary and scholarly publications.
- Reproduce: `python build.py && python export_bookmarked.py --chapters 1-18 --font-profile offline --out output/full.pdf`. Validate `python tests/test_readings_17_18.py`. The generator `generate_readings_17_18.py` writes only the new 17/18 chapter files; **do not rerun historical generators** over prior curated chapters.
- Next manual pair: **20–21**, since reading **19 remains reserved and unidentified**. The recurring automation remains **disabled**.

---

# LATEST VERIFIED MANUAL CHECKPOINT — READINGS 01–16 · 4 November 2026

**Use this source ZIP as the authoritative starting point for the next manual batch, Readings 17–18.** Readings 15 and 16 were added from connected Google Docs. Their complete plain-text exports are preserved verbatim as `sources/15-raw-explainer.txt` and `sources/16-raw-explainer.txt`. The previous 01–14 chapter HTML and all shared publisher files remain unchanged. This batch used the five-main-page editorial target, permitting six for a dense reading; it did not modify typography, spacing or the print compositor.

- Latest full export: **169 physical pages**, **249 genuine bookmarks**, **16 Contents links**, zero detected PDF overflow in the offline-font profile.
- New pair 15–16: **25 pages**, **33 genuine bookmarks**; **49/49 notes** precisely aligned; five main pages for 15 and six for 16; all six revision sections each. Standalone exports: Reading 15 is 12 pages, Reading 16 is 13 pages (with no Contents).
- Full-volume alignment: 302/303; the single previously documented offline-font exception is `s4-6-n2` (Reading 04). Do not silently modify older chapters to mask it.
- `NEW_READINGS_15_16_MANIFEST.json`, `QA_READINGS_15_16.md` and `QA_READINGS_15_16_MACHINE.json` document provenance and checks; `generate_readings_15_16.py` writes only two chapter files.
- Build and test: `python build.py`, `python export_bookmarked.py --chapters 1-16 --font-profile offline --out output/full.pdf`, `python tests/test_readings_15_16.py`.
- The scheduled automation remains **disabled**. Reading 19 remains unassigned; never shift later numbered readings into its place.

---

# LATEST VERIFIED MANUAL CHECKPOINT — READINGS 01–14 · 4 November 2026

**This is the authoritative checkpoint for any future task.** Reading 13 (*The Book Thief*, Part 1) and Reading 14 (*Textual Endings as Persuasive Educational Beginnings*) were added from the named Google Docs in the supplied Drive folder. Full source text exports are archived without change in `sources/13-raw-explainer.txt` and `sources/14-raw-explainer.txt`. The 12 earlier chapter files and seven shared publishing files remain byte-for-byte identical to the 01–12 verified ZIP.

- Final complete dossier: **146 pages** (offline font profile), **218 PDF bookmarks**, **14 clickable Contents links**, zero detected overflow.
- Two-reading chapter PDF: **21 pages**, **31 bookmarks**, with **45 / 45 new exact note-to-passage placements** and every semantic category. Full-volume audit finds one inherited offline-font alignment exception in Reading 04 (s4-6-n2), documented in the QA report; no earlier chapter was rewritten. Four main-note pages for Reading 13, five for Reading 14, without any global CSS, font, spacing or print-engine changes.
- Reading 13: 6 narrative sections, 2 evidence/comparison tables, 5 unique memory cues, all 6 revision sections. Reading 14: 7 substantive sections, 2 tables, 6 memory cues, all 6 revision sections. Conclusion repetitions were consolidated into the last substantive sections; their complete synthesis remains in Chapter Summary.
- Starting point for next **manual** batch: **Reading 15 — The Dāʾūdī Bohras** and **Reading 16 — Shuʿūbiyyah in Arabic Literature**. The recurring automation stays disabled. Reading 19 remains reserved.
- Build: `python build.py` followed by `python export_bookmarked.py --font-profile offline --out output/complete_01_14.pdf`. Test: `python tests/test_readings_13_14.py`. Inspect `QA_READINGS_13_14.md` and `NEW_READINGS_13_14_MANIFEST.json`.
- `generate_readings_13_14.py` is a **provenance generator for ONLY those two new chapters**. Do not rerun old `generate_...` scripts over curated earlier chapter files.

---

# MANUAL CHECKPOINT — READINGS 01–12 · 4 November 2026

**This section is authoritative.** Reading 11 (Homicide in Islamic Law) and Reading 12 (Jews and the Fatimid Caliphate) have been added from the two Google Docs, with raw source exports in `sources/11-raw-explainer.txt` and `sources/12-raw-explainer.txt`. All previously validated chapters 01–10 and all shared printing files are byte-for-byte unchanged. Each new reading has eight substantive sections, all six semantic sidebar categories, five contextual memory aids collected again in six dark revision sections.

- Current complete PDF: **127 physical pages, 189 actual PDF bookmarks, 12 Contents links** (offline font profile), zero compositor-detected overflow.
- Reading 11: five main pages. Reading 12: four main pages, after removing a duplicated conclusory recap that otherwise caused an almost-empty continuation sheet. Tables and scholarly evidence are not dropped.
- Next manual batch: **Readings 13 and 14**. The old hourly automation is disabled. Reading 19 stays reserved.
- Reproduce: `python build.py && python export_bookmarked.py --chapters '1-12' --font-profile offline --out output/Complete_01_12.pdf`. For a two-reading export use `--chapters 11,12`.
- Validation: `python tests/test_readings_11_12.py` and read `QA_READINGS_11_12.md`. Font downloads were blocked for the reproducible release; original font choices remain in CSS.
- Treat all `generate_*` scripts as provenance; never rerun an older generator across curated existing chapters. Only `generate_readings_11_12.py` regenerates the current two readings.

---


## Verified manual checkpoint: Readings 01–10

Readings 09 (Philosophy of Language in the Medieval Arabic Tradition) and 10 (Black Muslim) have been added under the existing sidebar+condensed design. First eight chapter files and publisher components are unchanged. The previously enabled hourly automation is **disabled**; processing continues manually, with Readings 11 and 12 next.

The archived raw Google Docs exports are in `sources/09-raw-explainer.txt` and `sources/10-raw-explainer.txt`. Source provenance, page counts, exact note alignment and the offline-font caveat are documented in `QA_READINGS_09_10.md`. A portable generation helper is `generate_readings_09_10.py`.

For reproducible publishing: run `python build.py` and then `python export_bookmarked.py --chapters '1-10' --font-profile offline --out output/Complete_Readings_01_10.pdf`. The title index reserves missing Reading 19. Five body pages remains the target, with six accepted when evidence requires it.


> **LATEST EDITORIAL RELEASE — 4 NOV 2026:** This edition supersedes the original 105-page uncondensed one.
> Read `EDITORIAL_COMPRESSION_POLICY.md`, `EDITORIAL_CHECKPOINT.json`, and `EDITORIAL_01_08_QA.md` before adding reading 09+.
> The full verified PDF now has **88 pages** (43 main, 35 revision, 8 openers, 2 front); 125 bookmarks and 128 exact-match sidebar notes.
> **Never** run the legacy `generate_*readings*.py` to refresh existing curated chapters; they overwrite edited material.
> The older strict verbatim test `tests/test_eight_readings.py` is historical only, not an acceptance criterion for user-authorized editing.

# Complete Literature Dossier Notes — Sidebar Edition · Readings 01–08

**Canonical, editable 16:9 landscape publishing source**. The former long 333 KB Geoffrey Khan reading is archived separately; this current Reading 01 is the shorter user-supplied replacement. The eight scholarly chapters and original explainers remain intact; only their layout, card placement and shared compositor have been migrated.

## Current completed chapters

| # | Syllabus reading | Main study aids |
|---|---|---:|
| 01 | A Petition to the Fāṭimid Caliph al-Āmir | 15 |
| 02 | Was the Fatimid Amīr al-Juyūsh in fact a Wazīr (Another Version) | 16 |
| 03 | Learning the Grammar of Animacy | 18 |
| 04 | Al-Afḍal b. Badr al-Jamālī, the vizierate and the Fatimid response to the First Crusade | 19 |
| 05 | Persian in Arabic Poetry - Identity Politics and Abbasid Macaronics | 14 |
| 06 | The Worst of Times - Crisis Management and Al-Shidda al-ʿUzma | 14 |
| 07 | The Qadi, the Wazir and the Da'i - Religious and Ethnic Relations in Buyid Shiraz in the Eleventh Century | 15 |
| 08 | The Fatimids and the Red Sea (969–1171) | 17 |

Read **`SIDEBAR_AUTHORING_AND_PRINT_CONTRACT.md` before authoring any next chapter**. Its instructions override the earlier no-sidebar layout and any historical templates. Reading 19 in `course_index.json` has no title, and must not be invented or renumbered.

## Editing and building

Each reading is in `chapters/NN-*.html`; matching user-provided explainers are in `sources/NN-raw-explainer.md`. These chapter files and source texts are the canonical educational content. `styles.css`, `engine.js`, `cover.html`, `head-template.html` and `build.py` are the stable in-house publisher. Edit sources, not `output/book.html`.

```bash
cd book-source
python build.py
python export_bookmarked.py --chapters 1-8 --font-profile offline --out output/dossier_01_08.pdf
python export_bookmarked.py --chapters '8,1,6' --no-revision --font-profile offline --out output/order_test.pdf
python tests/test_sidebar_integrity.py --pdf output/dossier_01_08.pdf
```

If locally licensed/open fonts are installed in `fonts/` at build time, `--font-profile local` explicitly loads Spectral, Fraunces, Inter and Amiri before pagination. The delivered source archive does **not** distribute raw font files; `--font-profile offline` instead uses available system fonts, and `normal` uses the HTML's font sources when reachable. The delivered final PDF has embedded font subsets and was fully tested using the intended local fonts. Never change fonts *after* pagination.

Older `generate_*readings*.py` scripts are retained as historical authoring provenance, **not** a way to refresh existing chapters: they can overwrite the curated sidebar anchor structure. All new chapters should be authored in the `.passage/.prose/aside` format described in the contract. If a new component cannot fit, add a measured adapter to the compositor rather than allowing Chromium to fragment an unchecked page.

## QA and continuing production

The 01–08 sidebar migration passed source integrity checks, preserved all 15 main evidence tables and both process strips, and produced 105 physical sheets / 138 actual hierarchical bookmarks / 8 Contents links with 128 exactly anchored sidebar cards. Mobile stacking at 390px passed. See `SIDEBAR_01_08_QA.md` for the detailed report.

**Next assigned batch: Readings 09 and 10**. Work two readings at a time from the connected Drive folder, save each validated checkpoint persistently, and never overwrite a newer independently verified edition. Preserve the six semantic colors, separate dark revision zone, six revision subsections, and main-text explanations. Attribute source text to the provided explainer; do not claim independent scholarly verification.

## Manual editorial checkpoint: Readings 20 and 21 (5 November 2026)

Completed source documents: 20 and 21, preserving 01–18. Reading 19 is unassigned. The cumulative verified PDF is 217 pages with 307 real bookmarks. The two-reading PDF is 27 pages. New cards: 49/49 exactly passage-aligned; one old 04 sidebar exception remains in offline metrics. See `MANUAL_CHECKPOINT_READINGS_20_21.json`, `NEW_READINGS_20_21_MANIFEST.json`, `QA_READINGS_20_21.md`. Continue manually with Readings 22–23. Do not alter CSS/compositor, previous chapters, or scheduled task.


## Manual checkpoint: Readings 22 and 23 (5 November 2026)

Both readings are integrated into the single-file GitHub Pages offline reader; Reading 19 remains unassigned. Editorial main lengths: 5 pages for 22, 4 for 23. Complete 22-reading verified PDF: 239 pages, 336 bookmarks and 22 Contents links (offline-font profile). All 47 new study cards are correctly passage-aligned; the inherited Reading 04 font-metric exception persists. Source: `MANUAL_CHECKPOINT_READINGS_22_23.json`; QA: `QA_READINGS_22_23.md`. Next manually assigned pair: Readings 24–25. Bump the service-worker cache version with every published content update.
